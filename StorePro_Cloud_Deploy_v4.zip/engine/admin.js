/* =========================================================
   محرك لوحة تحكم التاجر — Merchant Admin Engine v3.0
   متصل بلوحة المالك المركزية (يدعم الباقات الأسبوعية، الشهرية،
   السنوية، الدائمية مدى الحياة، وحد المنتجات، ودخول المالك المباشر)
   ========================================================= */
(function () {
  'use strict';

  var MASTER_STORES_KEY = 'agency_master_stores_v1';
  var MASTER_CFG_KEY = 'agency_master_config_v1';

  var SECTOR_TEMPLATES = {
    fashion: {
      title: 'بوتيك أزياء نسائية وعبايات', color: '#7A4E2D', tagline: 'أزياء نسائية راقية · توصيل لكل المحافظات',
      categories: ['عبايات', 'فساتين', 'أطقم كاجوال', 'قمصان وبلوزات', 'حقائب', 'أحذية', 'عطور', 'إكسسوارات'],
      useDemoProducts: true
    },
    cosmetics: {
      title: 'عطور وكوزمتك وعناية', color: '#9D174D', tagline: 'عطور أصلية · عناية بالبشرة · مكياج',
      categories: ['عطور نسائية', 'عطور رجالية', 'عناية بالبشرة', 'مكياج', 'مجموعات هدايا'],
      products: [
        { id: 'c-1', name: 'عطر عود العنبر الملكي 100 مل', category: 'عطور نسائية', price: 42000, oldPrice: 52000, badge: 'ثبات 48 ساعة', images: ['images/perfume.jpg'], sizes: ['50 مل', '100 مل'], colors: [], desc: 'تركيبة شرقية فاخرة من العود الكمبودي والعنبر الدافئ والزعفران.' },
        { id: 'c-2', name: 'مجموعة العناية المتكاملة بالبشرة', category: 'عناية بالبشرة', price: 35000, badge: 'الأكثر مبيعاً', images: ['images/perfume.jpg'], sizes: ['مجموعة كاملة'], colors: [], desc: 'سيروم فيتامين C مع مرطب عميق وغسول يومي لنضارة فورية.' }
      ]
    },
    abaya: {
      title: 'دار عبايات وشالات خليجية', color: '#1C1917', tagline: 'عبايات خليجية فاخرة · تفصيل حسب الطلب',
      categories: ['عبايات سوداء', 'عبايات ملونة', 'عبايات مناسبات', 'شالات وحجابات'],
      products: [
        { id: 'ab-1', name: 'عباية كريب ملكي مطرزة يدوياً', category: 'عبايات سوداء', price: 48000, oldPrice: 60000, badge: 'الأكثر مبيعاً', images: ['images/abaya.jpg'], sizes: ['52', '54', '56', '58', '60'], colors: [{ name: 'أسود ملكي', hex: '#141414' }], desc: 'قماش كريب كوري أصلي درجة أولى مع تطريز يدوي وشال مطابق.' },
        { id: 'ab-2', name: 'فستان وعباية سهرة مخمل', category: 'عبايات مناسبات', price: 65000, badge: 'إصدار خاص', images: ['images/evening-dress.jpg'], sizes: ['52', '54', '56', '58'], colors: [{ name: 'ماروني', hex: '#5B1A18' }], desc: 'تصميم ملكي فاخر للمناسبات الخاصة.' }
      ]
    },
    sport: {
      title: 'ملابس رياضية وكاجوال شبابي', color: '#1E3A8A', tagline: 'تراكسوتات · كاجوال · أحذية رياضية',
      categories: ['تراكسوتات', 'تيشيرتات', 'بناطيل كاجوال', 'أحذية رياضية', 'ساعات رياضية'],
      products: [
        { id: 'sp-1', name: 'طقم تراكسوت قطني مريح', category: 'تراكسوتات', price: 38000, badge: 'جديد', images: ['images/sport-set.jpg'], sizes: ['M', 'L', 'XL', 'XXL'], colors: [{ name: 'أخضر ميرمية', hex: '#8FA394' }, { name: 'أسود', hex: '#1F1F1F' }], desc: 'قطن تركي ممتاز مناسب للرياضة والطلعات اليومية.' }
      ]
    },
    shoes: {
      title: 'حقائب وأحذية جلدية', color: '#641E16', tagline: 'حقائب ماركات · أحذية مريحة · جلد طبيعي',
      categories: ['حقائب يد', 'حقائب كتف', 'أحذية كعب', 'أحذية فلات ومريحة'],
      products: [
        { id: 'sh-1', name: 'حقيبة جلد كراميل كلاسيك', category: 'حقائب يد', price: 35000, badge: 'الأكثر طلباً', images: ['images/handbag.jpg'], sizes: [], colors: [{ name: 'كراميل', hex: '#A86532' }, { name: 'أسود', hex: '#1B1B1B' }], desc: 'حقيبة جلدية فاخرة مع حزام كتف.' },
        { id: 'sh-2', name: 'حذاء كعب عالي نود أنيق', category: 'أحذية كعب', price: 29000, images: ['images/heels.jpg'], sizes: ['37', '38', '39', '40'], colors: [{ name: 'نود بيج', hex: '#D6B79E' }], desc: 'قالب طبي مريح جداً للمناسبات والدوام.' }
      ]
    },
    watches: {
      title: 'ساعات وإكسسوارات وهدايا', color: '#1C1917', tagline: 'ساعات أصلية · إكسسوارات · هدايا فخمة',
      categories: ['ساعات نسائية', 'ساعات رجالية', 'إكسسوارات ومجوهرات', 'بوكسات هدايا'],
      products: [
        { id: 'wt-1', name: 'ساعة ذهبية حصير ضد الماء', category: 'ساعات نسائية', price: 28000, oldPrice: 35000, badge: 'ضمان سنة', images: ['images/watch.jpg'], sizes: [], colors: [{ name: 'ذهبي', hex: '#D4AF37' }], desc: 'ساعة ستانلس ستيل أصلية ضد الماء مع علبة فخمة.' }
      ]
    },
    sweets: {
      title: 'مخبز وحلويات وكيك', color: '#9D174D', tagline: 'كيك · حلويات شرقية · بوكسات مناسبات',
      categories: ['كيك مناسبات', 'حلويات شرقية', 'بوكسات ضيافة', 'معجنات'],
      products: []
    },
    electronics: {
      title: 'إلكترونيات وإكسسوارات موبايل', color: '#1E3A8A', tagline: 'إكسسوارات موبايل · شواحن · سماعات',
      categories: ['سماعات', 'شواحن وكوابل', 'كفرات وحماية', 'ساعات ذكية'],
      products: []
    },
    kids: {
      title: 'ملابس وألعاب أطفال', color: '#047857', tagline: 'ملابس أطفال · ألعاب تعليمية · مستلزمات',
      categories: ['ملابس مواليد', 'ملابس بناتي', 'ملابس ولادي', 'ألعاب وهدايا'],
      products: []
    },
    decor: {
      title: 'ديكور ومنزل ومفروشات', color: '#7A4E2D', tagline: 'ديكور منزلي · إضاءة · مفارش',
      categories: ['تحفيات وديكور', 'إضاءة ومصابيح', 'مفارش وسجاد', 'مستلزمات مطبخ'],
      products: []
    }
  };

  var SEEDED_STORES_META = {
    'lujain': { n: 'بوتيك لُجين', tg: 'أزياء نسائية راقية · عطور · إكسسوارات', t: 'fashion', w: '9647700000001', ig: 'lujain.boutique.iq', pl: 'monthly', cl: '#7A4E2D' },
    'noor-beauty': { n: 'نور بيوتي', tg: 'عطور أصلية · عناية بالبشرة · مكياج', t: 'cosmetics', w: '9647700000002', ig: 'noor.beauty.iq', pl: 'yearly', cl: '#9D174D' },
    'dar-alabaya': { n: 'دار العبايات الملكية', tg: 'عبايات خليجية فاخرة · تفصيل حسب الطلب', t: 'abaya', w: '9647700000003', ig: 'dar.alabaya', pl: 'lifetime', cl: '#1C1917' },
    'sport-zone': { n: 'سبورت زون', tg: 'تراكسوتات · كاجوال · أحذية رياضية', t: 'sport', w: '9647700000004', ig: 'sportzone.iq', pl: 'weekly', cl: '#1E3A8A' },
    'kaab-alghazal': { n: 'كعب الغزال', tg: 'أحذية نسائية · حقائب جلد طبيعي', t: 'shoes', w: '9647700000005', ig: 'kaab.alghazal', pl: 'monthly', cl: '#641E16' },
    'time-gallery': { n: 'تايم كاليري', tg: 'ساعات أصلية · إكسسوارات · هدايا فخمة', t: 'watches', w: '9647700000006', ig: 'time.gallery.iq', pl: 'yearly', cl: '#1C1917' },
    'baghdad-sweets': { n: 'حلويات بغداد', tg: 'كيك · حلويات شرقية · بوكسات مناسبات', t: 'sweets', w: '9647700000007', ig: 'baghdad.sweets', pl: 'trial', cl: '#9D174D' },
    'smart-tech': { n: 'سمارت تك', tg: 'إكسسوارات موبايل · شواحن · سماعات', t: 'electronics', w: '9647700000008', ig: 'smarttech.iq', pl: 'monthly', cl: '#1E3A8A' },
    'little-stars': { n: 'نجوم صغار', tg: 'ملابس أطفال · ألعاب تعليمية · مستلزمات', t: 'kids', w: '9647700000009', ig: 'little.stars.iq', pl: 'lifetime', cl: '#047857' },
    'bayt-alfan': { n: 'بيت الفن للديكور', tg: 'ديكور منزلي · إضاءة · مفارش', t: 'decor', w: '9647700000010', ig: 'bayt.alfan', pl: 'weekly', cl: '#7A4E2D' },
    'stress-test': { n: 'متجر اختبار الأداء (150 منتج)', tg: 'متجر تجريبي لاختبار التحميل المجزأ 20 منتج في كل دفعة', t: 'fashion', w: '9647700000099', ig: 'stress.test.iq', pl: 'lifetime', cl: '#7A4E2D' }
  };

  function buildStoreFromMiniObj(slug, mini) {
    if (!mini || !mini.n) return null;
    var tpl = SECTOR_TEMPLATES[mini.t] || SECTOR_TEMPLATES.fashion;
    var prods = (tpl.useDemoProducts && window.STORE && window.STORE.products)
      ? JSON.parse(JSON.stringify(window.STORE.products))
      : JSON.parse(JSON.stringify(tpl.products || []));
    return {
      slug: slug || mini.s || 'store-1',
      name: mini.n,
      tagline: mini.tg || tpl.tagline,
      whatsapp: mini.w || '9647700000000',
      instagram: mini.ig || '',
      adminPin: mini.p || '1234',
      templateId: mini.t || 'fashion',
      currency: 'د.ع',
      orderPrefix: (slug || mini.s || 'STR').slice(0, 3).toUpperCase(),
      announcement: '✨ الدفع عند الاستلام والتوصيل السريع لجميع المحافظات ✨',
      theme: { primary: mini.cl || tpl.color || '#7A4E2D', accent: '#C89B6E', bg: '#FAF7F2', text: '#1F1A17' },
      hero: { title: 'أهلاً بكم في ' + mini.n + ' 🌸', subtitle: 'تصفحوا أحدث الموديلات والطلب يوصل لباب البيت' },
      subscription: {
        plan: mini.pl || 'monthly',
        expires: mini.ex || '2027-12-31',
        graceDays: 3,
        maxProducts: Number(mini.mp || 0),
        suspended: Boolean(mini.sp),
        hideBranding: Boolean(mini.hb)
      },
      delivery: {
        default: Number(mini.dd || 5000),
        freeOver: 75000,
        provinces: { 'بغداد': Number(mini.db || 4000) }
      },
      payment: ['الدفع عند الاستلام', 'زين كاش (ZainCash)', 'سوبر كي (SuperQi)'],
      categories: JSON.parse(JSON.stringify(tpl.categories || [])),
      products: prods,
      coupons: [{ code: 'WELCOME10', type: 'percent', value: 10, active: true }],
      footerNote: 'جميع الطلبات تُفحص قبل الإرسال · الاستبدال متاح خلال 48 ساعة'
    };
  }

  function buildStoreFromToken(slug, tokenStr) {
    if (!tokenStr) {
      if (slug && SEEDED_STORES_META[slug] && slug !== 'lujain') {
        return buildStoreFromMiniObj(slug, SEEDED_STORES_META[slug]);
      }
      return null;
    }
    try {
      var b64 = tokenStr.replace(/-/g, '+').replace(/_/g, '/');
      while (b64.length % 4) b64 += '=';
      var mini = JSON.parse(decodeURIComponent(escape(atob(b64))));
      return buildStoreFromMiniObj(slug, mini);
    } catch (e) { return null; }
  }

  var urlParams = new URLSearchParams(location.search);
  var requestedSlug = urlParams.get('admin') || urlParams.get('store');
  var kToken = urlParams.get('k') || '';
  var isOwnerBypass = urlParams.get('owner') === '1';

  var baseStore = window.STORE || {};
  var masterStores = {};
  var agencyCfg = {};
  try { masterStores = JSON.parse(localStorage.getItem(MASTER_STORES_KEY) || '{}') || {}; } catch (e) { }
  try { agencyCfg = JSON.parse(localStorage.getItem(MASTER_CFG_KEY) || '{}') || {}; } catch (e) { }

  var SLUG = requestedSlug || baseStore.slug || 'lujain';
  var tokenStore = buildStoreFromToken(SLUG, kToken);

  if (requestedSlug && masterStores[requestedSlug]) {
    baseStore = masterStores[requestedSlug];
  } else if (tokenStore) {
    baseStore = tokenStore;
  } else if (masterStores[SLUG]) {
    var ms = masterStores[SLUG];
    baseStore = Object.assign({}, baseStore, ms, {
      products: (ms.products && ms.products.length) ? ms.products : baseStore.products,
      categories: (ms.categories && ms.categories.length) ? ms.categories : baseStore.categories
    });
  }

  if (!baseStore || !baseStore.name) {
    document.body.innerHTML = '<p style="padding:2rem;text-align:center">المتجر غير موجود.</p>';
    return;
  }

  var DATA_KEY = 'store_data_' + SLUG;
  var AUTH_KEY = 'store_auth_' + SLUG;

  var S = JSON.parse(JSON.stringify(baseStore));
  try {
    var saved = localStorage.getItem(DATA_KEY);
    if (saved) {
      var parsed = JSON.parse(saved);
      if (baseStore.subscription) parsed.subscription = baseStore.subscription;
      if (baseStore.poweredBy) parsed.poweredBy = baseStore.poweredBy;
      if (baseStore.adminPin) parsed.adminPin = baseStore.adminPin;
      S = Object.assign({}, S, parsed);
    } else if (tokenStore && kToken) {
      localStorage.setItem(DATA_KEY, JSON.stringify(S));
    }
  } catch (e) { }

  S.slug = SLUG;
  S.schemaVersion = '4.0.0';
  if (!S.adminPin) S.adminPin = '1234';
  if (!S.categories) S.categories = [];
  if (!S.products) S.products = [];
  if (!S.coupons) S.coupons = [];
  if (!S.delivery) S.delivery = { default: 5000, freeOver: 0, provinces: { 'بغداد': 4000 } };
  if (!S.delivery.provinces) S.delivery.provinces = { 'بغداد': 4000 };
  if (!S.payment) S.payment = ['الدفع عند الاستلام'];
  if (!S.theme) S.theme = { primary: '#7A4E2D', accent: '#C89B6E', bg: '#FAF7F2', text: '#1F1A17' };
  if (!S.hero) S.hero = { title: '', subtitle: '' };
  if (!S.subscription) S.subscription = { plan: 'monthly', expires: '2027-12-31', graceDays: 3 };

  var PLAN_LABELS = {
    trial: 'تجريبي',
    weekly: 'أسبوعي',
    monthly: 'شهري',
    yearly: 'سنوي',
    lifetime: 'دائمي مدى الحياة ♾️'
  };

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var fmt = function (n) { return Number(n || 0).toLocaleString('en-US') + ' ' + (S.currency || 'د.ع'); };

  var PROVINCES = ['بغداد', 'البصرة', 'نينوى', 'أربيل', 'السليمانية', 'دهوك', 'حلبجة', 'كركوك', 'الأنبار', 'بابل',
    'كربلاء', 'النجف', 'واسط', 'ذي قار', 'ميسان', 'المثنى', 'القادسية', 'ديالى', 'صلاح الدين'];

  var COLOR_PRESETS_DEFAULT = [
    { name: 'أسود ملكي', hex: '#1B1B1B' },
    { name: 'أبيض سكري', hex: '#FAF6F0' },
    { name: 'بيج نود', hex: '#D6B79E' },
    { name: 'كراميل', hex: '#A86532' },
    { name: 'ماروني', hex: '#641E16' },
    { name: 'أخضر زمردي', hex: '#145A32' },
    { name: 'كحلي غامق', hex: '#1B263B' },
    { name: 'وردي ناعم', hex: '#E8C5C8' },
    { name: 'ذهبي', hex: '#D4AF37' },
    { name: 'رصاصي', hex: '#9CA3AF' },
    { name: 'سمائي', hex: '#7DD3FC' },
    { name: 'زيتوني', hex: '#556B2F' }
  ];

  var BUILTIN_TYPE_PRESETS = {
    fashion: {
      title: 'أزياء متكامل (ملابس، أحذية، إكسسوارات)',
      sizePresets: [
        { label: 'قياسات ملابس بالأرقام (36 - 50)', sizes: ['36', '38', '40', '42', '44', '46', '48', '50'] },
        { label: 'قياسات عبايات وفساتين (50 - 60)', sizes: ['50', '52', '54', '56', '58', '60'] },
        { label: 'قياسات أحذية نسائية ورجالية (36 - 45)', sizes: ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45'] },
        { label: 'قياسات عالمية (XS - 3XL)', sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'] },
        { label: 'قياسات خواتم وإكسسوارات (15 - 21)', sizes: ['15', '16', '17', '18', '19', '20', '21'] },
        { label: 'قياسات أطفال بالسنوات (2 - 14)', sizes: ['2', '4', '6', '8', '10', '12', '14'] },
        { label: 'فري سايز (Free Size)', sizes: ['فري سايز'] }
      ],
      colorPresets: COLOR_PRESETS_DEFAULT
    },
    cosmetics: {
      title: 'كوزمتك وعطور وعناية',
      sizePresets: [
        { label: 'أحجام عطور (30 - 200 مل)', sizes: ['30 مل', '50 مل', '75 مل', '100 مل', '150 مل', '200 مل'] },
        { label: 'أحجام كريمات وسيروم (15 - 500 مل)', sizes: ['15 مل', '30 مل', '50 مل', '100 مل', '250 مل', '500 مل'] },
        { label: 'أوزان بودرة وعناية (50 - 500 غرام)', sizes: ['50 غرام', '100 غرام', '200 غرام', '500 غرام'] },
        { label: 'درجات فاونديشن وكونسيلر (01 - 06)', sizes: ['درجة 01 فاتح', 'درجة 02 طبيعي', 'درجة 03 بيج دافئ', 'درجة 04 حنطي', 'درجة 05 برونزي', 'درجة 06 عميق'] },
        { label: 'باكجات ومجموعات', sizes: ['قطعة مفردة', 'مجموعة ثنائية', 'مجموعة العناية الكاملة'] }
      ],
      colorPresets: [
        { name: 'وردي نود', hex: '#DDA7A5' },
        { name: 'أحمر مخملي', hex: '#9B1B30' },
        { name: 'خوخي ناعم', hex: '#F4A896' },
        { name: 'برونزي دافئ', hex: '#B87333' },
        { name: 'بيج طبيعي', hex: '#E5C29F' },
        { name: 'توتي عميق', hex: '#66023C' },
        { name: 'شفاف نقي', hex: '#F1F5F9' },
        { name: 'ذهبي لامع', hex: '#D4AF37' }
      ]
    },
    abaya: {
      title: 'عبايات وشالات خليجية',
      sizePresets: [
        { label: 'قياسات عبايات قياسية (50 - 62)', sizes: ['50', '52', '54', '56', '58', '60', '62'] },
        { label: 'أطوال بالأرقام (135 - 160 سم)', sizes: ['135', '140', '145', '150', '155', '160'] },
        { label: 'فري سايز / تفصيل خاص', sizes: ['فري سايز', 'تفصيل حسب القياس'] }
      ],
      colorPresets: COLOR_PRESETS_DEFAULT
    },
    sport: {
      title: 'ملابس وأحذية رياضية',
      sizePresets: [
        { label: 'ملابس رياضية (S - 3XL)', sizes: ['S', 'M', 'L', 'XL', 'XXL', '3XL'] },
        { label: 'أحذية رياضية بالأرقام (38 - 46)', sizes: ['38', '39', '40', '41', '42', '43', '44', '45', '46'] },
        { label: 'قياسات بناطيل بالأرقام (28 - 40)', sizes: ['28', '30', '32', '34', '36', '38', '40'] }
      ],
      colorPresets: COLOR_PRESETS_DEFAULT
    },
    shoes: {
      title: 'حقائب وأحذية جلدية',
      sizePresets: [
        { label: 'أحذية نسائية بالأرقام (35 - 42)', sizes: ['35', '36', '37', '38', '39', '40', '41', '42'] },
        { label: 'أحذية رجالية بالأرقام (39 - 46)', sizes: ['39', '40', '41', '42', '43', '44', '45', '46'] },
        { label: 'أحجام حقائب', sizes: ['ميني (Mini)', 'وسط (Medium)', 'كبير (Large)'] }
      ],
      colorPresets: COLOR_PRESETS_DEFAULT
    },
    watches: {
      title: 'ساعات وإكسسوارات وهدايا',
      sizePresets: [
        { label: 'قطر الساعة بالملم (28 - 44 مم)', sizes: ['28 مم', '32 مم', '36 مم', '40 مم', '42 مم', '44 مم'] },
        { label: 'قياسات خواتم وأساور بالأرقام (15 - 22)', sizes: ['15', '16', '17', '18', '19', '20', '21', '22'] },
        { label: 'بوكسات تغليف', sizes: ['مع علبة عادية', 'مع بوكس هدية ملكي VIP'] }
      ],
      colorPresets: [
        { name: 'ذهبي ملكي', hex: '#D4AF37' },
        { name: 'فضي ستيل', hex: '#C0C0C0' },
        { name: 'روز غولد', hex: '#B76E79' },
        { name: 'أسود مطفي', hex: '#1B1B1B' },
        { name: 'كحلي مينا', hex: '#1E3A8A' },
        { name: 'أخضر رولكس', hex: '#14532D' }
      ]
    }
  };

  function getActiveTypePresets() {
    var tid = S.templateId || 'fashion';
    var customTypes = {};
    try { customTypes = JSON.parse(localStorage.getItem('agency_store_types_v1') || '{}') || {}; } catch (e) { }
    var merged = Object.assign({}, BUILTIN_TYPE_PRESETS[tid] || BUILTIN_TYPE_PRESETS.fashion, customTypes[tid] || {});
    var sizes = (S.customSizePresets && S.customSizePresets.length) ? S.customSizePresets : (merged.sizePresets || BUILTIN_TYPE_PRESETS.fashion.sizePresets);
    var colors = (S.customColorPresets && S.customColorPresets.length) ? S.customColorPresets : (merged.colorPresets || COLOR_PRESETS_DEFAULT);
    return {
      typeId: tid,
      typeTitle: merged.title || tid,
      sizePresets: sizes,
      colorPresets: colors
    };
  }

  var THEMES = [
    { name: 'بني بوتيك دافئ', primary: '#7A4E2D', accent: '#C89B6E', bg: '#FAF7F2', text: '#1F1A17' },
    { name: 'أسود وذهبي ملكي', primary: '#1C1917', accent: '#D4AF37', bg: '#F8F7F4', text: '#18181B' },
    { name: 'وردي كوزمتك ناعم', primary: '#9D174D', accent: '#F472B6', bg: '#FFF5F7', text: '#1F1218' },
    { name: 'أخضر زمردي فخم', primary: '#14532D', accent: '#B48A3E', bg: '#F4F9F5', text: '#111C15' },
    { name: 'كحلي كلاسيك أنيق', primary: '#1E3A8A', accent: '#60A5FA', bg: '#F8FAFC', text: '#0F172A' },
    { name: 'ماروني شرقي', primary: '#641E16', accent: '#D4AC0D', bg: '#FDF8F5', text: '#211311' }
  ];

  function resolveRelUrl(relPath) {
    if (!relPath) return '';
    if (/^(https?:|data:|blob:|\/)/.test(relPath)) return relPath;
    if (location.pathname.indexOf('/stores/') !== -1 && relPath.indexOf('data/') === 0) {
      return '../../' + relPath;
    }
    return relPath;
  }

  /* ---------- حفظ البيانات ومزامنتها مع لوحة المالك المركزية ---------- */
  function saveStore(msg) {
    try {
      S._merchantEdited = true;
      localStorage.setItem(DATA_KEY, JSON.stringify(S));
      var allMaster = JSON.parse(localStorage.getItem(MASTER_STORES_KEY) || '{}') || {};
      if (allMaster[SLUG]) {
        allMaster[SLUG] = Object.assign({}, allMaster[SLUG], S);
        localStorage.setItem(MASTER_STORES_KEY, JSON.stringify(allMaster));
      }
    } catch (e) {
      if (window.UI) window.UI.alert('حجم الصور كبير جداً على ذاكرة المتصفح. يفضل حذف بعض الصور أو تصغيرها.', { title: 'تنبيه الذاكرة', type: 'warning' });
      else toast('حجم الصور كبير جداً على ذاكرة المتصفح');
      return;
    }
    if (S.theme && S.theme.primary) {
      document.documentElement.style.setProperty('--primary', S.theme.primary);
    }
    var fr = $('#liveFrame');
    if (fr && fr.contentWindow) fr.contentWindow.location.reload();
    pushStoreToCloud();
    if (msg) toast(msg);
  }

  /* ---------- المزامنة السحابية المجانية 100% (Google Apps Script / Live Server) ---------- */
  function pushStoreToCloud() {
    try {
      var cfg = JSON.parse(localStorage.getItem(MASTER_CFG_KEY) || '{}') || {};
      var targetUrl = cfg.cloudWriteUrl || ((location.protocol.indexOf('http') === 0) ? '/api/cloud' : '');
      if (targetUrl) {
        fetch(targetUrl, {
          method: 'POST',
          mode: cfg.cloudWriteUrl ? 'no-cors' : 'cors',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'saveStore', storeSlug: SLUG, slug: SLUG, store: S })
        }).catch(function () { });
      }
    } catch (e) { }
  }

  function toast(msg) {
    var t = $('#toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2400);
  }

  function compressImage(file, maxSide, quality, cb) {
    var reader = new FileReader();
    reader.onload = function (e) {
      var img = new Image();
      img.onload = function () {
        var w = img.width, h = img.height;
        if (w > maxSide || h > maxSide) {
          if (w > h) { h = Math.round(h * maxSide / w); w = maxSide; }
          else { w = Math.round(w * maxSide / h); h = maxSide; }
        }
        var canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        cb(canvas.toDataURL('image/jpeg', quality || 0.82));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  /* ---------- فحص حالة الاشتراك ---------- */
  function isLifetime() {
    var sub = S.subscription || {};
    return sub.plan === 'lifetime' || sub.expires === 'lifetime' || sub.expires === '9999-12-31';
  }
  function subDaysLeft() {
    if (isLifetime()) return Infinity;
    var sub = S.subscription || {};
    if (!sub.expires) return Infinity;
    var exp = new Date(sub.expires + 'T23:59:59');
    return isNaN(exp) ? Infinity : Math.ceil((exp - new Date()) / 86400000);
  }
  function isSubExpired() {
    var sub = S.subscription || {};
    if (sub.suspended) return true;
    if (isLifetime()) return false;
    var grace = Number(sub.graceDays || 0);
    return subDaysLeft() < -grace;
  }

  /* ---------- شاشة الدخول (PIN) ---------- */
  function checkAuth() {
    if (isOwnerBypass) {
      sessionStorage.setItem(AUTH_KEY, '1');
      renderDashboard();
      return;
    }
    if (isSubExpired()) {
      var agWa = String(agencyCfg.agencyWhatsapp || '9647700000000').replace(/\D/g, '');
      var renewMsg = 'مرحباً، أريد تجديد اشتراك متجر (' + S.name + ')';
      var zain = agencyCfg.zainCash ? '<li>زين كاش: <b dir="ltr">' + esc(agencyCfg.zainCash) + '</b></li>' : '';
      var qi = agencyCfg.superQi ? '<li>سوبر كي: <b dir="ltr">' + esc(agencyCfg.superQi) + '</b></li>' : '';
      document.getElementById('adminApp').innerHTML =
        '<div class="pin-screen"><div class="pin-card">' +
        '<div class="pin-logo">🔒</div>' +
        '<h2>' + esc(S.subscription.suspended ? 'المتجر موقوف من الإدارة' : 'انتهى اشتراك المتجر') + '</h2>' +
        '<p style="color:var(--muted);margin:10px 0 14px">' + esc(S.subscription.suspendReason || 'يرجى تجديد باقة الاشتراك لإعادة تفعيل المتجر ولوحة التحكم فوراً.') + '</p>' +
        ((zain || qi) ? '<ul style="list-style:none;background:#FFF8EB;padding:12px;border-radius:12px;margin-bottom:14px;font-size:0.9rem">' + zain + qi + '</ul>' : '') +
        '<a class="btn btn-primary btn-lg" style="width:100%" href="https://wa.me/' + agWa + '?text=' + encodeURIComponent(renewMsg) + '" target="_blank">💬 إرسال وصل التجديد عبر واتساب</a>' +
        '</div></div>';
      return;
    }
    if (sessionStorage.getItem(AUTH_KEY) === '1') {
      renderDashboard();
      return;
    }
    var storeHref = 'index.html' + (requestedSlug ? '?store=' + encodeURIComponent(requestedSlug) : '');
    document.getElementById('adminApp').innerHTML =
      '<div class="pin-screen"><form class="pin-card" id="pinForm">' +
      (S.logo ? '<img class="pin-logo" src="' + esc(S.logo) + '">' : '<div class="pin-logo">' + esc((S.name || 'م').charAt(0)) + '</div>') +
      '<h2>لوحة إدارة ' + esc(S.name) + '</h2>' +
      '<p style="color:var(--muted);font-size:0.9rem">أدخل الرمز السري لصاحب المتجر لإضافة وتعديل المنتجات</p>' +
      '<input class="pin-input" id="pinInp" type="password" inputmode="numeric" placeholder="••••" autocomplete="off" required>' +
      '<button class="btn btn-primary btn-lg" style="width:100%" type="submit">دخول للوحة التحكم</button>' +
      '<a href="' + storeHref + '" class="btn btn-ghost" style="width:100%;margin-top:8px">الرجوع للمتجر</a>' +
      (S.adminPin === '1234' ? '<div class="pin-hint">💡 الرمز السري الافتراضي للتجربة: <b>1234</b><br>(يمكنك تغييره من تبويب إعدادات المتجر)</div>' : '') +
      '</form></div>';

    $('#pinInp').focus();
    $('#pinForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var val = $('#pinInp').value.trim();
      if (val === String(S.adminPin)) {
        sessionStorage.setItem(AUTH_KEY, '1');
        renderDashboard();
      } else {
        if (window.UI) window.UI.alert('الرمز السري الذي أدخلته غير صحيح، يرجى المحاولة مرة أخرى.', { title: 'خطأ في الرمز السري', type: 'danger' });
        else toast('الرمز السري غير صحيح!');
        $('#pinInp').value = '';
        $('#pinInp').focus();
      }
    });
  }

  /* ---------- بناء لوحة التحكم الرئيسية ---------- */
  var uiState = { tab: 'products', q: '', cat: 'all', status: 'all', previewMode: 'full' };

  function getStoreHref() {
    var kPart = kToken ? '&k=' + encodeURIComponent(kToken) : '';
    if (location.pathname.indexOf('/stores/') !== -1) {
      return 'index.html?store=' + encodeURIComponent(SLUG) + kPart;
    }
    return '?store=' + encodeURIComponent(SLUG) + kPart;
  }

  function getOwnerHref() {
    if (location.pathname.indexOf('/stores/') !== -1) {
      return '../../index.html';
    }
    return location.pathname || './';
  }

  function getPublicStoreUrl() {
    var kPart = kToken ? '&k=' + encodeURIComponent(kToken) : '';
    var base = location.origin + location.pathname;
    if (location.pathname.indexOf('/stores/') !== -1) {
      return base.replace(/admin(\.html)?$/, 'index.html') + '?store=' + encodeURIComponent(SLUG) + kPart;
    }
    return base + '?store=' + encodeURIComponent(SLUG) + kPart;
  }

  var hdrScrollBound = false;

  function setModalOpen(isOpen) {
    var bg = $('#modalBg');
    if (bg) bg.classList.toggle('open', !!isOpen);
    document.body.classList.toggle('adm-modal-open', !!isOpen);
  }

  function triggerAddProduct() {
    var maxP = Number((S.subscription && S.subscription.maxProducts) || 0);
    if (maxP > 0 && S.products.length >= maxP && !isOwnerBypass) {
      if (window.UI) window.UI.alert('لقد وصلت للحد الأقصى للمنتجات المسموح في باقتك الحالية (' + maxP + ' منتج). يرجى ترقية باقتك لإضافة المزيد.', { title: 'الحد الأقصى للمنتجات', type: 'warning' });
      else toast('وصلت للحد الأقصى للمنتجات (' + maxP + ')');
      return;
    }
    openProductModal(null);
  }

  function renderDashboard() {
    if (S.theme && S.theme.primary) {
      document.documentElement.style.setProperty('--primary', S.theme.primary);
    }
    document.title = 'إدارة ' + S.name;
    document.body.setAttribute('data-adm-tab', uiState.tab);

    var sub = S.subscription || {};
    var planLabel = PLAN_LABELS[sub.plan || 'monthly'] || 'شهري';
    var dl = subDaysLeft();
    var subBadgeText = isLifetime() ? 'الباقة: دائمي مدى الحياة ♾️' :
      'الباقة: ' + planLabel + (dl !== Infinity ? ' (' + (dl >= 0 ? 'متبقي ' + dl + ' يوم' : 'متأخر ' + (-dl) + ' يوم') + ')' : '');

    var maxP = Number(sub.maxProducts || 0);
    var pCount = S.products.length;
    var capPct = maxP > 0 ? Math.min(100, Math.round((pCount / maxP) * 100)) : 100;
    var ringPct = isLifetime() ? 100 : (dl !== Infinity ? Math.max(5, Math.min(100, Math.round((Math.max(0, dl) / (sub.plan === 'yearly' ? 365 : 30)) * 100))) : 100);
    var ringLabel = isLifetime() ? '♾️' : (dl !== Infinity ? (dl >= 0 ? dl + 'ي' : '!') : '✓');

    var storeHref = getStoreHref();
    var agWa = String(agencyCfg.agencyWhatsapp || '9647700000000').replace(/\D/g, '');
    var upgMsg = 'مرحباً، أريد تجديد أو ترقية باقة متجر (' + S.name + ')';

    var html =
      (isOwnerBypass ? '<div class="owner-strip">👑 أنت تتصفح هذه اللوحة بصلاحية المالك الرئيسي للمشروع · <a href="' + getOwnerHref() + '">العودة للوحة القيادة المركزية</a></div>' : '') +
      '<header class="adm-hdr" id="admHdr"><div class="adm-hdr-in">' +
      '<div class="adm-brand">' +
      (S.logo ? '<img class="adm-logo" src="' + esc(S.logo) + '" alt="' + esc(S.name) + '">' :
        '<div class="adm-logo">' + esc((S.name || 'م').charAt(0)) + '</div>') +
      '<div class="adm-brand-txt"><h1>إدارة ' + esc(S.name) + '</h1><span><i class="live-dot"></i>متصل بالمتجر المباشر · حفظ تلقائي فوري</span></div></div>' +
      '<div class="adm-actions">' +
      '<button class="btn hdr-btn" id="qrShareBtn" title="رابط المتجر و QR">📱 <span class="lbl">رابط المتجر و QR</span></button>' +
      '</div></div></header>' +

      '<div class="sub-banner"><div class="sub-banner-in">' +
      '<div class="sub-info">' +
        '<div class="sub-ring" style="--p:' + ringPct + '"><b>' + esc(ringLabel) + '</b></div>' +
        '<div class="sub-meta">' +
          '<div class="sub-meta-top">' +
            '<span class="sub-pill ' + (isLifetime() ? 'life' : '') + '">' + esc(subBadgeText) + '</span>' +
          '</div>' +
          '<div class="sub-cap">' +
            '<span>سعة المنتجات: <b>' + pCount + (maxP ? ' / ' + maxP : ' (غير محدود)') + '</b></span>' +
            (maxP ? '<div class="sub-cap-bar"><i style="width:' + capPct + '%"></i></div>' : '') +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="sub-cta">' +
      (!isLifetime() ? '<a class="btn btn-sm btn-upgrade" href="https://wa.me/' + agWa + '?text=' + encodeURIComponent(upgMsg) + '" target="_blank">💎 تجديد أو ترقية للباقة السنوية / الدائمية</a>' : '<span class="life-note">✨ متجرك مفعل مدى الحياة بدون اشتراكات</span>') +
      '</div></div></div>' +

      '<nav class="adm-tabs" id="admTabs"><div class="adm-tabs-in">' +
      '<button class="adm-tab ' + (uiState.tab === 'products' ? 'on' : '') + '" data-t="products">' +
        '<span class="adm-tab-ico">📦</span>' +
        '<span class="lbl-full">المنتجات</span><span class="lbl-short">المنتجات</span>' +
        '<span class="adm-tab-count">' + pCount + (maxP ? '/' + maxP : '') + '</span>' +
      '</button>' +
      '<button class="adm-tab ' + (uiState.tab === 'cats' ? 'on' : '') + '" data-t="cats">' +
        '<span class="adm-tab-ico">🗂️</span>' +
        '<span class="lbl-full">الأقسام</span><span class="lbl-short">الأقسام</span>' +
        '<span class="adm-tab-count">' + S.categories.length + '</span>' +
      '</button>' +
      '<button class="adm-tab ' + (uiState.tab === 'store' ? 'on' : '') + '" data-t="store">' +
        '<span class="adm-tab-ico">🛍️</span>' +
        '<span class="lbl-full">المتجر</span><span class="lbl-short">المتجر</span>' +
      '</button>' +
      '<button class="adm-tab ' + (uiState.tab === 'delivery' ? 'on' : '') + '" data-t="delivery">' +
        '<span class="adm-tab-ico">🚚</span>' +
        '<span class="lbl-full">التوصيل والدفع</span><span class="lbl-short">التوصيل</span>' +
      '</button>' +
      '<button class="adm-tab ' + (uiState.tab === 'settings' ? 'on' : '') + '" data-t="settings">' +
        '<span class="adm-tab-ico">🎨</span>' +
        '<span class="lbl-full">هوية المتجر والألوان</span><span class="lbl-short">الهوية</span>' +
      '</button>' +
      '</div></nav>' +

      '<div class="adm-wrap">' +
        '<main id="admMain" style="display:' + (uiState.tab === 'store' ? 'none' : 'block') + '"></main>' +
        '<section id="admStoreView" class="adm-store-view" style="display:' + (uiState.tab === 'store' ? 'block' : 'none') + '">' +
          '<div class="store-preview-card">' +
            '<div class="spc-bar">' +
              '<div class="spc-info">' +
                '<span class="spc-dot"></span>' +
                '<div>' +
                  '<b>🛍️ معاينة داخلية حية لـ ' + esc(S.name) + '</b>' +
                  '<span>تصفح المتجر والأقسام والمنتجات مباشرة دون الانتقال خارج لوحة الإدارة</span>' +
                '</div>' +
              '</div>' +
              '<div class="spc-controls">' +
                '<div class="spc-mode-seg" id="spcModeSeg">' +
                  '<button type="button" class="spc-mode-btn ' + (uiState.previewMode !== 'phone' ? 'on' : '') + '" data-pmode="full">🖥️ عرض كامل</button>' +
                  '<button type="button" class="spc-mode-btn ' + (uiState.previewMode === 'phone' ? 'on' : '') + '" data-pmode="phone">📱 عرض الهاتف</button>' +
                '</div>' +
                '<button type="button" class="btn btn-sm btn-tinted" id="spcReloadBtn">🔄 تحديث المعاينة</button>' +
              '</div>' +
            '</div>' +
            '<div class="spc-stage ' + (uiState.previewMode === 'phone' ? 'is-phone' : 'is-full') + '" id="spcStage">' +
              '<iframe id="liveFrame" src="' + storeHref + '" title="معاينة المتجر الداخلية"></iframe>' +
            '</div>' +
          '</div>' +
        '</section>' +
      '</div>' +

      '<button type="button" class="adm-fab" id="admFabBtn"><span class="plus">＋</span><span>إضافة منتج</span></button>' +

      '<div class="modal-bg" id="modalBg"><div class="modal" id="modalBox"></div></div>' +
      '<div class="toast" id="toast"></div>';

    document.getElementById('adminApp').innerHTML = html;

    if (!hdrScrollBound) {
      hdrScrollBound = true;
      window.addEventListener('scroll', function () {
        var h = document.getElementById('admHdr');
        if (h) h.classList.toggle('scrolled', window.scrollY > 10);
      }, { passive: true });
    }

    $('#admTabs').addEventListener('click', function (e) {
      var b = e.target.closest('.adm-tab');
      if (!b) return;
      uiState.tab = b.getAttribute('data-t');
      document.body.setAttribute('data-adm-tab', uiState.tab);
      $$('.adm-tab').forEach(function (x) { x.classList.toggle('on', x === b); });
      renderCurrentTab();
    });

    var modeSeg = $('#spcModeSeg');
    if (modeSeg) {
      modeSeg.addEventListener('click', function (e) {
        var mb = e.target.closest('.spc-mode-btn');
        if (!mb) return;
        uiState.previewMode = mb.getAttribute('data-pmode') || 'full';
        $$('#spcModeSeg .spc-mode-btn').forEach(function (x) { x.classList.toggle('on', x === mb); });
        var stg = $('#spcStage');
        if (stg) {
          stg.classList.toggle('is-phone', uiState.previewMode === 'phone');
          stg.classList.toggle('is-full', uiState.previewMode !== 'phone');
        }
      });
    }

    var reloadBtn = $('#spcReloadBtn');
    if (reloadBtn) {
      reloadBtn.addEventListener('click', function () {
        var fr = $('#liveFrame');
        if (fr && fr.contentWindow) {
          fr.contentWindow.location.reload();
          toast('تم تحديث المعاينة الداخلية للمتجر ✓');
        }
      });
    }

    $('#modalBg').addEventListener('click', function (e) {
      if (e.target === $('#modalBg')) setModalOpen(false);
    });

    $('#admFabBtn').addEventListener('click', triggerAddProduct);
    $('#qrShareBtn').addEventListener('click', openQrModal);
    renderCurrentTab();
    if (window.UI && window.UI.upgradeIcons) window.UI.upgradeIcons(document.body);
  }

  function openQrModal() {
    var box = $('#modalBox');
    var storeUrl = getPublicStoreUrl();
    var qrImg = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' + encodeURIComponent(storeUrl);
    box.innerHTML =
      '<div class="modal-hdr"><span class="modal-grabber"></span><h3>📱 رابط المتجر وباركود QR</h3><button class="btn btn-sm btn-ghost" id="qClose">✕ إغلاق</button></div>' +
      '<div class="modal-body" style="text-align:center">' +
        '<div class="m-sec" style="padding:22px 16px">' +
          '<img src="' + qrImg + '" alt="QR" style="width:184px;height:184px;border-radius:22px;border:1px solid var(--border);padding:12px;background:#fff;box-shadow:var(--shadow)">' +
          '<h3 style="margin:12px 0 4px;font-weight:900">' + esc(S.name) + '</h3>' +
          '<p class="hint" style="margin-bottom:14px">انسخ الرابط المختصر أدناه وضعه في بايو صفحة الإنستغرام أو التيك توك أو الواتساب</p>' +
          '<input id="qUrlInp" class="inp" dir="ltr" readonly value="' + esc(storeUrl) + '" style="text-align:center;margin-bottom:12px">' +
          '<button class="btn btn-primary btn-lg btn-block" id="qCopyBtn">📋 نسخ رابط المتجر</button>' +
        '</div>' +
      '</div>';
    setModalOpen(true);
    $('#qClose').onclick = function () { setModalOpen(false); };
    $('#qCopyBtn').onclick = function () {
      navigator.clipboard.writeText($('#qUrlInp').value);
      toast('تم نسخ رابط المتجر ✓');
    };
    if (window.UI && window.UI.upgradeIcons) window.UI.upgradeIcons(box);
  }

  function renderCurrentTab() {
    var mainEl = $('#admMain');
    var storeEl = $('#admStoreView');
    if (uiState.tab === 'store') {
      if (mainEl) mainEl.style.display = 'none';
      if (storeEl) storeEl.style.display = 'block';
      return;
    }
    if (storeEl) storeEl.style.display = 'none';
    if (mainEl) mainEl.style.display = 'block';

    if (uiState.tab === 'products') renderProductsTab();
    else if (uiState.tab === 'cats') renderCatsTab();
    else if (uiState.tab === 'delivery') renderDeliveryTab();
    else if (uiState.tab === 'settings') renderSettingsTab();
    if (window.UI && window.UI.upgradeIcons) window.UI.upgradeIcons(mainEl);
  }

  /* =========================================================
     تبويب 1: إدارة المنتجات
     ========================================================= */
  function renderProductsTab() {
    var total = S.products.length;
    var maxP = Number((S.subscription && S.subscription.maxProducts) || 0);
    var soldCount = S.products.filter(function (p) { return p.soldOut; }).length;
    var hidCount = S.products.filter(function (p) { return p.hidden; }).length;
    var availCount = Math.max(0, total - soldCount - hidCount);

    var html =
      '<div class="stats-row" id="admStatsRow">' +
      '<div class="stat-box ' + (uiState.status === 'all' ? 'on' : '') + '" data-st-filter="all" style="--sc:var(--primary);--sb:var(--primary-soft)">' +
        '<div class="stat-ico">📦</div>' +
        '<div><b>' + total + (maxP ? ' / ' + maxP : '') + '</b><span>إجمالي المنتجات</span></div>' +
      '</div>' +
      '<div class="stat-box ' + (uiState.status === 'avail' ? 'on' : '') + '" data-st-filter="avail" style="--sc:var(--ok);--sb:var(--ok-soft)">' +
        '<div class="stat-ico">✅</div>' +
        '<div><b style="color:var(--ok)">' + availCount + '</b><span>متوفر للطلب</span></div>' +
      '</div>' +
      '<div class="stat-box ' + (uiState.status === 'sold' ? 'on' : '') + '" data-st-filter="sold" style="--sc:var(--danger);--sb:var(--danger-soft)">' +
        '<div class="stat-ico">🔴</div>' +
        '<div><b style="color:var(--danger)">' + soldCount + '</b><span>نفذت الكمية</span></div>' +
      '</div>' +
      '<div class="stat-box ' + (uiState.status === 'hidden' ? 'on' : '') + '" data-st-filter="hidden" style="--sc:var(--muted);--sb:var(--fill)">' +
        '<div class="stat-ico">🙈</div>' +
        '<div><b style="color:var(--muted)">' + hidCount + '</b><span>مخفي مؤقتاً</span></div>' +
      '</div>' +
      '</div>' +

      '<div class="card">' +
      '<div class="card-h">' +
      '<h2>📦 قائمة المنتجات</h2>' +
      '<button class="btn btn-primary btn-lg add-prod-btn" id="addProdBtn">+ إضافة منتج جديد</button>' +
      '</div>' +

      '<div class="filter-bar">' +
      '<div class="search-box"><span class="search-ico">🔍</span><input id="pSearch" type="search" placeholder="ابحث باسم المنتج أو القسم..." value="' + esc(uiState.q) + '"></div>' +
      '<select id="pCatFilter"><option value="all">كل الأقسام</option>' +
      S.categories.map(function (c) { return '<option value="' + esc(c) + '"' + (uiState.cat === c ? ' selected' : '') + '>' + esc(c) + '</option>'; }).join('') +
      '</select>' +
      '<select id="pStatusFilter">' +
      '<option value="all"' + (uiState.status === 'all' ? ' selected' : '') + '>كل الحالات</option>' +
      '<option value="avail"' + (uiState.status === 'avail' ? ' selected' : '') + '>المتوفر فقط</option>' +
      '<option value="sold"' + (uiState.status === 'sold' ? ' selected' : '') + '>نفذت الكمية</option>' +
      '<option value="hidden"' + (uiState.status === 'hidden' ? ' selected' : '') + '>المخفي</option>' +
      '</select>' +
      '</div>' +

      '<div class="p-list" id="pList"></div>' +
      '</div>';

    $('#admMain').innerHTML = html;

    $('#addProdBtn').addEventListener('click', triggerAddProduct);
    $('#admStatsRow').addEventListener('click', function (e) {
      var sb = e.target.closest('.stat-box[data-st-filter]');
      if (!sb) return;
      uiState.status = sb.getAttribute('data-st-filter') || 'all';
      var sel = $('#pStatusFilter');
      if (sel) sel.value = uiState.status;
      $$('#admStatsRow .stat-box').forEach(function (x) { x.classList.toggle('on', x === sb); });
      renderProductRows();
    });
    $('#pSearch').addEventListener('input', function (e) { uiState.q = e.target.value; renderProductRows(); });
    $('#pCatFilter').addEventListener('change', function (e) { uiState.cat = e.target.value; renderProductRows(); });
    $('#pStatusFilter').addEventListener('change', function (e) {
      uiState.status = e.target.value;
      $$('#admStatsRow .stat-box').forEach(function (x) {
        x.classList.toggle('on', x.getAttribute('data-st-filter') === uiState.status);
      });
      renderProductRows();
    });

    renderProductRows();
  }

  function renderProductRows() {
    var q = uiState.q.trim().toLowerCase();
    var list = S.products.filter(function (p) {
      if (uiState.cat !== 'all' && p.category !== uiState.cat) return false;
      if (uiState.status === 'avail' && (p.soldOut || p.hidden)) return false;
      if (uiState.status === 'sold' && !p.soldOut) return false;
      if (uiState.status === 'hidden' && !p.hidden) return false;
      if (q && (p.name + ' ' + (p.category || '') + ' ' + (p.desc || '')).toLowerCase().indexOf(q) === -1) return false;
      return true;
    });

    var box = $('#pList');
    if (!list.length) {
      box.innerHTML = '<div class="empty-state"><div class="empty-ico">📦</div>لا توجد منتجات مطابقة حالياً.<br>اضغط على زر <b>+ إضافة منتج</b> لإضافة أول قطعة!</div>';
      if (window.UI && window.UI.upgradeIcons) window.UI.upgradeIcons(box);
      return;
    }

    box.innerHTML = list.map(function (p) {
      var idx = S.products.indexOf(p);
      var img = (p.images && p.images[0]) ? resolveRelUrl(p.images[0]) : '';
      return '<div class="p-row ' + (p.hidden ? 'is-hidden' : '') + '" data-id="' + esc(p.id) + '">' +
        (img ? '<img class="p-row-img" src="' + esc(img) + '" onerror="this.style.opacity=0.2">' : '<div class="p-row-img" style="display:grid;place-items:center;font-weight:800">' + esc((p.name || '؟').charAt(0)) + '</div>') +
        '<div class="p-row-body">' +
          '<div class="p-row-title">' +
            '<span class="p-name">' + esc(p.name) + '</span>' +
          '</div>' +
          '<div class="p-row-tags">' +
            (p.soldOut ? '<span class="tag tag-sold">نفذت الكمية</span>' : '<span class="tag tag-ok">متوفر</span>') +
            (p.hidden ? '<span class="tag tag-hid">مخفي عن الزبائن</span>' : '') +
            (p.badge ? '<span class="tag tag-badge">' + esc(p.badge) + '</span>' : '') +
            (p.videoUrl ? '<span class="tag tag-video">🎬 فيديو</span>' : '') +
          '</div>' +
          '<div class="p-row-meta">' +
            '<b>' + fmt(p.price) + '</b>' +
            (p.oldPrice && p.oldPrice > p.price ? ' <s>' + fmt(p.oldPrice) + '</s>' : '') +
            '<span>· ' + esc(p.category || 'بدون قسم') + '</span>' +
            (p.sizes && p.sizes.length ? '<span>· المقاسات: ' + esc(p.sizes.join(', ')) + '</span>' : '') +
            (p.colors && p.colors.length ? '<span>· الألوان: ' + p.colors.length + '</span>' : '') +
          '</div>' +
        '</div>' +
        '<div class="p-row-actions">' +
          '<button class="btn btn-sm btn-primary" data-act="edit" title="تعديل المنتج">✏️ <span class="lbl">تعديل</span></button>' +
          '<button class="btn btn-sm btn-ghost" data-act="sold" title="' + (p.soldOut ? 'إرجاع متوفر' : 'تعليم نفذت الكمية') + '">' + (p.soldOut ? '✅ <span class="lbl">إرجاع متوفر</span>' : '🔴 <span class="lbl">نفذت الكمية</span>') + '</button>' +
          '<button class="btn btn-sm btn-ghost" data-act="hide" title="' + (p.hidden ? 'إظهار في المتجر' : 'إخفاء مؤقتاً') + '">' + (p.hidden ? '👁️ <span class="lbl">إظهار</span>' : '🙈 <span class="lbl">إخفاء</span>') + '</button>' +
          '<button class="btn btn-sm btn-ghost" data-act="dup" title="تكرار المنتج">📑 <span class="lbl">تكرار</span></button>' +
          (idx > 0 ? '<button class="btn btn-sm btn-ghost" data-act="up" title="تحريك للأعلى">⬆️</button>' : '') +
          (idx < S.products.length - 1 ? '<button class="btn btn-sm btn-ghost" data-act="down" title="تحريك للأسفل">⬇️</button>' : '') +
          '<button class="btn btn-sm btn-danger" data-act="del" title="حذف المنتج">🗑️ <span class="lbl">حذف</span></button>' +
        '</div>' +
        '</div>';
    }).join('');

    if (window.UI && window.UI.upgradeIcons) window.UI.upgradeIcons(box);

    box.onclick = function (e) {
      var btn = e.target.closest('button[data-act]');
      if (!btn) return;
      var row = btn.closest('.p-row');
      var id = row.getAttribute('data-id');
      var idx = S.products.findIndex(function (x) { return x.id === id; });
      if (idx === -1) return;
      var p = S.products[idx];
      var act = btn.getAttribute('data-act');

      if (act === 'edit') {
        openProductModal(p);
      } else if (act === 'sold') {
        p.soldOut = !p.soldOut;
        saveStore(p.soldOut ? 'تم تعليم المنتج: نفذت الكمية' : 'تم تفعيل المنتج كمتوفر ✓');
        renderProductsTab();
      } else if (act === 'hide') {
        p.hidden = !p.hidden;
        saveStore(p.hidden ? 'تم إخفاء المنتج عن الزبائن' : 'تم إظهار المنتج في المتجر ✓');
        renderProductsTab();
      } else if (act === 'dup') {
        var maxP = Number((S.subscription && S.subscription.maxProducts) || 0);
        if (maxP > 0 && S.products.length >= maxP && !isOwnerBypass) {
          if (window.UI) window.UI.alert('وصلت للحد الأقصى للمنتجات المسموح في باقتك (' + maxP + ').', { title: 'الحد الأقصى للمنتجات', type: 'warning' });
          else toast('وصلت للحد الأقصى للمنتجات');
          return;
        }
        var copy = JSON.parse(JSON.stringify(p));
        copy.id = 'p-' + Date.now();
        copy.name = p.name + ' (نسخة)';
        S.products.splice(idx + 1, 0, copy);
        saveStore('تم تكرار المنتج ✓');
        renderDashboard();
      } else if (act === 'up' && idx > 0) {
        var tmp = S.products[idx - 1];
        S.products[idx - 1] = S.products[idx];
        S.products[idx] = tmp;
        saveStore('تم تحديث الترتيب ✓');
        renderProductRows();
      } else if (act === 'down' && idx < S.products.length - 1) {
        var tmp2 = S.products[idx + 1];
        S.products[idx + 1] = S.products[idx];
        S.products[idx] = tmp2;
        saveStore('تم تحديث الترتيب ✓');
        renderProductRows();
      } else if (act === 'del') {
        var doDel = function () {
          S.products.splice(idx, 1);
          saveStore('تم حذف المنتج');
          renderDashboard();
        };
        if (window.UI) {
          window.UI.confirm('هل أنت متأكد من حذف المنتج "' + p.name + '" نهائياً من المتجر؟', {
            title: 'تأكيد حذف المنتج',
            type: 'danger',
            okText: 'نعم، احذف المنتج',
            cancelText: 'تراجع'
          }).then(function (ok) { if (ok) doDel(); });
        } else {
          doDel();
        }
      }
    };
  }

  /* =========================================================
     نافذة إضافة / تعديل المنتج بالتفصيل الكامل
     ========================================================= */
  function openProductModal(prod) {
    var isNew = !prod;
    var draft = prod ? JSON.parse(JSON.stringify(prod)) : {
      id: 'p-' + Date.now(),
      name: '',
      category: S.categories[0] || 'عام',
      price: '',
      oldPrice: '',
      badge: '',
      videoUrl: '',
      images: [],
      sizes: [],
      colors: [],
      desc: '',
      soldOut: false,
      hidden: false
    };
    if (!draft.images) draft.images = [];
    if (!draft.sizes) draft.sizes = [];
    if (!draft.colors) draft.colors = [];

    var box = $('#modalBox');
    var activeTypePresets = getActiveTypePresets();
    var SIZE_PRESETS = activeTypePresets.sizePresets;
    var COLOR_PRESETS = activeTypePresets.colorPresets;

    var html =
      '<div class="modal-hdr">' +
      '<span class="modal-grabber"></span>' +
      '<h3>' + (isNew ? '➕ إضافة منتج جديد' : '✏️ تعديل: ' + esc(draft.name)) + '</h3>' +
      '<button class="btn btn-sm btn-ghost" id="mClose">✕ إغلاق</button>' +
      '</div>' +

      '<div class="modal-body">' +

      '<div class="fld"><span>1. صور المنتج (ارفع صورة أو عدة صور من الموبايل / الحاسبة)</span>' +
      '<div class="img-uploader">' +
      '<input type="file" id="mImgFile" accept="image/*" multiple style="display:none">' +
      '<button type="button" class="btn btn-primary" id="mPickImg">📷 اختر صور من جهازك / الموبايل</button>' +
      '<p class="hint" style="margin-top:6px">يتم ضغط الصور تلقائياً لتعمل بسرعة فائقة على هواتف الزبائن</p>' +
      '<div class="inline-row">' +
      '<input id="mImgUrl" placeholder="أو الصق رابط صورة مباشر (اختياري)..." dir="ltr">' +
      '<button type="button" class="btn btn-tinted btn-sm" id="mAddUrl">+ إضافة الرابط</button>' +
      '</div>' +
      '<div class="img-thumbs" id="mThumbs"></div>' +
      '</div></div>' +

      '<div class="form-grid">' +
      '<label class="fld"><span>2. اسم المنتج *</span><input id="mName" value="' + esc(draft.name) + '" placeholder="مثال: عباية ملكية سوداء بتطريز ذهبي"></label>' +
      '<label class="fld"><span>القسم *</span>' +
      '<select id="mCatSelect">' +
      S.categories.map(function (c) { return '<option value="' + esc(c) + '"' + (draft.category === c ? ' selected' : '') + '>' + esc(c) + '</option>'; }).join('') +
      '<option value="__new__">+ كتابة قسم جديد...</option>' +
      '</select>' +
      '<input id="mCatNew" placeholder="اكتب اسم القسم الجديد" style="display:none;margin-top:6px">' +
      '</label>' +
      '</div>' +

      '<div class="form-grid">' +
      '<label class="fld"><span>3. السعر الحالي (' + esc(S.currency || 'د.ع') + ') *</span><input id="mPrice" type="number" inputmode="numeric" value="' + esc(draft.price) + '" placeholder="مثال: 35000"></label>' +
      '<label class="fld"><span>السعر قبل الخصم (اختياري) <em id="mDiscPreview" style="color:var(--danger);font-style:normal"></em></span><input id="mOldPrice" type="number" inputmode="numeric" value="' + esc(draft.oldPrice || '') + '" placeholder="مثال: 45000"></label>' +
      '</div>' +

      '<div class="fld"><span>4. شارة مميزة فوق صورة المنتج (اختياري)</span>' +
      '<input id="mBadge" value="' + esc(draft.badge || '') + '" placeholder="مثال: الأكثر طلباً / جديد / كمية محدودة">' +
      '<div class="presets" id="mBadgePresets">' +
      ['بدون شارة', 'جديد ✨', 'الأكثر طلباً 🔥', 'كمية محدودة ⚡', 'عرض خاص 🎁', 'خامة أصلية 💎'].map(function (b) {
        return '<button type="button" class="preset-btn" data-b="' + (b === 'بدون شارة' ? '' : b) + '">' + b + '</button>';
      }).join('') +
      '</div></div>' +

      '<label class="fld"><span>🎬 رابط فيديو للمنتج (اختياري — ريلز إنستغرام، تيك توك، يوتيوب...)</span>' +
      '<input id="mVideoUrl" dir="ltr" value="' + esc(draft.videoUrl || '') + '" placeholder="https://www.instagram.com/reel/... أو https://www.tiktok.com/...">' +
      '<small class="hint">عند إضافة الرابط يظهر زر فيديو أنيق على المنتج يحوّل الزبون مباشرة لمشاهدة الفيديو في مكانه الأصلي</small>' +
      '</label>' +

      '<div class="fld"><span>5. المقاسات المتوفرة — <small style="color:var(--primary);font-weight:800">قوالب نوع المتجر: ' + esc(activeTypePresets.typeTitle) + '</small></span>' +
      '<div class="presets" id="mSizePresets">' +
      SIZE_PRESETS.map(function (sp, i) {
        return '<button type="button" class="preset-btn" data-sp="' + i + '">+ ' + esc(sp.label) + '</button>';
      }).join('') +
      '<button type="button" class="preset-btn" data-sp="clear" style="color:var(--danger)">مسح كل المقاسات (منتج بدون مقاس)</button>' +
      '</div>' +
      '<div class="inline-row">' +
      '<input id="mSizeInp" placeholder="أو اكتب مقاساً مخصصاً (مثل: 42 أو XL) واضغط إضافة">' +
      '<button type="button" class="btn btn-tinted btn-sm" id="mSizeAdd">+ إضافة مقاس</button>' +
      '</div>' +
      '<div class="chips-box" id="mSizesBox"></div>' +
      '</div>' +

      '<div class="fld"><span>6. الألوان المتوفرة (اضغط على أي لون لإضافته فوراً، أو اختر لوناً خاصاً)</span>' +
      '<div class="color-palette" id="mColorPalette">' +
      COLOR_PRESETS.map(function (c, i) {
        return '<button type="button" class="c-dot" data-cp="' + i + '"><i style="background:' + c.hex + '"></i>' + c.name + '</button>';
      }).join('') +
      '</div>' +
      '<div class="inline-row" style="margin-top:6px">' +
      '<input type="color" id="mColorHex" value="#7A4E2D" style="width:46px;height:42px;flex-shrink:0">' +
      '<input id="mColorName" placeholder="اسم اللون (مثال: بيج فاتح)">' +
      '<button type="button" class="btn btn-tinted btn-sm" id="mColorAdd">+ إضافة اللون</button>' +
      '</div>' +
      '<div class="chips-box" id="mColorsBox"></div>' +
      '</div>' +

      '<label class="fld"><span>7. وصف المنتج وتفاصيل القماش / الموديل</span>' +
      '<textarea id="mDesc" rows="3" placeholder="اكتب تفاصيل المنتج التي تهم الزبون...">' + esc(draft.desc || '') + '</textarea>' +
      '</label>' +

      '<div class="m-sec">' +
        '<div class="switch-list">' +
          '<label class="ios-switch-row"><span>🔴 تعليم المنتج كـ "نفذت الكمية"</span><input type="checkbox" class="ios-switch" id="mSoldOut"' + (draft.soldOut ? ' checked' : '') + '></label>' +
          '<label class="ios-switch-row"><span>🙈 إخفاء المنتج مؤقتاً عن الزبائن</span><input type="checkbox" class="ios-switch" id="mHidden"' + (draft.hidden ? ' checked' : '') + '></label>' +
        '</div>' +
      '</div>' +

      '</div>' +

      '<div class="modal-ftr">' +
      '<button type="button" class="btn btn-ghost" id="mCancel">إلغاء</button>' +
      '<button type="button" class="btn btn-primary btn-lg" id="mSave">✅ حفظ المنتج ونشره في المتجر</button>' +
      '</div>';

    box.innerHTML = html;
    setModalOpen(true);
    if (window.UI && window.UI.upgradeIcons) window.UI.upgradeIcons(box);

    function renderThumbs() {
      var tBox = $('#mThumbs');
      if (!draft.images.length) {
        tBox.innerHTML = '<span style="font-size:0.82rem;color:var(--muted);margin:auto">لم تتم إضافة صور بعد</span>';
        return;
      }
      tBox.innerHTML = draft.images.map(function (src, i) {
        return '<div class="thumb"><img src="' + esc(src) + '">' +
          '<button type="button" data-del="' + i + '" title="حذف الصورة">×</button>' +
          (i === 0 ? '<span class="main-lbl">الرئيسية</span>' : '<span class="main-lbl" style="cursor:pointer;background:var(--primary)" data-main="' + i + '">اجعلها رئيسية</span>') +
          '</div>';
      }).join('');
    }
    renderThumbs();

    $('#mThumbs').addEventListener('click', function (e) {
      var del = e.target.closest('button[data-del]');
      if (del) {
        draft.images.splice(Number(del.getAttribute('data-del')), 1);
        renderThumbs();
        return;
      }
      var mkMain = e.target.closest('[data-main]');
      if (mkMain) {
        var idx = Number(mkMain.getAttribute('data-main'));
        var item = draft.images.splice(idx, 1)[0];
        draft.images.unshift(item);
        renderThumbs();
      }
    });

    $('#mPickImg').addEventListener('click', function () { $('#mImgFile').click(); });
    $('#mImgFile').addEventListener('change', function (e) {
      var files = Array.prototype.slice.call(e.target.files || []);
      files.forEach(function (f) {
        compressImage(f, 760, 0.82, function (dataUrl) {
          draft.images.push(dataUrl);
          renderThumbs();
        });
      });
      e.target.value = '';
    });

    $('#mAddUrl').addEventListener('click', function () {
      var u = $('#mImgUrl').value.trim();
      if (!u) return;
      draft.images.push(u);
      $('#mImgUrl').value = '';
      renderThumbs();
    });

    $('#mCatSelect').addEventListener('change', function (e) {
      $('#mCatNew').style.display = e.target.value === '__new__' ? 'block' : 'none';
      if (e.target.value === '__new__') $('#mCatNew').focus();
    });

    function updDisc() {
      var p = Number($('#mPrice').value) || 0;
      var o = Number($('#mOldPrice').value) || 0;
      $('#mDiscPreview').textContent = (o > p && p > 0) ? '(خصم ' + Math.round((1 - p / o) * 100) + '%)' : '';
    }
    $('#mPrice').addEventListener('input', updDisc);
    $('#mOldPrice').addEventListener('input', updDisc);
    updDisc();

    $('#mBadgePresets').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-b]');
      if (b) $('#mBadge').value = b.getAttribute('data-b');
    });

    function renderSizes() {
      var sb = $('#mSizesBox');
      if (!draft.sizes.length) {
        sb.innerHTML = '<span style="font-size:0.8rem;color:var(--muted)">بدون مقاسات (الزبون يطلب مباشرة بدون اختيار مقاس)</span>';
        return;
      }
      sb.innerHTML = draft.sizes.map(function (s, i) {
        return '<span class="chip-item">' + esc(s) + '<button type="button" data-sdel="' + i + '">×</button></span>';
      }).join('');
    }
    renderSizes();

    $('#mSizesBox').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-sdel]');
      if (b) { draft.sizes.splice(Number(b.getAttribute('data-sdel')), 1); renderSizes(); }
    });
    $('#mSizePresets').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-sp]');
      if (!b) return;
      var v = b.getAttribute('data-sp');
      if (v === 'clear') { draft.sizes = []; renderSizes(); return; }
      var preset = SIZE_PRESETS[Number(v)];
      if (preset) {
        preset.sizes.forEach(function (s) { if (draft.sizes.indexOf(s) === -1) draft.sizes.push(s); });
        renderSizes();
      }
    });
    function addCustomSize() {
      var v = $('#mSizeInp').value.trim();
      if (!v) return;
      v.split(',').map(function (x) { return x.trim(); }).filter(Boolean).forEach(function (s) {
        if (draft.sizes.indexOf(s) === -1) draft.sizes.push(s);
      });
      $('#mSizeInp').value = '';
      renderSizes();
    }
    $('#mSizeAdd').addEventListener('click', addCustomSize);
    $('#mSizeInp').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); addCustomSize(); } });

    function renderColors() {
      var cb = $('#mColorsBox');
      if (!draft.colors.length) {
        cb.innerHTML = '<span style="font-size:0.8rem;color:var(--muted)">بدون ألوان متعددة</span>';
        return;
      }
      cb.innerHTML = draft.colors.map(function (c, i) {
        return '<span class="chip-item"><i style="background:' + esc(c.hex) + '"></i>' + esc(c.name) + '<button type="button" data-cdel="' + i + '">×</button></span>';
      }).join('');
    }
    renderColors();

    $('#mColorsBox').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-cdel]');
      if (b) { draft.colors.splice(Number(b.getAttribute('data-cdel')), 1); renderColors(); }
    });
    $('#mColorPalette').addEventListener('click', function (e) {
      var b = e.target.closest('button[data-cp]');
      if (!b) return;
      var c = COLOR_PRESETS[Number(b.getAttribute('data-cp'))];
      if (c && !draft.colors.some(function (x) { return x.name === c.name; })) {
        draft.colors.push({ name: c.name, hex: c.hex });
        renderColors();
      }
    });
    $('#mColorAdd').addEventListener('click', function () {
      var name = $('#mColorName').value.trim();
      var hex = $('#mColorHex').value;
      if (!name) {
        if (window.UI) window.UI.alert('يرجى كتابة اسم اللون أولاً قبل إضافته.', { title: 'تنبيه', type: 'warning' });
        else toast('اكتب اسم اللون أولاً');
        return;
      }
      draft.colors.push({ name: name, hex: hex });
      $('#mColorName').value = '';
      renderColors();
    });

    var closeModal = function () { setModalOpen(false); };
    $('#mClose').addEventListener('click', closeModal);
    $('#mCancel').addEventListener('click', closeModal);

    $('#mSave').addEventListener('click', function () {
      var name = $('#mName').value.trim();
      var price = Number($('#mPrice').value);
      if (!name) {
        if (window.UI) window.UI.alert('يرجى كتابة اسم المنتج قبل الحفظ.', { title: 'حقل مطلوب', type: 'warning' });
        else toast('يرجى كتابة اسم المنتج');
        $('#mName').focus();
        return;
      }
      if (!price || price <= 0) {
        if (window.UI) window.UI.alert('يرجى كتابة سعر صحيح للمنتج أكبر من صفر.', { title: 'حقل مطلوب', type: 'warning' });
        else toast('يرجى كتابة سعر المنتج');
        $('#mPrice').focus();
        return;
      }

      var cat = $('#mCatSelect').value;
      if (cat === '__new__') {
        cat = $('#mCatNew').value.trim() || 'عام';
      }
      if (cat && S.categories.indexOf(cat) === -1) {
        S.categories.push(cat);
      }

      draft.name = name;
      draft.category = cat;
      draft.price = price;
      var oldP = Number($('#mOldPrice').value);
      if (oldP > price) draft.oldPrice = oldP; else delete draft.oldPrice;
      draft.badge = $('#mBadge').value.trim();
      var vUrl = ($('#mVideoUrl') ? $('#mVideoUrl').value.trim() : '');
      if (vUrl) draft.videoUrl = vUrl; else delete draft.videoUrl;
      draft.desc = $('#mDesc').value.trim();
      draft.soldOut = $('#mSoldOut').checked;
      draft.hidden = $('#mHidden').checked;

      if (isNew) {
        S.products.unshift(draft);
      } else {
        var idx = S.products.findIndex(function (x) { return x.id === draft.id; });
        if (idx !== -1) S.products[idx] = draft;
      }

      closeModal();
      saveStore(isNew ? 'تمت إضافة المنتج بنجاح 🎉' : 'تم حفظ تعديلات المنتج ✓');
      renderDashboard();
    });
  }

  /* =========================================================
     تبويب 2: إدارة الأقسام
     ========================================================= */
  function renderCatsTab() {
    var html =
      '<div class="card">' +
      '<div class="card-h"><h2>🗂️ أقسام المتجر</h2></div>' +
      '<p class="card-sub">الأقسام تظهر كأزرار فلترة ناعمة أعلى المتجر لتسهيل تصفح الزبائن.</p>' +
      '<div class="inline-row" style="margin-bottom:18px">' +
      '<input id="newCatInp" class="inp" placeholder="اسم القسم الجديد (مثال: تخفيضات الموسم)">' +
      '<button class="btn btn-primary" id="addCatBtn">+ إضافة قسم</button>' +
      '</div>' +
      '<div class="p-list">' +
      S.categories.map(function (c, i) {
        var count = S.products.filter(function (p) { return p.category === c; }).length;
        return '<div class="p-row simple-row">' +
          '<div class="simple-row-main">' +
            '<div class="simple-row-ico">' + (i + 1) + '</div>' +
            '<div class="simple-row-txt"><b>' + esc(c) + '</b><span>' + count + ' منتج مرتبط بهذا القسم</span></div>' +
          '</div>' +
          '<div class="p-row-actions">' +
            '<button class="btn btn-sm btn-ghost" data-cact="ren" data-i="' + i + '">✏️ تغيير الاسم</button>' +
            (i > 0 ? '<button class="btn btn-sm btn-ghost" data-cact="up" data-i="' + i + '" title="للأعلى">⬆️</button>' : '') +
            (i < S.categories.length - 1 ? '<button class="btn btn-sm btn-ghost" data-cact="down" data-i="' + i + '" title="للأسفل">⬇️</button>' : '') +
            '<button class="btn btn-sm btn-danger" data-cact="del" data-i="' + i + '">🗑️ حذف</button>' +
          '</div></div>';
      }).join('') +
      '</div></div>';

    $('#admMain').innerHTML = html;

    var addCat = function () {
      var v = $('#newCatInp').value.trim();
      if (!v) return;
      if (S.categories.indexOf(v) === -1) {
        S.categories.push(v);
        saveStore('تمت إضافة القسم ✓');
        renderDashboard();
      }
    };
    $('#addCatBtn').addEventListener('click', addCat);
    $('#newCatInp').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); addCat(); } });

    $('#admMain').onclick = function (e) {
      var b = e.target.closest('button[data-cact]');
      if (!b) return;
      var i = Number(b.getAttribute('data-i'));
      var act = b.getAttribute('data-cact');
      var oldName = S.categories[i];

      if (act === 'ren') {
        var applyRename = function (nw) {
          if (nw && nw.trim() && nw.trim() !== oldName) {
            nw = nw.trim();
            S.categories[i] = nw;
            S.products.forEach(function (p) { if (p.category === oldName) p.category = nw; });
            saveStore('تم تحديث اسم القسم في جميع المنتجات ✓');
            renderCatsTab();
          }
        };
        if (window.UI) {
          window.UI.prompt('أدخل الاسم الجديد للقسم:', oldName, {
            title: 'تعديل اسم القسم',
            okText: 'حفظ الاسم الجديد'
          }).then(applyRename);
        }
      } else if (act === 'up' && i > 0) {
        var t = S.categories[i - 1]; S.categories[i - 1] = S.categories[i]; S.categories[i] = t;
        saveStore('تم تغيير الترتيب ✓'); renderCatsTab();
      } else if (act === 'down' && i < S.categories.length - 1) {
        var t2 = S.categories[i + 1]; S.categories[i + 1] = S.categories[i]; S.categories[i] = t2;
        saveStore('تم تغيير الترتيب ✓'); renderCatsTab();
      } else if (act === 'del') {
        var doDelCat = function () {
          S.categories.splice(i, 1);
          saveStore('تم حذف القسم');
          renderDashboard();
        };
        if (window.UI) {
          window.UI.confirm('هل أنت متأكد من حذف قسم "' + oldName + '" من قائمة الأقسام؟', {
            title: 'حذف القسم',
            type: 'danger',
            okText: 'نعم، احذف القسم'
          }).then(function (ok) { if (ok) doDelCat(); });
        } else {
          doDelCat();
        }
      }
    };
  }

  /* =========================================================
     تبويب 3: التوصيل وطرق الدفع
     ========================================================= */
  function renderDeliveryTab() {
    var d = S.delivery || {};
    var provs = d.provinces || {};
    var allPays = ['الدفع عند الاستلام', 'زين كاش (ZainCash)', 'سوبر كي (SuperQi)', 'ماستر كارد الرافدين', 'تحويل FIB'];

    var html =
      '<div class="card">' +
      '<div class="card-h"><h2>🚚 أسعار التوصيل للمحافظات</h2></div>' +
      '<p class="card-sub">حدد أجور التوصيل لبغداد والمحافظات ومبلغ التوصيل المجاني.</p>' +
      '<div class="form-grid">' +
      '<label class="fld"><span>سعر توصيل بغداد (' + esc(S.currency || 'د.ع') + ')</span><input id="dBgw" type="number" inputmode="numeric" value="' + esc(provs['بغداد'] != null ? provs['بغداد'] : 4000) + '"></label>' +
      '<label class="fld"><span>سعر توصيل باقي المحافظات الافتراضي</span><input id="dDef" type="number" inputmode="numeric" value="' + esc(d.default != null ? d.default : 5000) + '"></label>' +
      '<label class="fld"><span>توصيل مجاني للطلبات فوق مبلغ (ضع 0 لإلغائه)</span><input id="dFree" type="number" inputmode="numeric" value="' + esc(d.freeOver || 0) + '"></label>' +
      '</div>' +

      '<details class="soft-details">' +
      '<summary>📍 تخصيص سعر توصيل لمحافظات محددة (اختياري)</summary>' +
      '<div class="form-grid" style="margin-top:8px">' +
      PROVINCES.filter(function (p) { return p !== 'بغداد'; }).map(function (p) {
        return '<label class="fld"><span>' + p + '</span><input class="prov-fee" data-p="' + p + '" type="number" inputmode="numeric" placeholder="' + (d.default || 5000) + '" value="' + (provs[p] != null ? provs[p] : '') + '"></label>';
      }).join('') +
      '</div></details>' +

      '<div class="card-h" style="margin-top:18px;margin-bottom:10px"><h2>💳 طرق الدفع المتاحة للزبون</h2></div>' +
      '<div class="switch-list" style="margin-bottom:18px">' +
      allPays.map(function (pm) {
        var on = (S.payment || []).indexOf(pm) !== -1;
        return '<label class="ios-switch-row">' +
          '<span>' + esc(pm) + '</span>' +
          '<input type="checkbox" class="ios-switch pay-chk" value="' + esc(pm) + '"' + (on ? ' checked' : '') + '></label>';
      }).join('') +
      '</div>' +

      '<div class="actions-row">' +
      '<button class="btn btn-primary btn-lg" id="saveDelBtn">✅ حفظ إعدادات التوصيل والدفع</button>' +
      '</div>' +
      '</div>';

    $('#admMain').innerHTML = html;

    $('#saveDelBtn').addEventListener('click', function () {
      var newProvs = { 'بغداد': Number($('#dBgw').value) || 0 };
      $$('.prov-fee').forEach(function (inp) {
        if (inp.value.trim() !== '') newProvs[inp.getAttribute('data-p')] = Number(inp.value);
      });
      S.delivery = {
        default: Number($('#dDef').value) || 0,
        freeOver: Number($('#dFree').value) || 0,
        provinces: newProvs
      };
      var selectedPays = $$('.pay-chk:checked').map(function (c) { return c.value; });
      S.payment = selectedPays.length ? selectedPays : ['الدفع عند الاستلام'];
      saveStore('تم حفظ إعدادات التوصيل والدفع ✓');
    });
  }

  /* =========================================================
     تبويب 4: هوية المتجر والألوان والرمز السري
     ========================================================= */
  function renderSettingsTab() {
    var html =
      '<div class="card">' +
      '<div class="card-h"><h2>🎨 هوية المتجر والمظهر</h2></div>' +
      '<p class="card-sub">خصّص شعار المتجر، الألوان، وروابط حسابات التواصل الاجتماعي الخاصة بك.</p>' +

      '<div class="fld"><span>شعار المتجر (Logo)</span>' +
      '<div class="logo-row">' +
      (S.logo ? '<img id="sLogoPrev" class="logo-prev" src="' + esc(S.logo) + '" alt="logo">' :
        '<div id="sLogoPrev" class="logo-prev">' + esc((S.name || 'م').charAt(0)) + '</div>') +
      '<input type="file" id="sLogoFile" accept="image/*" style="display:none">' +
      '<button type="button" class="btn btn-tinted btn-sm" id="sPickLogo">📷 رفع شعار من الموبايل / الحاسبة</button>' +
      (S.logo ? '<button type="button" class="btn btn-danger btn-sm" id="sDelLogo">🗑️ حذف الشعار</button>' : '') +
      '</div></div>' +

      '<div class="form-grid">' +
      '<label class="fld"><span>اسم المتجر / البيج</span><input id="sName" value="' + esc(S.name) + '"></label>' +
      '<label class="fld"><span>وصف قصير تحت الاسم</span><input id="sTag" value="' + esc(S.tagline || '') + '"></label>' +
      '<label class="fld"><span>رقم واتساب استلام الطلبات (مع 964)</span><input id="sWa" dir="ltr" inputmode="tel" value="' + esc(S.whatsapp || '') + '"></label>' +
      '<label class="fld"><span>يوزر أو رابط إنستغرام</span><input id="sIg" dir="ltr" value="' + esc((S.socials && S.socials.instagram) || S.instagram || '') + '" placeholder="@page أو الرابط"></label>' +
      '<label class="fld"><span>رابط صفحة فيسبوك</span><input id="sFb" dir="ltr" value="' + esc((S.socials && S.socials.facebook) || S.facebook || '') + '" placeholder="https://facebook.com/..."></label>' +
      '<label class="fld"><span>رابط أو معرف قناة تلجرام</span><input id="sTg" dir="ltr" value="' + esc((S.socials && S.socials.telegram) || S.telegram || '') + '" placeholder="https://t.me/..."></label>' +
      '<label class="fld"><span>رابط أو يوزر تيك توك</span><input id="sTk" dir="ltr" value="' + esc((S.socials && S.socials.tiktok) || S.tiktok || '') + '" placeholder="@tiktok"></label>' +
      '<label class="fld"><span>رابط قناة واتساب</span><input id="sWac" dir="ltr" value="' + esc((S.socials && S.socials.whatsappChannel) || S.whatsappChannel || '') + '" placeholder="https://whatsapp.com/channel/..."></label>' +
      '</div>' +

      '<label class="fld"><span>شريط الإعلان العلوي المتحرك (اتركه فارغاً لإخفائه)</span><input id="sAnn" value="' + esc(S.announcement || '') + '"></label>' +

      '<div class="form-grid">' +
      '<label class="fld"><span>عنوان البنر الترحيبي</span><input id="sHeroT" value="' + esc((S.hero && S.hero.title) || '') + '"></label>' +
      '<label class="fld"><span>النص الفرعي للبنر</span><input id="sHeroS" value="' + esc((S.hero && S.hero.subtitle) || '') + '"></label>' +
      '</div>' +

      '<label class="fld"><span>ملاحظة أسفل المتجر (سياسة الاستبدال والفحص)</span><input id="sFooter" value="' + esc(S.footerNote || '') + '"></label>' +

      '<div class="fld"><span>ثيم وألوان المتجر (اضغط لاختيار ثيم جاهز)</span>' +
      '<div class="themes-grid" id="sThemes">' +
      THEMES.map(function (t, i) {
        var on = S.theme && S.theme.primary === t.primary;
        return '<div class="theme-card ' + (on ? 'on' : '') + '" data-ti="' + i + '">' +
          '<div class="theme-swatches"><span style="background:' + t.primary + '"></span><span style="background:' + t.accent + '"></span></div>' +
          '<span>' + t.name + '</span></div>';
      }).join('') +
      '</div>' +
      '<div class="inline-row" style="margin-top:8px">' +
      '<label style="font-size:0.85rem;font-weight:800">أو اختر لوناً مخصصاً:</label>' +
      '<input type="color" id="sCustomColor" value="' + esc((S.theme && S.theme.primary) || '#7A4E2D') + '" style="width:52px;height:40px">' +
      '</div></div>' +

      '<div class="form-grid" style="margin-top:14px">' +
      '<label class="fld"><span>🔑 الرمز السري لدخول لوحة التحكم (PIN)</span><input id="sPin" dir="ltr" inputmode="numeric" value="' + esc(S.adminPin || '1234') + '"></label>' +
      '</div>' +

      '<div class="actions-row" style="margin-top:16px">' +
      '<button class="btn btn-primary btn-lg" id="saveSetBtn">✅ حفظ إعدادات المتجر</button>' +
      '<button class="btn btn-danger" id="resetOrigBtn">🔄 استعادة الإعدادات الأصلية للمتجر</button>' +
      '</div>' +
      '</div>';

    $('#admMain').innerHTML = html;

    $('#sPickLogo').addEventListener('click', function () { $('#sLogoFile').click(); });
    $('#sLogoFile').addEventListener('change', function (e) {
      var f = (e.target.files || [])[0];
      if (!f) return;
      compressImage(f, 300, 0.85, function (dataUrl) {
        S.logo = dataUrl;
        saveStore('تم تحديث شعار المتجر ✓');
        renderDashboard();
      });
    });
    var delLogo = $('#sDelLogo');
    if (delLogo) delLogo.addEventListener('click', function () {
      delete S.logo;
      saveStore('تم حذف الشعار');
      renderDashboard();
    });

    $('#sThemes').addEventListener('click', function (e) {
      var tc = e.target.closest('.theme-card');
      if (!tc) return;
      var t = THEMES[Number(tc.getAttribute('data-ti'))];
      if (t) {
        S.theme = { primary: t.primary, accent: t.accent, bg: t.bg, text: t.text };
        document.documentElement.style.setProperty('--primary', t.primary);
        $('#sCustomColor').value = t.primary;
        saveStore('تم تطبيق ثيم: ' + t.name + ' 🎨');
        renderSettingsTab();
      }
    });

    $('#sCustomColor').addEventListener('change', function (e) {
      S.theme.primary = e.target.value;
      document.documentElement.style.setProperty('--primary', e.target.value);
      saveStore('تم تغيير اللون الرئيسي ✓');
    });

    $('#saveSetBtn').addEventListener('click', function () {
      S.name = $('#sName').value.trim() || S.name;
      S.tagline = $('#sTag').value.trim();
      var wa = $('#sWa').value.replace(/\D/g, '');
      if (wa.startsWith('07')) wa = '964' + wa.slice(1);
      S.whatsapp = wa;
      S.instagram = $('#sIg').value.trim();
      S.facebook = ($('#sFb') ? $('#sFb').value.trim() : '');
      S.telegram = ($('#sTg') ? $('#sTg').value.trim() : '');
      S.tiktok = ($('#sTk') ? $('#sTk').value.trim() : '');
      S.whatsappChannel = ($('#sWac') ? $('#sWac').value.trim() : '');
      S.socials = {
        instagram: S.instagram,
        facebook: S.facebook,
        telegram: S.telegram,
        tiktok: S.tiktok,
        whatsappChannel: S.whatsappChannel
      };
      S.announcement = $('#sAnn').value.trim();
      S.hero = { title: $('#sHeroT').value.trim(), subtitle: $('#sHeroS').value.trim() };
      S.footerNote = $('#sFooter').value.trim();
      S.adminPin = $('#sPin').value.trim() || '1234';
      saveStore('تم حفظ هوية المتجر وروابط التواصل الاجتماعي ✓');
      renderDashboard();
    });

    $('#resetOrigBtn').addEventListener('click', function () {
      var doReset = function () {
        localStorage.removeItem(DATA_KEY);
        location.reload();
      };
      if (window.UI) {
        window.UI.confirm('هل تريد مسح التعديلات المحفوظة في المتصفح والعودة لملف الإعدادات الأصلي؟', {
          title: 'استعادة الإعدادات الأصلية',
          type: 'warning',
          okText: 'نعم، استعد الأصلية'
        }).then(function (ok) { if (ok) doReset(); });
      } else {
        doReset();
      }
    });
  }

  async function exportConfigFile() {
    var content = '/* =========================================================\n' +
      '   ملف إعدادات المتجر — تم التحديث من لوحة التحكم\n' +
      '   ========================================================= */\n' +
      'window.STORE = ' + JSON.stringify(S, null, 2) + ';\n';

    if (window.showSaveFilePicker) {
      try {
        var handle = await window.showSaveFilePicker({
          suggestedName: 'config.js',
          types: [{ description: 'JavaScript Config', accept: { 'application/javascript': ['.js'] } }]
        });
        var writable = await handle.createWritable();
        await writable.write(content);
        await writable.close();
        toast('تم حفظ ملف config.js مباشرة بنجاح! ✅');
        return;
      } catch (err) {
        if (err && err.name === 'AbortError') return;
      }
    }

    var blob = new Blob([content], { type: 'application/javascript;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'config.js';
    a.click();
    toast('تم تنزيل ملف config.js المحدّث ✓');
  }

  function loadSourceStoreIfNeeded() {
    if (S._merchantEdited) return;
    var srcUrl = resolveRelUrl('data/source/' + encodeURIComponent(SLUG) + '.json');
    fetch(srcUrl)
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data || !data.name) return;
        if (masterStores && masterStores[SLUG]) {
          var ms = masterStores[SLUG];
          if (ms.name) data.name = ms.name;
          if (ms.logo) data.logo = ms.logo;
          if (ms.templateId) data.templateId = ms.templateId;
          if (ms.whatsapp) data.whatsapp = ms.whatsapp;
          if (ms.instagram) data.instagram = ms.instagram;
          if (ms.socials) data.socials = Object.assign({}, data.socials || {}, ms.socials);
          if (ms.subscription) data.subscription = ms.subscription;
          if (ms.adminPin) data.adminPin = ms.adminPin;
          if (ms.customSizePresets) data.customSizePresets = ms.customSizePresets;
          if (ms.customColorPresets) data.customColorPresets = ms.customColorPresets;
        }
        S = Object.assign({}, S, data);
        checkAuth();
      })
      .catch(function () { });
  }

  checkAuth();
  loadSourceStoreIfNeeded();
})();
