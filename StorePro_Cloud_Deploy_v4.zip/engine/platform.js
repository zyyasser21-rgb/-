/* =========================================================================
   محرك منصة إدارة المتاجر المركزية — Central Platform Engine v6.5 (Apple Edition)
   • تصميم مستوحى من أنظمة أبل (Cupertino Smooth UI)
   • خالٍ تماماً من نوافذ المتصفح التقليدية
   ========================================================================= */
(function () {
  'use strict';
  if (window.__TENANT_MODE__) return;

  var MASTER_STORES_KEY = 'agency_master_stores_v1';
  var MASTER_CFG_KEY = 'agency_master_config_v1';
  var MASTER_PAYMENTS_KEY = 'agency_master_payments_v1';
  var MASTER_PLANS_KEY = 'agency_master_plans_v1';
  var STORE_TYPES_KEY = 'agency_store_types_v1';
  var SNAPSHOTS_KEY = 'agency_backup_snapshots_v1';
  var SESSION_UNLOCK_KEY = 'agency_platform_unlocked_v1';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var fmt = function (n) { return Number(n || 0).toLocaleString('en-US') + ' د.ع'; };
  var todayISO = function () { return new Date().toISOString().slice(0, 10); };
  var addDaysISO = function (days) {
    var d = new Date();
    d.setDate(d.getDate() + Number(days || 0));
    return d.toISOString().slice(0, 10);
  };

  /* ---------- لوحة ألوان مميزة ومستقلة للباقات (تمنع ظهور الرسم الدائري بلون واحد) ---------- */
  var PLAN_PALETTE = ['#4F46E5', '#10B981', '#0EA5E9', '#F59E0B', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];

  var DEFAULT_PLANS = {
    trial: {
      id: 'trial', name: 'الباقة التجريبية', icon: '🧪', color: '#F59E0B',
      price: 0, days: 4, maxProducts: 20, isRecurring: false,
      features: ['صالحة لمدة 4 أيام للتجربة', 'حتى 20 منتج كحد أقصى', 'ربط الطلبات عبر واتساب', 'تصميم متجاوب للهواتف']
    },
    weekly: {
      id: 'weekly', name: 'الباقة الأسبوعية', icon: '📅', color: '#0EA5E9',
      price: 5000, days: 7, maxProducts: 40, isRecurring: true,
      features: ['تفعيل لمدة 7 أيام كاملة', 'حتى 40 منتج في المتجر', 'كوبونات خصم للزبائن', 'زر تابعنا الدوّار لمنصات التواصل']
    },
    monthly: {
      id: 'monthly', name: 'الباقة الشهرية', icon: '🌟', color: '#4F46E5',
      price: 15000, days: 30, maxProducts: 150, isRecurring: true,
      features: ['تفعيل لمدة 30 يوماً', 'حتى 150 منتج مع تقسيم ذكي', 'كوبونات خصم وإحصائيات', 'دعم فني وتحديثات مجانية']
    },
    yearly: {
      id: 'yearly', name: 'الباقة السنوية VIP', icon: '👑', color: '#10B981',
      price: 125000, days: 365, maxProducts: 0, isRecurring: true,
      features: ['تفعيل لمدة سنة كاملة (365 يوماً)', 'عدد منتجات غير محدود ♾️', 'إخفاء شعار المنصة أسفل المتجر', 'أولوية قصوى في الدعم الفني']
    },
    lifetime: {
      id: 'lifetime', name: 'الباقة الدائمية مدى الحياة', icon: '♾️', color: '#8B5CF6',
      price: 250000, days: 36500, maxProducts: 0, isLifetime: true,
      features: ['تفعيل أبدي مدى الحياة بدون تجديد', 'عدد منتجات وأقسام غير محدود ♾️', 'إخفاء حقوق المنصة بالكامل', 'جميع الميزات المستقبلية مجاناً']
    }
  };

  var DEFAULT_COLORS = [
    { name: 'أسود ملكي', hex: '#1B1B1B' },
    { name: 'أبيض سكري', hex: '#FAF6F0' },
    { name: 'بيج نود', hex: '#D6B79E' },
    { name: 'كراميل', hex: '#A86532' },
    { name: 'ماروني', hex: '#641E16' },
    { name: 'أخضر زمردي', hex: '#145A32' },
    { name: 'كحلي غامق', hex: '#1B263B' },
    { name: 'وردي ناعم', hex: '#E8C5C8' },
    { name: 'ذهبي', hex: '#D4AF37' },
    { name: 'رصاصي', hex: '#9CA3AF' },
    { name: 'سمائي', hex: '#7DD3FC' },
    { name: 'زيتوني', hex: '#556B2F' }
  ];

  var DEFAULT_STORE_TYPES = {
    fashion: {
      id: 'fashion',
      title: 'أزياء متكامل (ملابس، أحذية، إكسسوارات)',
      shortTitle: 'أزياء متكامل',
      icon: '👗',
      color: '#7A4E2D',
      tagline: 'أزياء راقية · أحذية · إكسسوارات · توصيل لكل المحافظات',
      categories: ['عبايات', 'فساتين', 'أطقم كاجوال', 'قمصان وبلوزات', 'أحذية', 'حقائب', 'إكسسوارات'],
      sizePresets: [
        { label: 'قياسات الملابس بالأرقام (36 - 50)', sizes: ['36', '38', '40', '42', '44', '46', '48', '50'] },
        { label: 'قياسات العبايات والفساتين (50 - 60)', sizes: ['50', '52', '54', '56', '58', '60'] },
        { label: 'قياسات الأحذية النسائية والرجالية (36 - 45)', sizes: ['36', '37', '38', '39', '40', '41', '42', '43', '44', '45'] },
        { label: 'قياسات عالمية بالحروف (XS - 3XL)', sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'] },
        { label: 'قياسات الخواتم والإكسسوارات بالأرقام (15 - 21)', sizes: ['15', '16', '17', '18', '19', '20', '21'] },
        { label: 'قياسات الأطفال بالسنوات (2 - 14)', sizes: ['2', '4', '6', '8', '10', '12', '14'] },
        { label: 'فري سايز (Free Size)', sizes: ['فري سايز'] }
      ],
      colorPresets: JSON.parse(JSON.stringify(DEFAULT_COLORS))
    },
    cosmetics: {
      id: 'cosmetics',
      title: 'كوزمتك وعطور وعناية بالبشرة',
      shortTitle: 'كوزمتك وعناية',
      icon: '💄',
      color: '#9D174D',
      tagline: 'عطور أصلية · عناية بالبشرة · مكياج ومستحضرات تجميل',
      categories: ['عطور نسائية', 'عطور رجالية', 'عناية بالبشرة', 'مكياج', 'عناية بالشعر', 'مجموعات هدايا'],
      sizePresets: [
        { label: 'أحجام العطور بالملي (30 - 200 مل)', sizes: ['30 مل', '50 مل', '75 مل', '100 مل', '150 مل', '200 مل'] },
        { label: 'أحجام الكريمات والسيرومات (15 - 500 مل)', sizes: ['15 مل', '30 مل', '50 مل', '100 مل', '250 مل', '500 مل'] },
        { label: 'أوزان العناية والماسكات (50 - 500 غرام)', sizes: ['50 غرام', '100 غرام', '200 غرام', '500 غرام'] },
        { label: 'درجات البشرة والفاونديشن (01 - 06)', sizes: ['درجة 01 فاتح', 'درجة 02 طبيعي', 'درجة 03 بيج دافئ', 'درجة 04 حنطي', 'درجة 05 برونزي', 'درجة 06 عميق'] },
        { label: 'مجموعات وباكجات', sizes: ['قطعة مفردة', 'مجموعة ثنائية', 'مجموعة العناية الكاملة'] }
      ],
      colorPresets: [
        { name: 'وردي نود', hex: '#DDA7A5' },
        { name: 'أحمر مخملي', hex: '#9B1B30' },
        { name: 'خوخي ناعم', hex: '#F4A896' },
        { name: 'برونزي دافئ', hex: '#B87333' },
        { name: 'بيج طبيعي', hex: '#E5C29F' },
        { name: 'توتي عميق', hex: '#66023C' },
        { name: 'ذهبي لامع', hex: '#D4AF37' }
      ]
    },
    abaya: {
      id: 'abaya',
      title: 'دار عبايات وشالات خليجية',
      shortTitle: 'عبايات وشالات',
      icon: '🖤',
      color: '#1C1917',
      tagline: 'عبايات خليجية فاخرة · شالات · تفصيل حسب الطلب',
      categories: ['عبايات سوداء', 'عبايات ملونة', 'عبايات مناسبات', 'شالات وحجابات'],
      sizePresets: [
        { label: 'قياسات العبايات بالأرقام (50 - 62)', sizes: ['50', '52', '54', '56', '58', '60', '62'] },
        { label: 'الأطوال بالسنتيمتر (135 - 160 سم)', sizes: ['135', '140', '145', '150', '155', '160'] },
        { label: 'فري سايز / تفصيل خاص', sizes: ['فري سايز', 'تفصيل حسب القياس'] }
      ],
      colorPresets: JSON.parse(JSON.stringify(DEFAULT_COLORS))
    },
    sport: {
      id: 'sport',
      title: 'ملابس وأحذية وتجهيزات رياضية',
      shortTitle: 'ملابس رياضية',
      icon: '👟',
      color: '#1E3A8A',
      tagline: 'تراكسوتات · كاجوال · أحذية وتجهيزات رياضية',
      categories: ['تراكسوتات', 'تيشيرتات', 'بناطيل كاجوال', 'أحذية رياضية', 'إكسسوارات رياضية'],
      sizePresets: [
        { label: 'قياسات رياضية (S - 3XL)', sizes: ['S', 'M', 'L', 'XL', 'XXL', '3XL'] },
        { label: 'أحذية رياضية بالأرقام (38 - 46)', sizes: ['38', '39', '40', '41', '42', '43', '44', '45', '46'] },
        { label: 'قياسات البناطيل بالأرقام (28 - 40)', sizes: ['28', '30', '32', '34', '36', '38', '40'] }
      ],
      colorPresets: JSON.parse(JSON.stringify(DEFAULT_COLORS))
    },
    watches: {
      id: 'watches',
      title: 'ساعات ومجوهرات وهدايا فاخرة',
      shortTitle: 'ساعات وإكسسوارات',
      icon: '⌚',
      color: '#0F172A',
      tagline: 'ساعات أصلية · مجوهرات وإكسسوارات · بوكسات هدايا',
      categories: ['ساعات نسائية', 'ساعات رجالية', 'إكسسوارات ومجوهرات', 'بوكسات هدايا'],
      sizePresets: [
        { label: 'قطر الساعة بالملم (28 - 44 مم)', sizes: ['28 مم', '32 مم', '36 مم', '40 مم', '42 مم', '44 مم'] },
        { label: 'قياسات الخواتم والأساور بالأرقام (15 - 22)', sizes: ['15', '16', '17', '18', '19', '20', '21', '22'] },
        { label: 'خيارات التغليف', sizes: ['علبة قياسية', 'بوكس هدية ملكي VIP'] }
      ],
      colorPresets: [
        { name: 'ذهبي ملكي', hex: '#D4AF37' },
        { name: 'فضي ستيل', hex: '#C0C0C0' },
        { name: 'روز غولد', hex: '#B76E79' },
        { name: 'أسود مطفي', hex: '#1B1B1B' },
        { name: 'كحلي مينا', hex: '#1E3A8A' }
      ]
    }
  };

  var DEFAULT_LOCK_REASONS = [
    'انتهاء فترة الاشتراك وعدم التجديد في الموعد المحدد',
    'مخالفة شروط وسياسات استخدام المنصة',
    'المتجر في وضع الصيانة والتحديث المؤقت بناءً على طلب التاجر',
    'مراجعة البيانات المالية وتأكيد وصل الدفع',
    'تجاوز الحد المسموح للطلبات أو البيانات'
  ];

  /* ---------- حالة المنصة والبيانات ---------- */
  var masterStores = {};
  var masterPlans = {};
  var storeTypes = {};
  var payments = [];
  var cfg = {};
  var snapshots = [];

  var uiState = {
    panel: 'cmd',
    chartMode: 'revenue',
    cmdSpotlightPlan: 'all',
    cmdFocusKpi: 'revenue',
    chartFocusIdx: -1,
    // فلاتر إدارة المتاجر
    storeSearch: '',
    storeSort: 'newest',
    storePlanFilter: 'all',
    storeStatusFilter: 'all',
    storeTypeFilter: 'all',
    storeProdSort: 'all',
    selectedStoreSlug: null,
    storeDetailTab: 'identity', // 'identity' | 'owner' | 'subs' | 'security'
    // حالة مصنع المتاجر وبطاقات القياسات التفاعلية
    factorySelectedType: 'fashion',
    factoryLogoDataUrl: '',
    factoryOpenSizeCardIdx: null,
    factoryEditingSizeItemIdx: null,
    factoryIsCreatingSizeCard: false,
    // فلاتر الباقات والمالية
    finTab: 'subs', // 'subs' | 'payments'
    finSearch: '',
    finPlanFilter: 'all',
    finStatusFilter: 'all',
    finSort: 'newest'
  };

  var SIZE_CARD_PALETTE = ['#4F46E5', '#0EA5E9', '#10B981', '#F59E0B', '#EC4899', '#8B5CF6', '#7A4E2D', '#1C1917'];
  var SIZE_CARD_ICONS = ['📏', '👗', '👠', '⌚', '💄', '💎', '🎁', '🏷️', '👑', '🛍️', '✨', '📦'];

  function inferSizeCardDesc(sp, tp) {
    if (sp && sp.desc && String(sp.desc).trim()) return String(sp.desc).trim();
    var lbl = String((sp && sp.label) || '').toLowerCase();
    if (lbl.indexOf('عباي') !== -1 || lbl.indexOf('فساتين') !== -1) {
      return 'تستخدم لمحلات العبايات والفساتين الشرقية · مثال: قياس 52 أو 56';
    }
    if (lbl.indexOf('أحذية') !== -1 || lbl.indexOf('احذية') !== -1) {
      return 'تستخدم لمتاجر الأحذية النسائية والرجالية والرياضية · مثال: قياس 38 أو 42';
    }
    if (lbl.indexOf('حروف') !== -1 || lbl.indexOf('عالمية') !== -1 || lbl.indexOf('رياضية') !== -1) {
      return 'تستخدم للملابس الجاهزة والقمصان والأطقم · مثال: قياس M أو XL';
    }
    if (lbl.indexOf('أطفال') !== -1 || lbl.indexOf('اطفال') !== -1 || lbl.indexOf('سنوات') !== -1) {
      return 'تستخدم لملابس وتجهيزات الأطفال حسب العمر · مثال: عمر 4 أو 8 سنوات';
    }
    if (lbl.indexOf('خواتم') !== -1 || lbl.indexOf('إكسسوار') !== -1 || lbl.indexOf('اكسسوار') !== -1 || lbl.indexOf('أساور') !== -1) {
      return 'تستخدم لمحلات المجوهرات والخواتم والإكسسوارات · مثال: قياس 17 أو 19';
    }
    if (lbl.indexOf('عطور') !== -1) {
      return 'تستخدم لمتاجر العطور وتحديد حجم العبوة · مثال: عبوة 50 مل أو 100 مل';
    }
    if (lbl.indexOf('كريم') !== -1 || lbl.indexOf('سيروم') !== -1) {
      return 'تستخدم لمنتجات العناية بالبشرة والشعر · مثال: عبوة 30 مل أو 100 مل';
    }
    if (lbl.indexOf('أوزان') !== -1 || lbl.indexOf('غرام') !== -1) {
      return 'تستخدم للمنتجات التي تباع بالوزن والماسكات · مثال: وزن 100 غرام';
    }
    if (lbl.indexOf('بشرة') !== -1 || lbl.indexOf('فاونديشن') !== -1 || lbl.indexOf('درجات') !== -1) {
      return 'تستخدم لمستحضرات التجميل وتحديد درجات اللون · مثال: درجة طبيعي أو بيج';
    }
    if (lbl.indexOf('ساع') !== -1 || lbl.indexOf('قطر') !== -1) {
      return 'تستخدم لمتاجر الساعات لتحديد قطر المينا · مثال: قطر 36 مم أو 42 مم';
    }
    if (lbl.indexOf('بناطيل') !== -1) {
      return 'تستخدم للبناطيل الرجالية والنسائية والكاجوال · مثال: قياس 32 أو 34';
    }
    if (lbl.indexOf('أطوال') !== -1 || lbl.indexOf('سنتيمتر') !== -1) {
      return 'تستخدم لتحديد الطول بالسنتيمتر للعبايات والملابس · مثال: طول 145 سم';
    }
    if (lbl.indexOf('فري سايز') !== -1 || lbl.indexOf('free') !== -1) {
      return 'تستخدم للمنتجات ذات القياس الموحد المناسبة للجميع بدون تعدد مقاسات';
    }
    if (lbl.indexOf('مجموعات') !== -1 || lbl.indexOf('تغليف') !== -1 || lbl.indexOf('باكج') !== -1) {
      return 'تستخدم لخيارات البكجات وصناديق الهدايا والتغليف الخاص';
    }
    if (lbl.indexOf('ملابس') !== -1 || lbl.indexOf('أرقام') !== -1) {
      return 'تستخدم للملابس والأزياء القياسية بالأرقام · مثال: قياس 38 أو 42';
    }
    var tpTitle = (tp && (tp.shortTitle || tp.title)) || 'المتجر';
    var ex = (sp && sp.sizes && sp.sizes.length) ? (' · مثال: ' + sp.sizes[0]) : '';
    return 'مخصصة لمنتجات (' + tpTitle + ') وتسهيل اختيار الزبون' + ex;
  }

  /* ---------- توحيد وترقية بيانات الباقات والأنواع لمنع أي نقص في الاسم أو الرمز أو اللون ---------- */
  function normalizeMasterPlans() {
    if (!masterPlans || typeof masterPlans !== 'object' || !Object.keys(masterPlans).length) {
      masterPlans = JSON.parse(JSON.stringify(DEFAULT_PLANS));
    }
    // ضمان وجود الباقات الأساسية وترقية أي باقة قديمة مخزنة بصيغة {label, price, days}
    Object.keys(DEFAULT_PLANS).forEach(function (k) {
      var def = DEFAULT_PLANS[k];
      var cur = masterPlans[k] || {};
      masterPlans[k] = {
        id: k,
        name: cur.name || cur.label || def.name,
        icon: cur.icon || def.icon,
        color: (cur.color && cur.color !== '#64748B') ? cur.color : def.color,
        price: cur.price != null ? Number(cur.price) : def.price,
        days: cur.days != null ? Number(cur.days) : def.days,
        maxProducts: cur.maxProducts != null ? Number(cur.maxProducts) : def.maxProducts,
        isLifetime: Boolean(cur.isLifetime != null ? cur.isLifetime : def.isLifetime),
        features: (Array.isArray(cur.features) && cur.features.length) ? cur.features : JSON.parse(JSON.stringify(def.features))
      };
    });
    // ضمان أن أي باقة مخصصة أضافها المالك تمتلك اسماً ورمزاً ولوناً مميزاً وميزات
    var usedColors = {};
    Object.keys(masterPlans).forEach(function (k, idx) {
      var p = masterPlans[k];
      if (!p || typeof p !== 'object') { delete masterPlans[k]; return; }
      p.id = k;
      if (!p.name) p.name = p.label || ('باقة ' + (idx + 1));
      if (!p.icon) p.icon = '💎';
      if (!p.color || usedColors[p.color]) {
        p.color = (DEFAULT_PLANS[k] && DEFAULT_PLANS[k].color) || PLAN_PALETTE[idx % PLAN_PALETTE.length];
      }
      usedColors[p.color] = true;
      if (p.price == null) p.price = 15000;
      if (!p.days) p.days = 30;
      if (!Array.isArray(p.features) || !p.features.length) {
        p.features = ['اشتراك فعّال بكامل المزايا', 'ربط الطلبات عبر واتساب'];
      }
    });
  }

  function normalizeStoreTypes() {
    if (!storeTypes || typeof storeTypes !== 'object' || !Object.keys(storeTypes).length) {
      storeTypes = JSON.parse(JSON.stringify(DEFAULT_STORE_TYPES));
    }
    Object.keys(DEFAULT_STORE_TYPES).forEach(function (k) {
      var def = DEFAULT_STORE_TYPES[k];
      var cur = storeTypes[k] || {};
      storeTypes[k] = {
        id: k,
        title: cur.title || def.title,
        shortTitle: cur.shortTitle || cur.title || def.shortTitle,
        icon: cur.icon || def.icon,
        color: cur.color || def.color,
        tagline: cur.tagline || def.tagline,
        categories: (Array.isArray(cur.categories) && cur.categories.length) ? cur.categories : JSON.parse(JSON.stringify(def.categories)),
        sizePresets: (Array.isArray(cur.sizePresets) && cur.sizePresets.length) ? cur.sizePresets : JSON.parse(JSON.stringify(def.sizePresets)),
        colorPresets: (Array.isArray(cur.colorPresets) && cur.colorPresets.length) ? cur.colorPresets : JSON.parse(JSON.stringify(def.colorPresets))
      };
    });
    Object.keys(storeTypes).forEach(function (k) {
      var tp = storeTypes[k];
      if (!tp || typeof tp !== 'object') return;
      if (!Array.isArray(tp.sizePresets)) tp.sizePresets = [];
      tp.sizePresets = tp.sizePresets.map(function (sp, idx) {
        var defSp = (DEFAULT_STORE_TYPES[k] && DEFAULT_STORE_TYPES[k].sizePresets && DEFAULT_STORE_TYPES[k].sizePresets[idx]) || {};
        var normSp = {
          label: (sp && sp.label) || defSp.label || ('بطاقة قياسات ' + (idx + 1)),
          desc: (sp && sp.desc) || defSp.desc || '',
          icon: (sp && sp.icon) || defSp.icon || SIZE_CARD_ICONS[idx % SIZE_CARD_ICONS.length],
          color: (sp && sp.color) || defSp.color || SIZE_CARD_PALETTE[idx % SIZE_CARD_PALETTE.length],
          sizes: (sp && Array.isArray(sp.sizes)) ? sp.sizes : (defSp.sizes ? defSp.sizes.slice() : ['فري سايز'])
        };
        normSp.desc = inferSizeCardDesc(normSp, tp);
        return normSp;
      });
    });
  }

  function loadAllState() {
    try { masterStores = JSON.parse(localStorage.getItem(MASTER_STORES_KEY) || '{}') || {}; } catch (e) { masterStores = {}; }
    try { masterPlans = JSON.parse(localStorage.getItem(MASTER_PLANS_KEY) || '{}') || {}; } catch (e) { masterPlans = {}; }
    try { storeTypes = JSON.parse(localStorage.getItem(STORE_TYPES_KEY) || '{}') || {}; } catch (e) { storeTypes = {}; }
    try { payments = JSON.parse(localStorage.getItem(MASTER_PAYMENTS_KEY) || '[]') || []; } catch (e) { payments = []; }
    try { cfg = JSON.parse(localStorage.getItem(MASTER_CFG_KEY) || '{}') || {}; } catch (e) { cfg = {}; }
    try { snapshots = JSON.parse(localStorage.getItem(SNAPSHOTS_KEY) || '[]') || []; } catch (e) { snapshots = []; }

    normalizeMasterPlans();
    normalizeStoreTypes();

    if (!cfg.agencyName) cfg.agencyName = 'منصة متاجر العراق الرقمية';
    if (!cfg.agencyWhatsapp) cfg.agencyWhatsapp = '9647700000000';
    if (!cfg.adminUsername) cfg.adminUsername = 'admin';
    if (!cfg.adminDisplayName) cfg.adminDisplayName = 'الإدارة العامة';
    if (!cfg.adminPassword) cfg.adminPassword = '1234';
    if (!cfg.recoveryPin) cfg.recoveryPin = '0000';
    if (!cfg.lockReasons || !cfg.lockReasons.length) cfg.lockReasons = JSON.parse(JSON.stringify(DEFAULT_LOCK_REASONS));
    if (!cfg.seqCounter || cfg.seqCounter < 1000) cfg.seqCounter = 1000 + Object.keys(masterStores).length;

    localStorage.setItem(MASTER_PLANS_KEY, JSON.stringify(masterPlans));
    localStorage.setItem(STORE_TYPES_KEY, JSON.stringify(storeTypes));
  }

  function saveAllState(skipCloud) {
    localStorage.setItem(MASTER_STORES_KEY, JSON.stringify(masterStores));
    localStorage.setItem(MASTER_PLANS_KEY, JSON.stringify(masterPlans));
    localStorage.setItem(STORE_TYPES_KEY, JSON.stringify(storeTypes));
    localStorage.setItem(MASTER_PAYMENTS_KEY, JSON.stringify(payments));
    localStorage.setItem(MASTER_CFG_KEY, JSON.stringify(cfg));
    updateSidebarIdentity();
    if (!skipCloud && location.protocol.indexOf('http') === 0) {
      fetch('/api/cloud', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'syncMaster', stores: masterStores, config: cfg, payments: payments })
      }).catch(function () { });
    }
  }

  function peekNextSequentialStoreId() {
    var existingNums = Object.keys(masterStores).map(function (slug) {
      var st = masterStores[slug] || {};
      var m = String(st.serialId || slug).match(/(\d+)/);
      return m ? Number(m[1]) : 0;
    });
    var maxNum = Math.max.apply(null, [cfg.seqCounter || 1000].concat(existingNums));
    return 'ST-' + (maxNum + 1);
  }

  function consumeNextSequentialStoreId() {
    var nextId = peekNextSequentialStoreId();
    var num = Number(nextId.replace(/\D/g, '')) || 1001;
    cfg.seqCounter = num;
    return nextId;
  }

  /* ---------- استيراد المتاجر الـ 11 الجاهزة (مدمج فوراً للعمل على file:// و http:// معاً) ---------- */
  var BUILTIN_SEEDED_STORES = [
    { slug: 'lujain', name: 'بوتيك لُجين', tagline: 'أزياء نسائية راقية · عطور · إكسسوارات', templateId: 'fashion', whatsapp: '9647700000001', instagram: 'lujain.boutique.iq', plan: 'monthly', productsCount: 10 },
    { slug: 'noor-beauty', name: 'نور بيوتي', tagline: 'عطور أصلية · عناية بالبشرة · مكياج', templateId: 'cosmetics', whatsapp: '9647700000002', instagram: 'noor.beauty.iq', plan: 'yearly', productsCount: 10 },
    { slug: 'dar-alabaya', name: 'دار العبايات الملكية', tagline: 'عبايات خليجية فاخرة · تفصيل حسب الطلب', templateId: 'fashion', whatsapp: '9647700000003', instagram: 'dar.alabaya', plan: 'lifetime', productsCount: 10 },
    { slug: 'sport-zone', name: 'سبورت زون', tagline: 'تراكسوتات · كاجوال · أحذية رياضية', templateId: 'fashion', whatsapp: '9647700000004', instagram: 'sportzone.iq', plan: 'weekly', productsCount: 10 },
    { slug: 'kaab-alghazal', name: 'كعب الغزال', tagline: 'أحذية نسائية · حقائب جلد طبيعي', templateId: 'fashion', whatsapp: '9647700000005', instagram: 'kaab.alghazal', plan: 'monthly', productsCount: 10 },
    { slug: 'time-gallery', name: 'تايم كاليري', tagline: 'ساعات أصلية · إكسسوارات · هدايا فخمة', templateId: 'watches', whatsapp: '9647700000006', instagram: 'time.gallery.iq', plan: 'yearly', productsCount: 10 },
    { slug: 'baghdad-sweets', name: 'حلويات بغداد', tagline: 'كيك · حلويات شرقية · بوكسات مناسبات', templateId: 'sweets', whatsapp: '9647700000007', instagram: 'baghdad.sweets', plan: 'trial', productsCount: 10 },
    { slug: 'smart-tech', name: 'سمارت تك', tagline: 'إكسسوارات موبايل · شواحن · سماعات', templateId: 'electronics', whatsapp: '9647700000008', instagram: 'smarttech.iq', plan: 'monthly', productsCount: 10 },
    { slug: 'little-stars', name: 'نجوم صغار', tagline: 'ملابس أطفال · ألعاب تعليمية · مستلزمات', templateId: 'kids', whatsapp: '9647700000009', instagram: 'little.stars.iq', plan: 'lifetime', productsCount: 10 },
    { slug: 'bayt-alfan', name: 'بيت الفن للديكور', tagline: 'ديكور منزلي · إضاءة · مفارش', templateId: 'decor', whatsapp: '9647700000010', instagram: 'bayt.alfan', plan: 'weekly', productsCount: 10 },
    { slug: 'stress-test', name: 'متجر اختبار الأداء (150 منتج)', tagline: 'متجر تجريبي لاختبار التحميل المجزأ 20 منتج في كل دفعة', templateId: 'fashion', whatsapp: '9647700000099', instagram: 'stress.test.iq', plan: 'lifetime', productsCount: 150 }
  ];

  function applySeededStoresArray(list) {
    if (!Array.isArray(list) || !list.length) return false;
    var changed = false;
    var planRotation = ['monthly', 'yearly', 'lifetime', 'weekly', 'trial'];

    // فحص ما إذا كانت جميع المتاجر الحالية مكدسة في باقة واحدة فقط بسبب نسخة قديمة
    var currentSlugs = Object.keys(masterStores);
    var distinctPlans = {};
    currentSlugs.forEach(function (s) {
      var p = (masterStores[s] && masterStores[s].subscription && masterStores[s].subscription.plan) || 'monthly';
      distinctPlans[p] = true;
    });
    var allSamePlan = currentSlugs.length > 2 && Object.keys(distinctPlans).length === 1;

    list.forEach(function (entry, i) {
      var slug = entry.slug;
      var assignedPlan = entry.plan || (entry.subscription && entry.subscription.plan) || planRotation[i % planRotation.length];
      if (!masterStores[slug]) {
        masterStores[slug] = {
          slug: slug,
          serialId: 'ST-' + (1001 + i),
          name: entry.name,
          tagline: entry.tagline || '',
          logo: entry.logo || '',
          ownerName: 'مالك ' + entry.name,
          ownerPhone: entry.whatsapp || '9647700000000',
          whatsapp: entry.whatsapp || '9647700000000',
          instagram: entry.instagram || slug,
          socials: {
            instagram: entry.instagram || slug,
            facebook: slug + '.iq',
            telegram: slug + '_iq',
            tiktok: '@' + slug,
            whatsappChannel: entry.whatsapp || '9647700000000'
          },
          adminPin: entry.adminPin || '1234',
          templateId: entry.templateId || 'fashion',
          createdAt: addDaysISO(-(35 - i * 3)),
          theme: entry.theme || { primary: '#7A4E2D', accent: '#C89B6E', bg: '#FAF7F2', text: '#1F1A17' },
          subscription: {
            plan: assignedPlan,
            expires: assignedPlan === 'lifetime' ? 'lifetime' : addDaysISO(28 + i * 5),
            graceDays: 3,
            maxProducts: 0,
            suspended: false
          },
          subscriptionHistory: [
            {
              date: addDaysISO(-(35 - i * 3)),
              plan: assignedPlan,
              amount: (masterPlans[assignedPlan] || { price: 15000 }).price,
              note: 'تفعيل الاشتراك التأسيسي للمتجر'
            }
          ],
          categories: entry.categories || [],
          productsCount: Number(entry.productsCount || entry.productCount || 10),
          products: []
        };
        changed = true;
      } else {
        if (!masterStores[slug].serialId) {
          masterStores[slug].serialId = 'ST-' + (1001 + i);
          changed = true;
        }
        if (!masterStores[slug].productsCount && (entry.productsCount || entry.productCount)) {
          masterStores[slug].productsCount = Number(entry.productsCount || entry.productCount);
          changed = true;
        }
        if (allSamePlan && masterStores[slug].subscription) {
          masterStores[slug].subscription.plan = assignedPlan;
          masterStores[slug].subscription.expires = assignedPlan === 'lifetime' ? 'lifetime' : addDaysISO(28 + i * 5);
          changed = true;
        }
      }
    });

    if (!payments.length && Object.keys(masterStores).length) {
      Object.keys(masterStores).forEach(function (slug, idx) {
        var st = masterStores[slug];
        var pKey = (st.subscription && st.subscription.plan) || 'monthly';
        var pl = masterPlans[pKey] || DEFAULT_PLANS.monthly;
        if (pl.price > 0) {
          payments.push({
            id: 'pay-seed-' + idx,
            storeSlug: slug,
            storeName: st.name,
            plan: pKey,
            amount: pl.price,
            method: idx % 2 === 0 ? 'زين كاش (ZainCash)' : 'سوبر كي (SuperQi)',
            date: st.createdAt || todayISO(),
            note: 'دفعة اشتراك (' + pl.name + ')'
          });
        }
      });
      changed = true;
    }
    return changed;
  }

  function hydrateSeededStoresFromIndex() {
    // 1. استيراد فوري متزامن يعمل حتى عند فتح الملف مباشرة بدون خادم (file://)
    if (applySeededStoresArray(BUILTIN_SEEDED_STORES)) {
      saveAllState(true);
      renderActivePanel();
    }
    // 2. مزامنة إضافية من data/registry.json عند توفر بروتوكول http
    if (location.protocol.indexOf('http') === 0) {
      fetch('data/registry.json')
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (idxData) {
          if (idxData && idxData.stores && applySeededStoresArray(idxData.stores)) {
            saveAllState(true);
            renderActivePanel();
          }
        })
        .catch(function () { });
    }
  }

  /* ---------- دوال فحص حالة المتجر والاشتراك ---------- */
  function getStoreProductCount(st) {
    if (!st) return 0;
    if (st.products && st.products.length) return st.products.length;
    if (st.catalog && st.catalog.all && st.catalog.all.count) return Number(st.catalog.all.count);
    return Number(st.productsCount || 10);
  }

  function isStoreLifetime(st) {
    var sub = (st && st.subscription) || {};
    var pl = masterPlans[sub.plan] || {};
    return Boolean(pl.isLifetime || sub.plan === 'lifetime' || sub.expires === 'lifetime' || sub.expires === '9999-12-31');
  }

  function getStoreDaysLeft(st) {
    if (isStoreLifetime(st)) return Infinity;
    var sub = (st && st.subscription) || {};
    if (!sub.expires) return Infinity;
    var d = new Date(sub.expires + 'T23:59:59');
    return isNaN(d) ? Infinity : Math.ceil((d - new Date()) / 86400000);
  }

  function getStoreStatusInfo(st) {
    var sub = (st && st.subscription) || {};
    var dl = getStoreDaysLeft(st);
    var grace = Number(sub.graceDays || 0);
    if (sub.suspended) {
      return { key: 'locked', icon: '🔒', label: 'موقوف إدارياً', cls: 'st-locked', reason: sub.suspendReason || 'موقوف من الإدارة' };
    }
    if (!isStoreLifetime(st) && dl < -grace) {
      return { key: 'locked', icon: '⛔', label: 'منتهي الاشتراك', cls: 'st-locked', reason: 'انتهى الاشتراك منذ ' + (-dl) + ' يوم' };
    }
    if (!isStoreLifetime(st) && dl <= 5) {
      return { key: 'expiring', icon: '⏳', label: 'ينتهي خلال ' + Math.max(0, dl) + ' يوم', cls: 'st-expiring', reason: '' };
    }
    return { key: 'active', icon: '🟢', label: 'فعّال ونشط', cls: 'st-active', reason: '' };
  }

  function getStoreTypeInfo(st) {
    var tid = (st && st.templateId) || 'fashion';
    var t = storeTypes[tid] || DEFAULT_STORE_TYPES[tid] || DEFAULT_STORE_TYPES.fashion;
    return {
      id: tid,
      icon: t.icon || '🛍️',
      title: t.shortTitle || t.title || tid,
      fullTitle: t.title || tid,
      color: t.color || '#4F46E5'
    };
  }

  function getStorePlanInfo(st) {
    var sub = (st && st.subscription) || {};
    var pid = sub.plan || 'monthly';
    var p = masterPlans[pid] || DEFAULT_PLANS[pid] || DEFAULT_PLANS.monthly;
    return {
      id: pid,
      name: p.name || p.label || pid,
      icon: p.icon || '💎',
      price: Number(p.price || 0),
      color: p.color || '#4F46E5'
    };
  }

  function generatePortableToken(st) {
    try {
      var sc = st.socials || {};
      var mini = {
        s: st.slug,
        n: st.name,
        tg: st.tagline || '',
        w: st.whatsapp || '',
        ig: sc.instagram || st.instagram || '',
        fb: sc.facebook || st.facebook || '',
        tgm: sc.telegram || st.telegram || '',
        tk: sc.tiktok || st.tiktok || '',
        wac: sc.whatsappChannel || st.whatsappChannel || '',
        p: st.adminPin || '1234',
        t: st.templateId || 'fashion',
        cl: (st.theme && st.theme.primary) || '#7A4E2D',
        pl: (st.subscription && st.subscription.plan) || 'monthly',
        ex: (st.subscription && st.subscription.expires) || '2027-01-01',
        mp: (st.subscription && st.subscription.maxProducts) || 0,
        sp: (st.subscription && st.subscription.suspended) ? 1 : 0,
        hb: (st.subscription && st.subscription.hideBranding) ? 1 : 0
      };
      return btoa(unescape(encodeURIComponent(JSON.stringify(mini)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    } catch (e) { return ''; }
  }

  function getStoreLinks(st) {
    var base = location.origin + location.pathname.replace(/index\.html$/, '');
    if (!base.endsWith('/')) base += '/';
    return {
      storeUrl: base + '?store=' + encodeURIComponent(st.slug),
      adminUrl: base + '?admin=' + encodeURIComponent(st.slug),
      ownerAdminUrl: base + '?admin=' + encodeURIComponent(st.slug) + '&owner=1'
    };
  }

  function updateSidebarIdentity() {
    var countEl = $('#navStoresCount');
    if (countEl) countEl.textContent = Object.keys(masterStores).length;
    var titleEl = $('#sideBrandTitle');
    if (titleEl) titleEl.textContent = cfg.agencyName || 'منصة متاجر العراق الرقمية';
    var logoEl = $('#sideBrandLogo');
    if (logoEl) {
      if (cfg.adminAvatar) logoEl.innerHTML = '<img src="' + esc(cfg.adminAvatar) + '" alt="Admin">';
      else logoEl.textContent = 'LOGO';
    }
    var admAv = $('#sideAdminAvatar');
    if (admAv) {
      if (cfg.adminAvatar) admAv.innerHTML = '<img src="' + esc(cfg.adminAvatar) + '" alt="Admin">';
      else admAv.textContent = (cfg.adminDisplayName || cfg.adminUsername || 'إ').trim().charAt(0).toUpperCase();
    }
    var admNm = $('#sideAdminName');
    if (admNm) admNm.textContent = cfg.adminDisplayName || 'الإدارة العامة';
    var admEm = $('#sideAdminEmail');
    if (admEm) admEm.textContent = '@' + (cfg.adminUsername || 'admin');
  }

  /* =========================================================================
     1. القائمة الأولى: الرئيسية (#panel-cmd)
        • مصفوفة الباقات النشطة مع اسم ورمز ولون كل باقة بوضوح تام
        • التوزيع النسبي للباقات بألوان متعددة ومستقلة لكل باقة
     ========================================================================= */
  function computePlatformMetrics() {
    var slugs = Object.keys(masterStores);
    var totalRev = payments.reduce(function (acc, p) { return acc + Number(p.amount || 0); }, 0);
    var mrr = 0;
    var activeCount = 0;
    var totalProducts = 0;
    var planCounts = {};
    var planMrr = {};

    Object.keys(masterPlans).forEach(function (k) {
      planCounts[k] = 0;
      planMrr[k] = 0;
    });

    slugs.forEach(function (slug) {
      var st = masterStores[slug];
      var stStatus = getStoreStatusInfo(st);
      var pCount = getStoreProductCount(st);
      totalProducts += pCount;

      var sub = st.subscription || {};
      var pKey = sub.plan || 'monthly';
      if (planCounts[pKey] == null) planCounts[pKey] = 0;
      if (planMrr[pKey] == null) planMrr[pKey] = 0;

      if (stStatus.key !== 'locked') {
        activeCount += 1;
        planCounts[pKey] += 1;
        var pl = masterPlans[pKey] || DEFAULT_PLANS[pKey] || {};
        if (!pl.isLifetime && pl.price > 0) {
          var days = Number(pl.days || 30);
          var monthlyEq = Math.round((Number(pl.price) * 30) / Math.max(1, days));
          mrr += monthlyEq;
          planMrr[pKey] += monthlyEq;
        } else if (pl.isLifetime && pl.price > 0) {
          var lifeMonthlyEq = Math.round(Number(pl.price) / 12);
          planMrr[pKey] += lifeMonthlyEq;
        }
      }
    });

    return {
      totalStores: slugs.length,
      activeStores: activeCount,
      totalRevenue: totalRev,
      monthlyRecurring: mrr,
      totalProducts: totalProducts,
      planCounts: planCounts,
      planMrr: planMrr
    };
  }

  function buildDaylightSvgChart(metrics) {
    var slugs = Object.keys(masterStores);
    if (uiState.cmdSpotlightPlan !== 'all') {
      slugs = slugs.filter(function (s) {
        var st = masterStores[s];
        return st && ((st.subscription && st.subscription.plan) || 'monthly') === uiState.cmdSpotlightPlan;
      });
    }

    var chartData = { svg: '', peakLabel: '—', avgLabel: '—', effLabel: '—', insightText: '' };

    if (uiState.chartMode === 'sectors') {
      normalizeStoreTypes();
      var sectorCounts = {};
      slugs.forEach(function (s) {
        var tid = (masterStores[s] && masterStores[s].templateId) || 'fashion';
        sectorCounts[tid] = (sectorCounts[tid] || 0) + 1;
      });
      var secItems = Object.keys(storeTypes).map(function (tid, idx) {
        var tp = storeTypes[tid];
        return {
          name: (tp.shortTitle || tp.title || tid).slice(0, 12),
          fullTitle: tp.title || tid,
          count: Number(sectorCounts[tid] || 0),
          color: tp.color || PLAN_PALETTE[idx % PLAN_PALETTE.length]
        };
      }).slice(0, 8);
      if (!secItems.length) secItems = [{ name: 'أزياء', fullTitle: 'أزياء', count: 1, color: '#4F46E5' }];
      var maxS = Math.max.apply(null, [4].concat(secItems.map(function (x) { return x.count; })));
      var ws = 680, hs = 228, padLs = 42, padRs = 24, padTs = 26, padBs = 40;
      var plotWs = ws - padLs - padRs, plotHs = hs - padTs - padBs;
      var stepS = plotWs / Math.max(1, secItems.length);
      var gridS = [0, 0.5, 1].map(function (r) {
        var y = Math.round(padTs + plotHs * (1 - r));
        var val = Math.round(maxS * r);
        return '<line x1="' + padLs + '" y1="' + y + '" x2="' + (ws - padRs) + '" y2="' + y + '" stroke="#E2E8F0" stroke-dasharray="4 4"/>' +
               '<text x="' + (padLs - 8) + '" y="' + (y + 4) + '" font-size="11" fill="#64748B" text-anchor="end">' + val + '</text>';
      }).join('');

      var topSec = secItems.slice().sort(function (a, b) { return b.count - a.count; })[0] || secItems[0];
      var focusedSec = (uiState.chartFocusIdx >= 0 && secItems[uiState.chartFocusIdx]) ? secItems[uiState.chartFocusIdx] : topSec;

      var barsS = secItems.map(function (it, idx) {
        var bw = Math.min(48, stepS * 0.56);
        var x = Math.round(padLs + idx * stepS + (stepS - bw) / 2);
        var bh = Math.max(10, Math.round((it.count / maxS) * plotHs));
        var y = padTs + plotHs - bh;
        var isFoc = (uiState.chartFocusIdx === idx) || (uiState.chartFocusIdx === -1 && it === topSec);
        return '<g class="chart-interactive-node" data-chart-idx="' + idx + '" style="cursor:pointer">' +
          '<rect x="' + (x - 4) + '" y="' + (padTs - 6) + '" width="' + (bw + 8) + '" height="' + (plotHs + 12) + '" rx="12" fill="' + (isFoc ? esc(it.color) + '12' : 'transparent') + '"/>' +
          '<rect x="' + x + '" y="' + y + '" width="' + bw + '" height="' + bh + '" rx="11" fill="' + esc(it.color) + '" opacity="' + (isFoc ? '1' : '0.78') + '"/>' +
          '<text x="' + (x + bw / 2) + '" y="' + (y - 7) + '" font-size="11" font-weight="900" fill="' + esc(it.color) + '" text-anchor="middle">' + it.count + ' متجر</text>' +
          '<text x="' + (x + bw / 2) + '" y="' + (hs - 13) + '" font-size="11" font-weight="' + (isFoc ? '900' : '700') + '" fill="' + (isFoc ? '#0F172A' : '#475569') + '" text-anchor="middle">' + esc(it.name) + '</text>' +
        '</g>';
      }).join('');

      var activeSecCount = secItems.filter(function (x) { return x.count > 0; }).length;
      chartData.svg = '<svg viewBox="0 0 ' + ws + ' ' + hs + '">' + gridS + barsS + '</svg>';
      chartData.peakLabel = focusedSec.name + ' (' + focusedSec.count + ' متجر)';
      chartData.avgLabel = (slugs.length / Math.max(1, secItems.length)).toFixed(1) + ' متجر / قطاع';
      chartData.effLabel = activeSecCount + ' من ' + secItems.length + ' قطاعات نشطة';
      chartData.insightText = 'القطاع المتصدر حالياً هو «' + focusedSec.name + '» بحصة ' + (slugs.length ? Math.round((focusedSec.count / slugs.length) * 100) : 0) + '% من المتاجر المعروضة.';
      return chartData;
    }

    if (uiState.chartMode === 'mrr') {
      var planKeys = Object.keys(masterPlans);
      var mrrItems = planKeys.map(function (k, idx) {
        var pl = masterPlans[k];
        var cnt = Number(metrics.planCounts[k] || 0);
        var val = Number((metrics.planMrr && metrics.planMrr[k]) || (cnt * Number(pl.price || 0)));
        return {
          key: k,
          name: (pl.name || k).replace('الباقة ', ''),
          val: val,
          count: cnt,
          color: pl.color || PLAN_PALETTE[idx % PLAN_PALETTE.length]
        };
      });
      var maxM = Math.max.apply(null, [25000].concat(mrrItems.map(function (x) { return x.val; })));
      var wm = 680, hm = 228, padLm = 54, padRm = 24, padTm = 26, padBm = 40;
      var plotWm = wm - padLm - padRm, plotHm = hm - padTm - padBm;
      var stepM = plotWm / Math.max(1, mrrItems.length);
      var gridM = [0, 0.5, 1].map(function (r) {
        var y = Math.round(padTm + plotHm * (1 - r));
        var val = Math.round((maxM * r) / 1000) + 'k';
        return '<line x1="' + padLm + '" y1="' + y + '" x2="' + (wm - padRm) + '" y2="' + y + '" stroke="#E2E8F0" stroke-dasharray="4 4"/>' +
               '<text x="' + (padLm - 8) + '" y="' + (y + 4) + '" font-size="11" fill="#64748B" text-anchor="end" dir="ltr">' + val + '</text>';
      }).join('');

      var topMrrItem = mrrItems.slice().sort(function (a, b) { return b.val - a.val; })[0] || mrrItems[0];
      var focusedMrr = (uiState.chartFocusIdx >= 0 && mrrItems[uiState.chartFocusIdx]) ? mrrItems[uiState.chartFocusIdx] : topMrrItem;

      var barsM = mrrItems.map(function (it, idx) {
        var bw = Math.min(52, stepM * 0.54);
        var x = Math.round(padLm + idx * stepM + (stepM - bw) / 2);
        var bh = Math.max(10, Math.round((it.val / maxM) * plotHm));
        var y = padTm + plotHm - bh;
        var isFoc = (uiState.chartFocusIdx === idx) || (uiState.chartFocusIdx === -1 && it === topMrrItem);
        var valTxt = it.val >= 1000 ? (Math.round(it.val / 1000) + ' ألف') : '0';
        return '<g class="chart-interactive-node" data-chart-idx="' + idx + '" style="cursor:pointer">' +
          '<rect x="' + (x - 4) + '" y="' + (padTm - 6) + '" width="' + (bw + 8) + '" height="' + (plotHm + 12) + '" rx="12" fill="' + (isFoc ? esc(it.color) + '12' : 'transparent') + '"/>' +
          '<rect x="' + x + '" y="' + y + '" width="' + bw + '" height="' + bh + '" rx="11" fill="' + esc(it.color) + '" opacity="' + (isFoc ? '1' : '0.78') + '"/>' +
          '<text x="' + (x + bw / 2) + '" y="' + (y - 7) + '" font-size="10.5" font-weight="900" fill="' + esc(it.color) + '" text-anchor="middle">' + valTxt + '</text>' +
          '<text x="' + (x + bw / 2) + '" y="' + (hm - 13) + '" font-size="11" font-weight="' + (isFoc ? '900' : '700') + '" fill="' + (isFoc ? '#0F172A' : '#475569') + '" text-anchor="middle">' + esc(it.name.slice(0, 12)) + '</text>' +
        '</g>';
      }).join('');

      chartData.svg = '<svg viewBox="0 0 ' + wm + ' ' + hm + '">' + gridM + barsM + '</svg>';
      chartData.peakLabel = focusedMrr.name + ' (' + fmt(focusedMrr.val) + ')';
      chartData.avgLabel = fmt(Math.round((metrics.monthlyRecurring || 0) / Math.max(1, metrics.activeStores)));
      chartData.effLabel = focusedMrr.count + ' متجر مشترك';
      chartData.insightText = 'باقة «' + focusedMrr.name + '» تحقق أعلى مساهمة في التدفق المالي عبر ' + focusedMrr.count + ' متجر فعّال.';
      return chartData;
    }

    if (uiState.chartMode === 'stores') {
      var items = slugs.map(function (s) {
        return {
          name: masterStores[s].name.replace(/^(متجر|بوتيك|دار|معرض)\s+/, ''),
          fullName: masterStores[s].name,
          count: getStoreProductCount(masterStores[s])
        };
      }).slice(0, 8);
      if (!items.length) items = [{ name: 'لا توجد متاجر', fullName: 'لا توجد متاجر', count: 0 }];
      var maxC = Math.max.apply(null, [20].concat(items.map(function (x) { return x.count; })));
      var w = 680, h = 228, padL = 42, padR = 24, padT = 26, padB = 40;
      var plotW = w - padL - padR, plotH = h - padT - padB;
      var step = plotW / Math.max(1, items.length);

      var gridLines = [0, 0.25, 0.5, 0.75, 1].map(function (r) {
        var y = Math.round(padT + plotH * (1 - r));
        var val = Math.round(maxC * r);
        return '<line x1="' + padL + '" y1="' + y + '" x2="' + (w - padR) + '" y2="' + y + '" stroke="#E2E8F0" stroke-dasharray="4 4"/>' +
               '<text x="' + (padL - 8) + '" y="' + (y + 4) + '" font-size="11" fill="#64748B" text-anchor="end">' + val + '</text>';
      }).join('');

      var topSt = items.slice().sort(function (a, b) { return b.count - a.count; })[0] || items[0];
      var focusedSt = (uiState.chartFocusIdx >= 0 && items[uiState.chartFocusIdx]) ? items[uiState.chartFocusIdx] : topSt;

      var bars = items.map(function (it, idx) {
        var bw = Math.min(46, step * 0.54);
        var x = Math.round(padL + idx * step + (step - bw) / 2);
        var bh = Math.max(8, Math.round((it.count / maxC) * plotH));
        var y = padT + plotH - bh;
        var barColor = PLAN_PALETTE[idx % PLAN_PALETTE.length];
        var isFoc = (uiState.chartFocusIdx === idx) || (uiState.chartFocusIdx === -1 && it === topSt);
        return '<g class="chart-interactive-node" data-chart-idx="' + idx + '" style="cursor:pointer">' +
          '<rect x="' + (x - 4) + '" y="' + (padT - 6) + '" width="' + (bw + 8) + '" height="' + (plotH + 12) + '" rx="12" fill="' + (isFoc ? barColor + '14' : 'transparent') + '"/>' +
          '<rect x="' + x + '" y="' + y + '" width="' + bw + '" height="' + bh + '" rx="10" fill="' + barColor + '" opacity="' + (isFoc ? '1' : '0.78') + '"/>' +
          '<text x="' + (x + bw / 2) + '" y="' + (y - 7) + '" font-size="11" font-weight="900" fill="' + barColor + '" text-anchor="middle">' + it.count + '</text>' +
          '<text x="' + (x + bw / 2) + '" y="' + (h - 13) + '" font-size="11" font-weight="' + (isFoc ? '900' : '700') + '" fill="' + (isFoc ? '#0F172A' : '#475569') + '" text-anchor="middle">' + esc(it.name.slice(0, 10)) + '</text>' +
          '</g>';
      }).join('');

      var avgProds = items.length ? Math.round(items.reduce(function (a, b) { return a + b.count; }, 0) / items.length) : 0;
      chartData.svg = '<svg viewBox="0 0 ' + w + ' ' + h + '">' + gridLines + bars + '</svg>';
      chartData.peakLabel = focusedSt.fullName + ' (' + focusedSt.count + ' منتج)';
      chartData.avgLabel = avgProds + ' منتج / متجر';
      chartData.effLabel = metrics.totalProducts + ' منتج بالمنصة';
      chartData.insightText = 'متجر «' + focusedSt.fullName + '» يضم ' + focusedSt.count + ' منتج معروض بمتوسط عام ' + avgProds + ' منتج لكل متجر.';
      return chartData;
    }

    var baseMrr = Math.max(45000, metrics.monthlyRecurring || 75000);
    var totalR = Math.max(baseMrr, metrics.totalRevenue || 150000);
    var months = [
      { m: 'حزيران', v: Math.round(baseMrr * 0.48) },
      { m: 'تموز', v: Math.round(baseMrr * 0.62) },
      { m: 'آب', v: Math.round(baseMrr * 0.74) },
      { m: 'أيلول', v: Math.round(baseMrr * 0.85) },
      { m: 'تشرين 1', v: Math.round(baseMrr * 0.94) },
      { m: 'الحالي', v: Math.max(baseMrr, Math.round(totalR * 0.65)) }
    ];
    var maxV = Math.max.apply(null, months.map(function (x) { return x.v; })) * 1.15;
    var w2 = 680, h2 = 228, pL = 58, pR = 24, pT = 24, pB = 38;
    var pw = w2 - pL - pR, ph = h2 - pT - pB;

    var pts = months.map(function (item, i) {
      var x = Math.round(pL + (i / (months.length - 1)) * pw);
      var y = Math.round(pT + ph * (1 - item.v / maxV));
      return { x: x, y: y, m: item.m, v: item.v, idx: i };
    });

    var pathD = 'M ' + pts[0].x + ' ' + pts[0].y;
    for (var i = 0; i < pts.length - 1; i++) {
      var p0 = pts[i], p1 = pts[i + 1];
      var cx = Math.round((p0.x + p1.x) / 2);
      pathD += ' C ' + cx + ' ' + p0.y + ', ' + cx + ' ' + p1.y + ', ' + p1.x + ' ' + p1.y;
    }
    var areaD = pathD + ' L ' + pts[pts.length - 1].x + ' ' + (pT + ph) + ' L ' + pts[0].x + ' ' + (pT + ph) + ' Z';

    var hLines = [0, 0.33, 0.66, 1].map(function (r) {
      var y = Math.round(pT + ph * (1 - r));
      var val = Math.round((maxV * r) / 1000) + 'k';
      return '<line x1="' + pL + '" y1="' + y + '" x2="' + (w2 - pR) + '" y2="' + y + '" stroke="#E2E8F0" stroke-dasharray="4 4"/>' +
             '<text x="' + (pL - 10) + '" y="' + (y + 4) + '" font-size="11" fill="#64748B" text-anchor="end" dir="ltr">' + val + '</text>';
    }).join('');

    var focPtIdx = (uiState.chartFocusIdx >= 0 && pts[uiState.chartFocusIdx]) ? uiState.chartFocusIdx : (pts.length - 1);
    var focPt = pts[focPtIdx];

    var dots = pts.map(function (pt, idx) {
      var isFoc = idx === focPtIdx;
      return '<g class="chart-interactive-node" data-chart-idx="' + idx + '" style="cursor:pointer">' +
        (isFoc ? '<line x1="' + pt.x + '" y1="' + pt.y + '" x2="' + pt.x + '" y2="' + (pT + ph) + '" stroke="#4F46E5" stroke-width="1.5" stroke-dasharray="3 3" opacity="0.55"/>' : '') +
        (isFoc ? '<circle cx="' + pt.x + '" cy="' + pt.y + '" r="12" fill="#4F46E5" opacity="0.16"/>' : '') +
        '<circle cx="' + pt.x + '" cy="' + pt.y + '" r="' + (isFoc ? '7.5' : '5.5') + '" fill="#FFFFFF" stroke="' + (isFoc ? '#4F46E5' : '#0EA5E9') + '" stroke-width="' + (isFoc ? '3.8' : '3') + '"/>' +
        '<text x="' + pt.x + '" y="' + (pt.y - 12) + '" font-size="10.5" font-weight="900" fill="' + (isFoc ? '#4F46E5' : '#1E293B') + '" text-anchor="middle">' + Math.round(pt.v / 1000) + ' ألف</text>' +
        '<text x="' + pt.x + '" y="' + (h2 - 12) + '" font-size="11" font-weight="' + (isFoc ? '900' : '700') + '" fill="' + (isFoc ? '#0F172A' : '#475569') + '" text-anchor="middle">' + pt.m + '</text>' +
        '</g>';
    }).join('');

    var growthPct = pts[0].v > 0 ? Math.round(((pts[pts.length - 1].v - pts[0].v) / pts[0].v) * 100) : 100;
    chartData.svg = '<svg viewBox="0 0 ' + w2 + ' ' + h2 + '">' +
      '<defs>' +
      '<linearGradient id="dayAreaGrad" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0%" stop-color="#4F46E5" stop-opacity="0.28"/>' +
      '<stop offset="65%" stop-color="#0EA5E9" stop-opacity="0.09"/>' +
      '<stop offset="100%" stop-color="#0EA5E9" stop-opacity="0.0"/>' +
      '</linearGradient>' +
      '<linearGradient id="dayStrokeGrad" x1="0" y1="0" x2="1" y2="0">' +
      '<stop offset="0%" stop-color="#4F46E5"/><stop offset="100%" stop-color="#0EA5E9"/>' +
      '</linearGradient>' +
      '</defs>' +
      hLines +
      '<path d="' + areaD + '" fill="url(#dayAreaGrad)"/>' +
      '<path d="' + pathD + '" fill="none" stroke="url(#dayStrokeGrad)" stroke-width="4" stroke-linecap="round"/>' +
      dots +
      '</svg>';
    chartData.peakLabel = focPt.m + ' (' + fmt(focPt.v) + ')';
    chartData.avgLabel = fmt(Math.round(pts.reduce(function (a, b) { return a + b.v; }, 0) / pts.length));
    chartData.effLabel = '+' + growthPct + '% معدل النمو';
    chartData.insightText = 'قراءة شهر «' + focPt.m + '» تسجل ' + fmt(focPt.v) + ' بنمو تراكمي +' + growthPct + '% منذ بداية السلسلة.';
    return chartData;
  }

  function buildPlansDonutHtml(metrics) {
    var planKeys = Object.keys(masterPlans);
    var r = 64;
    var circ = 2 * Math.PI * r;
    var offset = 0;
    var circles = [];
    var legendRows = [];

    var rawCounts = planKeys.map(function (k) { return Number(metrics.planCounts[k] || 0); });
    var sumActive = rawCounts.reduce(function (a, b) { return a + b; }, 0);
    var nonZeroPlans = rawCounts.filter(function (c) { return c > 0; }).length;

    var visualWeights = planKeys.map(function (k) {
      var c = Number(metrics.planCounts[k] || 0);
      if (sumActive === 0) return 1;
      if (nonZeroPlans === 1) return c > 0 ? (c * 3) : 0.45;
      return c;
    });
    var totalVisualWeight = visualWeights.reduce(function (a, b) { return a + b; }, 0) || 1;

    var topPlanKey = planKeys[0] || 'monthly';
    var topPlanCount = -1;
    var longTermCount = 0;

    planKeys.forEach(function (k, idx) {
      var pl = masterPlans[k];
      var pColor = pl.color || PLAN_PALETTE[idx % PLAN_PALETTE.length];
      var pIcon = pl.icon || '💎';
      var pName = pl.name || pl.label || k;
      var count = Number(metrics.planCounts[k] || 0);
      var pct = sumActive > 0 ? Math.round((count / sumActive) * 100) : 0;
      var pMrr = Number((metrics.planMrr && metrics.planMrr[k]) || 0);
      var w = visualWeights[idx];
      var isSpot = uiState.cmdSpotlightPlan === k;

      if (count > topPlanCount) {
        topPlanCount = count;
        topPlanKey = k;
      }
      if (pl.isLifetime || Number(pl.days || 0) >= 300 || k === 'yearly' || k === 'lifetime') {
        longTermCount += count;
      }

      if (w > 0) {
        var segLen = (w / totalVisualWeight) * circ;
        var drawLen = Math.max(2, segLen - 3);
        circles.push(
          '<circle cx="84" cy="84" r="' + r + '" fill="none" stroke="' + esc(pColor) + '" stroke-width="' + (isSpot ? '23' : '19') + '" ' +
          'stroke-dasharray="' + drawLen.toFixed(2) + ' ' + circ.toFixed(2) + '" ' +
          'stroke-dashoffset="' + (-offset).toFixed(2) + '" opacity="' + (uiState.cmdSpotlightPlan === 'all' || isSpot ? '1' : '0.32') + '"/>'
        );
        offset += segLen;
      }

      legendRows.push(
        '<div class="donut-legend-row' + (isSpot ? ' active-filter' : '') + '" data-cmd-plan="' + esc(k) + '" style="--dl-color:' + esc(pColor) + '" title="اضغط للتركيز البصري على هذه الباقة">' +
          '<div class="dl-row-top">' +
            '<span class="dl-row-id">' +
              '<i class="donut-dot" style="background:' + esc(pColor) + '"></i>' +
              '<span style="margin-left:5px">' + esc(pIcon) + '</span>' +
              '<b>' + esc(pName) + '</b>' +
            '</span>' +
            '<span class="dl-row-stats">' +
              '<b style="color:' + esc(pColor) + '">' + count + ' متجر</b>' +
              '<span class="dl-pct-pill" style="background:' + esc(pColor) + '18;color:' + esc(pColor) + '">' + pct + '%</span>' +
            '</span>' +
          '</div>' +
          '<div class="dl-row-bar"><i style="width:' + Math.max(6, pct) + '%;background:' + esc(pColor) + '"></i></div>' +
          '<div class="dl-row-sub">' +
            '<span>السعر: ' + (pl.price > 0 ? fmt(pl.price) : 'مجاناً') + '</span>' +
            '<span>العائد: ' + (pMrr > 0 ? fmt(pMrr) + '/ش' : '—') + '</span>' +
          '</div>' +
        '</div>'
      );
    });

    var centerTitle = String(metrics.activeStores);
    var centerSub = 'متجر فعّال (100%)';
    var centerColor = 'var(--text)';
    if (uiState.cmdSpotlightPlan !== 'all' && masterPlans[uiState.cmdSpotlightPlan]) {
      var spPl = masterPlans[uiState.cmdSpotlightPlan];
      var spCnt = Number(metrics.planCounts[uiState.cmdSpotlightPlan] || 0);
      var spPct = sumActive > 0 ? Math.round((spCnt / sumActive) * 100) : 0;
      centerTitle = spPct + '%';
      centerSub = spCnt + ' متجر · ' + (spPl.name || '').replace('الباقة ', '');
      centerColor = spPl.color || 'var(--brand)';
    }

    var topPlObj = masterPlans[topPlanKey] || { name: 'الباقة الشهرية', color: '#4F46E5' };
    var topPlPct = sumActive > 0 ? Math.round((Math.max(0, topPlanCount) / sumActive) * 100) : 0;
    var stabilityPct = sumActive > 0 ? Math.round((longTermCount / sumActive) * 100) : 0;

    return '<div class="smart-donut-studio">' +
      '<div class="donut-wrap">' +
        '<div class="donut-svg-box">' +
          '<svg width="168" height="168" viewBox="0 0 168 168" style="transform:rotate(-90deg)">' +
            '<circle cx="84" cy="84" r="' + r + '" fill="none" stroke="var(--surface-3)" stroke-width="19"/>' +
            circles.join('') +
            '<g style="transform:rotate(90deg);transform-origin:84px 84px">' +
              '<text x="84" y="80" text-anchor="middle" font-size="23" font-weight="900" fill="' + esc(centerColor) + '">' + esc(centerTitle) + '</text>' +
              '<text x="84" y="100" text-anchor="middle" font-size="10.5" font-weight="800" fill="var(--muted)">' + esc(centerSub) + '</text>' +
            '</g>' +
          '</svg>' +
        '</div>' +
        '<div class="donut-legend" id="cmdDonutLegend">' + legendRows.join('') + '</div>' +
      '</div>' +
      '<div class="donut-ai-summary">' +
        '<div class="das-pill">' +
          '<span>👑 الباقة المتصدرة</span>' +
          '<b style="color:' + esc(topPlObj.color || '#4F46E5') + '">' + esc(topPlObj.name) + ' (' + topPlPct + '%)</b>' +
        '</div>' +
        '<div class="das-pill">' +
          '<span>🛡️ مؤشر الاستقرار الطويل</span>' +
          '<b>' + stabilityPct + '% باقات سنوية ودائمية</b>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function renderCmdPanel() {
    var box = $('#panel-cmd');
    if (!box) return;
    normalizeMasterPlans();
    normalizeStoreTypes();
    var m = computePlatformMetrics();
    var planKeys = Object.keys(masterPlans);

    var matrixHtml = planKeys.map(function (k, idx) {
      var pl = masterPlans[k];
      var pColor = pl.color || PLAN_PALETTE[idx % PLAN_PALETTE.length];
      var pIcon = pl.icon || '💎';
      var pName = pl.name || pl.label || k;
      var cnt = Number(m.planCounts[k] || 0);
      var pct = m.activeStores ? Math.round((cnt / m.activeStores) * 100) : 0;
      var isActFilter = (uiState.cmdSpotlightPlan === k);

      return '<div class="pm-card' + (isActFilter ? ' active-filter' : '') + '" data-cmd-plan="' + esc(k) + '" style="--pm-color:' + esc(pColor) + '" title="اضغط للتركيز البصري على هذه الباقة في المؤشرات أدناه">' +
        '<div class="pm-card-top">' +
          '<div class="pm-icon-badge" style="color:' + esc(pColor) + ';border-color:' + esc(pColor) + '33">' + esc(pIcon) + '</div>' +
          '<div class="pm-title-box">' +
            '<b>' + esc(pName) + '</b>' +
            '<span>' + (pl.price > 0 ? fmt(pl.price) : 'مجاناً للتجربة') + '</span>' +
          '</div>' +
        '</div>' +
        '<div class="pm-count-row">' +
          '<div class="pm-count" style="color:' + esc(pColor) + '">' + cnt + ' <small style="font-size:0.84rem;font-weight:800;color:var(--muted)">متجر نشط</small></div>' +
          '<span style="font-size:0.82rem;font-weight:900;color:' + esc(pColor) + ';background:' + esc(pColor) + '15;padding:3px 10px;border-radius:999px">' + pct + '%</span>' +
        '</div>' +
        '<div class="pm-bar"><i style="width:' + Math.max(8, pct) + '%;background:' + esc(pColor) + '"></i></div>' +
      '</div>';
    }).join('');

    var chartObj = buildDaylightSvgChart(m);
    var activeKpi = uiState.cmdFocusKpi || 'revenue';

    box.innerHTML =
      '<div class="cmd-hero-banner">' +
        '<div class="cmd-hero-left">' +
          '<div class="cmd-pulse-orb">📊</div>' +
          '<div class="cmd-hero-txt">' +
            '<h2>' +
              '<span>الرئيسية — مركز القيادة والتحليل الذكي</span>' +
              '<span class="cmd-live-pill"><i class="cmd-live-dot"></i> النظام متصل ومحدّث لحظياً</span>' +
            '</h2>' +
            '<p>لوحة تفاعلية ذكية لاستعراض المؤشرات المالية وتوزيع الباقات والقطاعات في مكان واحد بدون مغادرة الصفحة</p>' +
          '</div>' +
        '</div>' +
        '<div class="cmd-hero-status-badges">' +
          '<span class="sym-badge st-active">⚡ الكفاءة التشغيلية 100%</span>' +
          '<span class="sym-badge st-plan">' + m.activeStores + ' متجر نشط</span>' +
        '</div>' +
      '</div>' +

      '<div class="kpi-grid-4" id="cmdKpiGrid">' +
        '<div class="kpi-card' + (activeKpi === 'revenue' ? ' active-kpi' : '') + '" data-kpi-focus="revenue" style="--kpi-color:#4F46E5;--kpi-bg:#EEF2FF">' +
          '<div class="kpi-top"><span class="kpi-label">إجمالي الإيرادات</span><div class="kpi-ico">💰</div></div>' +
          '<div class="kpi-val">' + fmt(m.totalRevenue) + '</div>' +
          '<div class="kpi-sub"><span>' + payments.length + ' عملية تحصيل مسجلة</span><span class="kpi-action-hint">' + (activeKpi === 'revenue' ? '● معروض بالتحليل' : 'معاينة المنحنى') + '</span></div>' +
        '</div>' +

        '<div class="kpi-card' + (activeKpi === 'mrr' ? ' active-kpi' : '') + '" data-kpi-focus="mrr" style="--kpi-color:#0EA5E9;--kpi-bg:#E0F2FE">' +
          '<div class="kpi-top"><span class="kpi-label">العائد الشهري</span><div class="kpi-ico">📈</div></div>' +
          '<div class="kpi-val">' + fmt(m.monthlyRecurring) + '</div>' +
          '<div class="kpi-sub"><span>عائد الاشتراكات النشطة</span><span class="kpi-action-hint">' + (activeKpi === 'mrr' ? '● معروض بالتحليل' : 'تحليل الباقات') + '</span></div>' +
        '</div>' +

        '<div class="kpi-card' + (activeKpi === 'stores' ? ' active-kpi' : '') + '" data-kpi-focus="stores" style="--kpi-color:#10B981;--kpi-bg:#ECFDF5">' +
          '<div class="kpi-top"><span class="kpi-label">المتاجر الفعالة</span><div class="kpi-ico">🏪</div></div>' +
          '<div class="kpi-val">' + m.activeStores + ' <small style="font-size:0.95rem;color:var(--muted);font-weight:700">/ ' + m.totalStores + '</small></div>' +
          '<div class="kpi-sub"><span>تعمل بكفاءة بدون توقف</span><span class="kpi-action-hint">' + (activeKpi === 'stores' ? '● معروض بالتحليل' : 'تحليل القطاعات') + '</span></div>' +
        '</div>' +

        '<div class="kpi-card' + (activeKpi === 'products' ? ' active-kpi' : '') + '" data-kpi-focus="products" style="--kpi-color:#8B5CF6;--kpi-bg:#F3E8FF">' +
          '<div class="kpi-top"><span class="kpi-label">إجمالي المنتجات</span><div class="kpi-ico">📦</div></div>' +
          '<div class="kpi-val">' + m.totalProducts.toLocaleString('en-US') + '</div>' +
          '<div class="kpi-sub"><span>مجموع المنتجات بالمنصة</span><span class="kpi-action-hint">' + (activeKpi === 'products' ? '● معروض بالتحليل' : 'كثافة المنتجات') + '</span></div>' +
        '</div>' +
      '</div>' +

      '<div class="card">' +
        '<div class="card-h">' +
          '<div>' +
            '<h3>💎 مصفوفة الباقات النشطة التفاعلية</h3>' +
            '<span style="font-size:0.78rem;color:var(--muted);font-weight:700">اضغط على أي باقة للتركيز البصري الفوري على حصتها ومؤشراتها داخل الصفحة</span>' +
          '</div>' +
          (uiState.cmdSpotlightPlan !== 'all'
            ? '<button type="button" class="btn btn-ghost btn-sm" id="cmdResetPlanFilterBtn">🔄 إظهار جميع الباقات (' + m.activeStores + ')</button>'
            : '<span class="sym-badge st-plan">الكل معروض (' + m.activeStores + ' متجر نشط)</span>') +
        '</div>' +
        '<div class="plans-matrix-grid" id="cmdPlansMatrix">' + matrixHtml + '</div>' +
      '</div>' +

      '<div class="analytics-showcase">' +
        '<div class="chart-card">' +
          '<div class="card-h" style="margin-bottom:8px">' +
            '<div>' +
              '<h3>✨ التحليل البياني التفاعلي للمنصة</h3>' +
              '<p style="font-size:0.78rem;color:var(--muted)">اضغط على التبويبات أو أعمدة ونقاط الرسم لقراءة المؤشرات التفصيلية لحظياً</p>' +
            '</div>' +
            '<div class="chart-tabs" id="cmdChartTabs">' +
              '<button type="button" class="chart-tab ' + (uiState.chartMode === 'revenue' ? 'active' : '') + '" data-cm="revenue">منحنى الإيرادات</button>' +
              '<button type="button" class="chart-tab ' + (uiState.chartMode === 'mrr' ? 'active' : '') + '" data-cm="mrr">عائد الباقات</button>' +
              '<button type="button" class="chart-tab ' + (uiState.chartMode === 'stores' ? 'active' : '') + '" data-cm="stores">كثافة المنتجات</button>' +
              '<button type="button" class="chart-tab ' + (uiState.chartMode === 'sectors' ? 'active' : '') + '" data-cm="sectors">توزيع القطاعات</button>' +
            '</div>' +
          '</div>' +
          '<div class="svg-chart-wrap" id="cmdSvgChartWrap">' + chartObj.svg + '</div>' +
          '<div class="chart-smart-strip">' +
            '<div class="css-tile"><span>🎯 القراءة المحددة / الأعلى</span><b>' + esc(chartObj.peakLabel) + '</b></div>' +
            '<div class="css-tile"><span>📊 المتوسط العام</span><b>' + esc(chartObj.avgLabel) + '</b></div>' +
            '<div class="css-tile"><span>⚡ مؤشر الكفاءة والنمو</span><b style="color:#059669">' + esc(chartObj.effLabel) + '</b></div>' +
          '</div>' +
          '<div class="chart-ai-note">💡 <b>التحليل الذكي:</b> ' + esc(chartObj.insightText) + '</div>' +
        '</div>' +

        '<div class="chart-card">' +
          '<div class="card-h" style="margin-bottom:6px">' +
            '<div>' +
              '<h3>🎯 التوزيع النسبي الذكي للباقات</h3>' +
              '<p style="font-size:0.76rem;color:var(--muted)">تحليل الحصص السوقية والعائد لكل باقة اشتراك</p>' +
            '</div>' +
            '<span class="sym-badge st-type">تفاعلي بالضغط</span>' +
          '</div>' +
          buildPlansDonutHtml(m) +
        '</div>' +
      '</div>';

    var cTabs = $('#cmdChartTabs', box);
    if (cTabs) {
      cTabs.onclick = function (e) {
        var b = e.target.closest('button[data-cm]');
        if (!b) return;
        uiState.chartMode = b.getAttribute('data-cm');
        uiState.chartFocusIdx = -1;
        if (uiState.chartMode === 'revenue') uiState.cmdFocusKpi = 'revenue';
        else if (uiState.chartMode === 'mrr') uiState.cmdFocusKpi = 'mrr';
        else if (uiState.chartMode === 'stores') uiState.cmdFocusKpi = 'products';
        else if (uiState.chartMode === 'sectors') uiState.cmdFocusKpi = 'stores';
        renderCmdPanel();
      };
    }

    var svgWrap = $('#cmdSvgChartWrap', box);
    if (svgWrap) {
      svgWrap.onclick = function (e) {
        var node = e.target.closest('[data-chart-idx]');
        if (!node) return;
        var idx = Number(node.getAttribute('data-chart-idx'));
        uiState.chartFocusIdx = (uiState.chartFocusIdx === idx) ? -1 : idx;
        renderCmdPanel();
      };
    }

    var kpiGrid = $('#cmdKpiGrid', box);
    if (kpiGrid) {
      kpiGrid.onclick = function (e) {
        var card = e.target.closest('[data-kpi-focus]');
        if (!card) return;
        var target = card.getAttribute('data-kpi-focus');
        uiState.cmdFocusKpi = target;
        uiState.chartFocusIdx = -1;
        if (target === 'revenue') uiState.chartMode = 'revenue';
        else if (target === 'mrr') uiState.chartMode = 'mrr';
        else if (target === 'stores') uiState.chartMode = 'sectors';
        else if (target === 'products') uiState.chartMode = 'stores';
        renderCmdPanel();
      };
    }

    var handlePlanToggle = function (e) {
      var el = e.target.closest('[data-cmd-plan]');
      if (!el) return;
      var pk = el.getAttribute('data-cmd-plan');
      uiState.cmdSpotlightPlan = (uiState.cmdSpotlightPlan === pk) ? 'all' : pk;
      uiState.chartFocusIdx = -1;
      renderCmdPanel();
    };

    var pmGrid = $('#cmdPlansMatrix', box);
    if (pmGrid) pmGrid.onclick = handlePlanToggle;

    var dLeg = $('#cmdDonutLegend', box);
    if (dLeg) dLeg.onclick = handlePlanToggle;

    var rstBtn = $('#cmdResetPlanFilterBtn', box);
    if (rstBtn) {
      rstBtn.onclick = function () {
        uiState.cmdSpotlightPlan = 'all';
        uiState.chartFocusIdx = -1;
        renderCmdPanel();
      };
    }
  }

  /* =========================================================================
     2. القائمة الثانية: إدارة المتاجر (#panel-stores)
        • المتاجر مرتبة واحداً تحت الآخر بتناسق هندسي 100% لجميع الأعمدة والشارات والأزرار
        • إضافة زر المتجر وزر التاجر وزر إدارة المتجر في كل شريط متجر
     ========================================================================= */
  function renderStoresPanel() {
    var box = $('#panel-stores');
    if (!box) return;

    if (uiState.selectedStoreSlug && masterStores[uiState.selectedStoreSlug]) {
      renderSingleStoreManagementView(box, masterStores[uiState.selectedStoreSlug]);
      return;
    }
    uiState.selectedStoreSlug = null;

    var slugs = Object.keys(masterStores);
    var q = uiState.storeSearch.trim().toLowerCase();

    var filtered = slugs.map(function (s) { return masterStores[s]; }).filter(function (st) {
      var stStatus = getStoreStatusInfo(st);
      var stType = getStoreTypeInfo(st);
      var stPlan = getStorePlanInfo(st);
      var pCount = getStoreProductCount(st);

      if (q) {
        var hay = [st.name, st.slug, st.serialId, st.ownerName, st.whatsapp, st.ownerPhone, stType.title].join(' ').toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      if (uiState.storePlanFilter !== 'all' && stPlan.id !== uiState.storePlanFilter) return false;
      if (uiState.storeStatusFilter !== 'all' && stStatus.key !== uiState.storeStatusFilter) return false;
      if (uiState.storeTypeFilter !== 'all' && stType.id !== uiState.storeTypeFilter) return false;
      if (uiState.storeProdSort === 'over20' && pCount < 20) return false;
      if (uiState.storeProdSort === 'under20' && pCount >= 20) return false;
      return true;
    });

    filtered.sort(function (a, b) {
      if (uiState.storeProdSort === 'high') return getStoreProductCount(b) - getStoreProductCount(a);
      if (uiState.storeProdSort === 'low') return getStoreProductCount(a) - getStoreProductCount(b);
      var da = String(a.createdAt || '2026-01-01');
      var db = String(b.createdAt || '2026-01-01');
      if (uiState.storeSort === 'oldest') return da.localeCompare(db);
      return db.localeCompare(da);
    });

    var planOptions = Object.keys(masterPlans).map(function (k) {
      var pl = masterPlans[k];
      return '<option value="' + esc(k) + '"' + (uiState.storePlanFilter === k ? ' selected' : '') + '>الاشتراك: ' + esc(pl.name) + '</option>';
    }).join('');

    var typeOptions = Object.keys(storeTypes).map(function (k) {
      var tp = storeTypes[k];
      return '<option value="' + esc(k) + '"' + (uiState.storeTypeFilter === k ? ' selected' : '') + '>النوع: ' + esc(tp.shortTitle || tp.title) + '</option>';
    }).join('');

    var stackHtml = filtered.length ? filtered.map(function (st) {
      var stStatus = getStoreStatusInfo(st);
      var stType = getStoreTypeInfo(st);
      var stPlan = getStorePlanInfo(st);
      var links = getStoreLinks(st);
      var pCount = getStoreProductCount(st);
      var avatarHtml = st.logo
        ? '<img src="' + esc(st.logo) + '" alt="' + esc(st.name) + '" onerror="this.remove()">'
        : esc((st.name || 'م').replace(/^(متجر|بوتيك|دار|معرض)\s+/, '').trim().charAt(0));

      return '<div class="apple-store-row">' +
        '<div class="asr-identity">' +
          '<div class="asr-avatar" style="background:' + esc((st.theme && st.theme.primary) || stType.color) + '">' + avatarHtml + '</div>' +
          '<div class="asr-title-wrap">' +
            '<span class="asr-name">' + esc(st.name) + '</span>' +
            '<div class="asr-sub">' +
              '<span class="asr-code-chip" dir="ltr">' + esc(st.serialId || st.slug) + '</span>' +
              '<span class="asr-owner-txt">' + esc(st.ownerName || 'حساب تاجر معتمد') + '</span>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div class="asr-col-cell">' +
          '<span class="sym-badge asr-uniform-badge st-type" title="عدد المنتجات">📦 ' + pCount + ' منتج</span>' +
        '</div>' +

        '<div class="asr-col-cell">' +
          '<span class="sym-badge asr-uniform-badge ' + stStatus.cls + '" title="حالة المتجر">' + stStatus.icon + ' ' + esc(stStatus.label) + '</span>' +
        '</div>' +

        '<div class="asr-col-cell">' +
          '<span class="sym-badge asr-uniform-badge st-plan" style="color:' + esc(stPlan.color) + ';background:' + esc(stPlan.color) + '14;border-color:' + esc(stPlan.color) + '30" title="باقة الاشتراك">' + esc(stPlan.icon) + ' ' + esc(stPlan.name) + '</span>' +
        '</div>' +

        '<div class="asr-col-cell">' +
          '<span class="sym-badge asr-uniform-badge st-type" title="نوع المتجر">' + esc(stType.icon) + ' ' + esc(stType.title) + '</span>' +
        '</div>' +

        '<div class="asr-actions">' +
          '<a class="btn btn-ghost btn-sm asr-act-btn" href="' + esc(links.storeUrl) + '" target="_blank" rel="noopener" title="فتح المتجر للزبائن">🛍️ المتجر</a>' +
          '<a class="btn btn-ok btn-sm asr-act-btn" href="' + esc(links.ownerAdminUrl) + '" target="_blank" rel="noopener" title="فتح لوحة تحكم التاجر">👤 التاجر</a>' +
          '<button type="button" class="btn btn-primary btn-sm asr-act-btn asr-manage-btn" data-manage-slug="' + esc(st.slug) + '">⚙️ إدارة المتجر</button>' +
        '</div>' +
      '</div>';
    }).join('') : '<div class="card" style="text-align:center;padding:48px;color:var(--muted)">لا توجد متاجر مطابقة لمعايير البحث أو الفلترة الحالية.</div>';

    box.innerHTML =
      '<div class="page-hdr">' +
        '<div class="page-hdr-title">' +
          '<h2>🏪 إدارة المتاجر (' + filtered.length + ' من ' + slugs.length + ')</h2>' +
          '<p>قائمة المتاجر مصفوفة بتناسق قياسي واحد تحت الآخر — تشمل أزرار المتجر والتاجر وإدارة المتجر الكاملة</p>' +
        '</div>' +
      '</div>' +

      '<div class="smart-filter-bar">' +
        '<input type="search" class="sf-input" id="sfSearchInp" placeholder="🔍 بحث ذكي بالاسم، الكود (ID)، اسم المالك، أو الهاتف..." value="' + esc(uiState.storeSearch) + '">' +
        '<select class="sf-select" id="sfSortSel">' +
          '<option value="newest"' + (uiState.storeSort === 'newest' ? ' selected' : '') + '>الترتيب: من الأحدث إلى الأقدم</option>' +
          '<option value="oldest"' + (uiState.storeSort === 'oldest' ? ' selected' : '') + '>الترتيب: من الأقدم إلى الأحدث</option>' +
        '</select>' +
        '<select class="sf-select" id="sfPlanSel">' +
          '<option value="all">الاشتراك: جميع الباقات</option>' +
          planOptions +
        '</select>' +
        '<select class="sf-select" id="sfStatusSel">' +
          '<option value="all"' + (uiState.storeStatusFilter === 'all' ? ' selected' : '') + '>الحالة: كل الحالات</option>' +
          '<option value="active"' + (uiState.storeStatusFilter === 'active' ? ' selected' : '') + '>🟢 الفعّالة فقط</option>' +
          '<option value="expiring"' + (uiState.storeStatusFilter === 'expiring' ? ' selected' : '') + '>⏳ قريبة الانتهاء</option>' +
          '<option value="locked"' + (uiState.storeStatusFilter === 'locked' ? ' selected' : '') + '>🔒 المقفولة / المنتهية</option>' +
        '</select>' +
        '<select class="sf-select" id="sfTypeSel">' +
          '<option value="all">النوع: كل أنواع المتاجر</option>' +
          typeOptions +
        '</select>' +
        '<select class="sf-select" id="sfProdSel">' +
          '<option value="all"' + (uiState.storeProdSort === 'all' ? ' selected' : '') + '>المنتجات: الكل</option>' +
          '<option value="high"' + (uiState.storeProdSort === 'high' ? ' selected' : '') + '>📦 الأكثر منتجات أولاً</option>' +
          '<option value="low"' + (uiState.storeProdSort === 'low' ? ' selected' : '') + '>📦 الأقل منتجات أولاً</option>' +
          '<option value="over20"' + (uiState.storeProdSort === 'over20' ? ' selected' : '') + '>أكثر من 20 منتج</option>' +
          '<option value="under20"' + (uiState.storeProdSort === 'under20' ? ' selected' : '') + '>أقل من 20 منتج</option>' +
        '</select>' +
      '</div>' +

      '<div class="apple-stores-stack" id="appleStoresStack">' + stackHtml + '</div>';

    $('#sfSearchInp', box).oninput = function (e) {
      uiState.storeSearch = e.target.value;
      renderStoresPanel();
      var inp = $('#sfSearchInp', box);
      if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
    };
    $('#sfSortSel', box).onchange = function (e) { uiState.storeSort = e.target.value; renderStoresPanel(); };
    $('#sfPlanSel', box).onchange = function (e) { uiState.storePlanFilter = e.target.value; renderStoresPanel(); };
    $('#sfStatusSel', box).onchange = function (e) { uiState.storeStatusFilter = e.target.value; renderStoresPanel(); };
    $('#sfTypeSel', box).onchange = function (e) { uiState.storeTypeFilter = e.target.value; renderStoresPanel(); };
    $('#sfProdSel', box).onchange = function (e) { uiState.storeProdSort = e.target.value; renderStoresPanel(); };

    $('#appleStoresStack', box).onclick = function (e) {
      var btn = e.target.closest('button[data-manage-slug]');
      if (!btn) return;
      uiState.selectedStoreSlug = btn.getAttribute('data-manage-slug');
      uiState.storeDetailTab = 'identity';
      renderStoresPanel();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
  }

  /* ---------- واجهة إدارة المتجر الكاملة والمرتبة بأسلوب إعدادات أبل (Apple System Settings) ---------- */
  function compressImageFile(file, maxSide, quality, cb) {
    var reader = new FileReader();
    reader.onload = function (e) {
      var img = new Image();
      img.onload = function () {
        var w = img.width, h = img.height;
        if (w > maxSide || h > maxSide) {
          if (w > h) { h = Math.round(h * maxSide / w); w = maxSide; }
          else { w = Math.round(w * maxSide / h); h = maxSide; }
        }
        var canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        cb(canvas.toDataURL('image/jpeg', quality || 0.84));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  function syncStoreToTenantCache(st) {
    try {
      var key = 'store_data_' + st.slug;
      var raw = localStorage.getItem(key);
      if (raw) {
        var parsed = JSON.parse(raw);
        parsed.name = st.name;
        parsed.logo = st.logo || '';
        parsed.tagline = st.tagline || parsed.tagline;
        parsed.templateId = st.templateId || 'fashion';
        parsed.whatsapp = st.whatsapp;
        parsed.instagram = (st.socials && st.socials.instagram) || st.instagram || '';
        parsed.socials = st.socials || {};
        parsed.adminPin = st.adminPin || '1234';
        parsed.subscription = st.subscription;
        if (st.categories && st.categories.length) parsed.categories = st.categories;
        if (st.customSizePresets) parsed.customSizePresets = st.customSizePresets;
        if (st.customColorPresets) parsed.customColorPresets = st.customColorPresets;
        localStorage.setItem(key, JSON.stringify(parsed));
      }
    } catch (e) { }
  }

  function openHandoverCardModal(st) {
    var links = getStoreLinks(st);
    var stPlan = getStorePlanInfo(st);
    var stType = getStoreTypeInfo(st);
    var qrImg = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' + encodeURIComponent(links.storeUrl);

    var bodyHtml =
      '<div style="text-align:center;padding:6px 0">' +
        '<img src="' + qrImg + '" alt="QR" style="width:156px;height:156px;border-radius:18px;border:1px solid var(--border);padding:8px;background:#fff;margin-bottom:10px;box-shadow:var(--shadow-sm)">' +
        '<h4 style="font-size:1.12rem;font-weight:900;margin-bottom:4px">' + esc(st.name) + ' (' + esc(st.serialId || st.slug) + ')</h4>' +
        '<p style="font-size:0.82rem;color:var(--muted);margin-bottom:12px">' + esc(stType.icon + ' ' + stType.fullTitle) + ' · الباقة: ' + esc(stPlan.name) + '</p>' +
        '<div style="background:var(--surface-2);border:1px solid var(--border);border-radius:16px;padding:14px;text-align:right;font-size:0.84rem;display:flex;flex-direction:column;gap:8px">' +
          '<div><b>👤 المالك:</b> ' + esc(st.ownerName || '—') + ' (<span dir="ltr">' + esc(st.whatsapp || '') + '</span>)</div>' +
          '<div><b>🔑 الرمز السري للتاجر (PIN):</b> <code style="background:#EEF2FF;color:#4F46E5;padding:2px 9px;border-radius:8px;font-weight:900">' + esc(st.adminPin || '1234') + '</code></div>' +
          '<div><b>🛍️ رابط المتجر للزبائن:</b><input readonly dir="ltr" value="' + esc(links.storeUrl) + '" style="width:100%;margin-top:4px;padding:7px 10px;border-radius:10px;border:1px solid var(--border);background:#fff;font-size:0.78rem"></div>' +
          '<div><b>⚙️ رابط لوحة تحكم التاجر:</b><input readonly dir="ltr" value="' + esc(links.adminUrl) + '" style="width:100%;margin-top:4px;padding:7px 10px;border-radius:10px;border:1px solid var(--border);background:#fff;font-size:0.78rem"></div>' +
        '</div>' +
      '</div>';

    var waText = [
      '🎉 *بطاقة تسليم متجرك الإلكتروني الجاهز*',
      '━━━━━━━━━━━━━━',
      '🏪 اسم المتجر: *' + st.name + '*',
      '🆔 كود المتجر: *' + (st.serialId || st.slug) + '*',
      '📦 الباقة المفعلة: *' + stPlan.name + '*',
      '🔑 الرمز السري للوحة التحكم (PIN): *' + (st.adminPin || '1234') + '*',
      '━━━━━━━━━━━━━━',
      '🛍️ *رابط المتجر للزبائن (يوضع في بايو الصفحة):*',
      links.storeUrl,
      '',
      '⚙️ *رابط لوحة التحكم الخاصة بك (لإضافة وتعديل المنتجات):*',
      links.adminUrl
    ].join('\n');

    UI.modal({
      title: 'بطاقة التسليم الرسمية وباركود QR',
      icon: '🎁',
      width: '540px',
      html: bodyHtml,
      actions: [
        { text: 'إغلاق', className: 'ui-btn-ghost' },
        {
          text: '📋 نسخ بطاقة التسليم كاملة',
          className: 'ui-btn-primary',
          keepOpen: true,
          onClick: function () { UI.copy(waText, 'تم نسخ بطاقة التسليم كاملة ✓'); }
        },
        {
          text: '💬 إرسال البطاقة عبر واتساب للتاجر',
          className: 'ui-btn-ok',
          onClick: function () {
            var num = String(st.whatsapp || st.ownerPhone || '').replace(/\D/g, '');
            window.open('https://wa.me/' + num + '?text=' + encodeURIComponent(waText), '_blank');
          }
        }
      ]
    });
  }

  function renderSingleStoreManagementView(box, st) {
    if (!st.subscription) st.subscription = { plan: 'monthly', expires: addDaysISO(30), graceDays: 3 };
    if (!st.socials) st.socials = {};
    if (!st.subscriptionHistory || !st.subscriptionHistory.length) {
      st.subscriptionHistory = [{
        date: st.createdAt || todayISO(),
        plan: st.subscription.plan || 'monthly',
        amount: getStorePlanInfo(st).price,
        note: 'تفعيل الاشتراك الأساسي'
      }];
    }

    var stStatus = getStoreStatusInfo(st);
    var stType = getStoreTypeInfo(st);
    var stPlan = getStorePlanInfo(st);
    var links = getStoreLinks(st);
    var pCount = getStoreProductCount(st);
    var activeTypeObj = storeTypes[st.templateId || 'fashion'] || DEFAULT_STORE_TYPES.fashion;
    var typeSizePresets = (st.customSizePresets && st.customSizePresets.length) ? st.customSizePresets : (activeTypeObj.sizePresets || []);
    var typeColorPresets = (st.customColorPresets && st.customColorPresets.length) ? st.customColorPresets : (activeTypeObj.colorPresets || []);

    var validTabs = ['identity', 'owner', 'subs', 'security'];
    var curTab = validTabs.indexOf(uiState.storeDetailTab) !== -1 ? uiState.storeDetailTab : 'identity';

    var avatarHtml = st.logo
      ? '<img src="' + esc(st.logo) + '" alt="' + esc(st.name) + '">'
      : esc((st.name || 'م').replace(/^(متجر|بوتيك|دار|معرض)\s+/, '').trim().charAt(0));

    var typeOptionsHtml = Object.keys(storeTypes).map(function (k) {
      var tp = storeTypes[k];
      return '<option value="' + esc(k) + '"' + ((st.templateId || 'fashion') === k ? ' selected' : '') + '>' + esc(tp.icon + ' ' + tp.title) + '</option>';
    }).join('');

    var planButtonsHtml = Object.keys(masterPlans).map(function (k) {
      var pl = masterPlans[k];
      var isCurr = (st.subscription && st.subscription.plan === k);
      return '<button type="button" class="btn ' + (isCurr ? 'btn-primary' : 'btn-ghost') + ' btn-sm" style="justify-content:flex-start" data-activate-plan="' + esc(k) + '">' +
        esc(pl.icon || '💎') + ' ' + esc(pl.name) + ' (' + (pl.price > 0 ? fmt(pl.price) : 'مجاناً') + ')' +
      '</button>';
    }).join('');

    var historyRowsHtml = st.subscriptionHistory.slice().reverse().slice(0, 5).map(function (h, idx) {
      var plObj = masterPlans[h.plan] || DEFAULT_PLANS[h.plan] || { name: h.plan };
      return '<tr>' +
        '<td style="width:12%"><b>#' + (st.subscriptionHistory.length - idx) + '</b></td>' +
        '<td style="width:24%">' + esc(plObj.name || h.plan) + '</td>' +
        '<td style="width:22%"><b>' + fmt(h.amount || 0) + '</b></td>' +
        '<td style="width:20%" dir="ltr">' + esc(h.date || '—') + '</td>' +
        '<td style="width:22%">' + esc(h.note || 'تجديد باقة') + '</td>' +
      '</tr>';
    }).join('');

    var lockReasonsHtml = (cfg.lockReasons || DEFAULT_LOCK_REASONS).map(function (r) {
      var sel = (st.subscription && st.subscription.suspendReason === r) ? ' selected' : '';
      return '<option value="' + esc(r) + '"' + sel + '>' + esc(r) + '</option>';
    }).join('');

    box.innerHTML =
      '<div class="apple-store-manager">' +

        '<!-- الرأس العلوي المدمج للمتجر على قياس 100% -->' +
        '<div class="asm-hero-card">' +
          '<div class="asm-hero-right">' +
            '<div class="asm-avatar" style="background:' + esc((st.theme && st.theme.primary) || stType.color) + '">' + avatarHtml + '</div>' +
            '<div>' +
              '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-bottom:3px">' +
                '<h2 style="font-size:1.18rem;font-weight:900">' + esc(st.name) + '</h2>' +
                '<span class="sym-badge st-type" dir="ltr">ID: ' + esc(st.serialId || st.slug) + '</span>' +
                '<span class="sym-badge ' + stStatus.cls + '">' + stStatus.icon + ' ' + esc(stStatus.label) + '</span>' +
                '<span class="sym-badge st-plan">' + esc(stPlan.icon + ' ' + stPlan.name) + '</span>' +
                '<span class="sym-badge st-type">' + esc(stType.icon + ' ' + stType.shortTitle) + '</span>' +
              '</div>' +
              '<p style="font-size:0.76rem;color:var(--muted)">' +
                '📅 التسجيل: <b dir="ltr">' + esc(st.createdAt || todayISO()) + '</b> · ' +
                '🔄 الاشتراكات: <b>' + st.subscriptionHistory.length + '</b> · ' +
                '📦 المنتجات: <b>' + pCount + ' منتج</b>' +
              '</p>' +
            '</div>' +
          '</div>' +
          '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">' +
            '<button type="button" class="btn btn-ghost btn-sm" id="sdvHandoverTopBtn">🎁 بطاقة التسليم</button>' +
            '<a class="btn btn-ok btn-sm" href="' + esc(links.ownerAdminUrl) + '" target="_blank">⚙️ لوحة التاجر</a>' +
            '<a class="btn btn-primary btn-sm" href="' + esc(links.storeUrl) + '" target="_blank">🛍️ فتح المتجر</a>' +
            '<button type="button" class="btn btn-ghost btn-sm" id="sdvBackBtn">← رجوع للمتاجر</button>' +
          '</div>' +
        '</div>' +

        '<!-- التبويبات الأربع المدمجة بنسبة 100% بدون أي شريط تمرير -->' +
        '<div class="apple-seg-bar" id="sdvSegBar">' +
          '<button type="button" class="apple-seg-btn ' + (curTab === 'identity' ? 'active' : '') + '" data-stab="identity">🏷️ 1. الهوية والنوع والقياسات</button>' +
          '<button type="button" class="apple-seg-btn ' + (curTab === 'owner' ? 'active' : '') + '" data-stab="owner">👤 2. المالك والتواصل الاجتماعي</button>' +
          '<button type="button" class="apple-seg-btn ' + (curTab === 'subs' ? 'active' : '') + '" data-stab="subs">📅 3. سجل وتجديد الاشتراكات</button>' +
          '<button type="button" class="apple-seg-btn ' + (curTab === 'security' ? 'active' : '') + '" data-stab="security">🔐 4. الروابط والصلاحيات وقفل المتجر</button>' +
        '</div>' +

        '<!-- التبويب 1: الهوية ونوع المتجر والقياسات (منسق بعمودين بدون أي سلايد) -->' +
        '<div class="apple-settings-group" data-tab-panel="identity" style="display:' + (curTab === 'identity' ? 'block' : 'none') + '">' +
          '<div class="asg-header">' +
            '<h3><span class="asg-num">1</span> هوية المتجر ونوعه (تحديث القياسات والألوان تلقائياً حسب النوع)</h3>' +
            '<span class="sym-badge st-type">النوع الفعال: ' + esc(activeTypeObj.icon + ' ' + activeTypeObj.title) + '</span>' +
          '</div>' +
          '<div class="asg-body">' +
            '<div class="bento-2col">' +
              '<div class="sub-box">' +
                '<div class="sub-box-title"><span>🏪 البيانات الأساسية ونوع المتجر</span></div>' +
                '<div style="display:flex;align-items:center;gap:10px;padding:6px 10px;background:var(--surface);border-radius:12px;border:1px solid var(--border)">' +
                  '<div class="asr-avatar" style="width:42px;height:42px;font-size:1rem;background:' + esc((st.theme && st.theme.primary) || stType.color) + '">' + avatarHtml + '</div>' +
                  '<div style="flex:1;min-width:0">' +
                    '<b style="font-size:0.8rem;display:block">شعار / صورة المتجر</b>' +
                    '<span style="font-size:0.71rem;color:var(--muted)">تظهر في واجهة المتجر وبطاقة التسليم</span>' +
                  '</div>' +
                  '<input type="file" id="sdvLogoInput" accept="image/*" style="display:none">' +
                  '<button type="button" class="btn btn-ghost btn-sm" id="sdvPickLogoBtn">📷 تغيير</button>' +
                  (st.logo ? '<button type="button" class="btn btn-danger btn-sm" id="sdvDelLogoBtn">حذف</button>' : '') +
                '</div>' +
                '<div class="form-grid">' +
                  '<label class="fld"><span>اسم المتجر الرسمي</span><input id="sdvName" value="' + esc(st.name) + '"></label>' +
                  '<label class="fld"><span>نوع المتجر (يغير القياسات فوراً)</span><select id="sdvTypeSelect">' + typeOptionsHtml + '</select></label>' +
                  '<label class="fld" style="grid-column:1/-1"><span>الوصف الترويجي أسفل اسم المتجر</span><input id="sdvTagline" value="' + esc(st.tagline || '') + '"></label>' +
                '</div>' +
              '</div>' +

              '<div class="sub-box">' +
                '<div class="sub-box-title"><span>📐 القياسات والألوان المطبقة تلقائياً</span><small style="color:var(--muted);font-weight:700">' + typeSizePresets.length + ' قوائم قياس</small></div>' +
                '<div>' +
                  '<span style="font-size:0.75rem;font-weight:800;color:var(--muted);display:block;margin-bottom:5px">قوائم القياسات الفعّالة لهذا النوع:</span>' +
                  '<div class="preset-pill-list">' +
                    typeSizePresets.map(function (sp) {
                      return '<span class="preset-pill">📐 <b>' + esc(sp.label) + ':</b> ' + esc((sp.sizes || []).join('، ')) + '</span>';
                    }).join('') +
                  '</div>' +
                '</div>' +
                '<div style="margin-top:4px">' +
                  '<span style="font-size:0.75rem;font-weight:800;color:var(--muted);display:block;margin-bottom:5px">لوحة الألوان المعتمدة:</span>' +
                  '<div class="preset-pill-list">' +
                    typeColorPresets.map(function (c) {
                      return '<span class="preset-pill"><i style="width:10px;height:10px;border-radius:50%;background:' + esc(c.hex) + ';display:inline-block"></i> ' + esc(c.name) + '</span>';
                    }).join('') +
                  '</div>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div class="asg-footer">' +
            '<span style="font-size:0.75rem;color:var(--muted)">💡 تغيير نوع المتجر يحدّث القياسات والألوان فوراً داخل لوحة التاجر</span>' +
            '<button type="button" class="btn btn-primary" id="sdvSaveIdentityBtn">💾 حفظ الهوية ونوع المتجر وتطبيق القياسات</button>' +
          '</div>' +
        '</div>' +

        '<!-- التبويب 2: المالك وحسابات التواصل الاجتماعي (منسق بـ 3 أعمدة أنيقة) -->' +
        '<div class="apple-settings-group" data-tab-panel="owner" style="display:' + (curTab === 'owner' ? 'block' : 'none') + '">' +
          '<div class="asg-header">' +
            '<h3><span class="asg-num">2</span> بيانات صاحب المتجر وحسابات التواصل الاجتماعي (عجلة تابعنا الدوّارة 🎡)</h3>' +
          '</div>' +
          '<div class="asg-body">' +
            '<div class="bento-3col">' +
              '<label class="fld"><span>👤 اسم صاحب المتجر</span><input id="sdvOwnerName" value="' + esc(st.ownerName || '') + '" placeholder="الاسم الكامل للتاجر"></label>' +
              '<label class="fld"><span>📞 رقم الهاتف الشخصي</span><input id="sdvOwnerPhone" dir="ltr" value="' + esc(st.ownerPhone || st.whatsapp || '') + '" placeholder="0770XXXXXXX"></label>' +
              '<label class="fld"><span>💬 واتساب الطلبات (مع 964)</span><input id="sdvWhatsapp" dir="ltr" value="' + esc(st.whatsapp || '') + '" placeholder="964770XXXXXXX"></label>' +
              '<label class="fld"><span>📸 حساب إنستغرام (Instagram)</span><input id="sdvSocIg" dir="ltr" value="' + esc(st.socials.instagram || st.instagram || '') + '" placeholder="@username أو الرابط"></label>' +
              '<label class="fld"><span>📘 صفحة فيسبوك (Facebook)</span><input id="sdvSocFb" dir="ltr" value="' + esc(st.socials.facebook || '') + '" placeholder="https://facebook.com/..."></label>' +
              '<label class="fld"><span>✈️ قناة تلجرام (Telegram)</span><input id="sdvSocTg" dir="ltr" value="' + esc(st.socials.telegram || '') + '" placeholder="https://t.me/..."></label>' +
              '<label class="fld"><span>🎵 حساب تيك توك (TikTok)</span><input id="sdvSocTk" dir="ltr" value="' + esc(st.socials.tiktok || '') + '" placeholder="@tiktok"></label>' +
              '<label class="fld" style="grid-column:span 2"><span>📢 قناة واتساب الرسمية (WhatsApp Channel)</span><input id="sdvSocWa" dir="ltr" value="' + esc(st.socials.whatsappChannel || '') + '" placeholder="https://whatsapp.com/channel/..."></label>' +
            '</div>' +
          '</div>' +
          '<div class="asg-footer">' +
            '<span style="font-size:0.75rem;color:var(--muted)">🎡 جميع الروابط المضافة تظهر تلقائياً في زر (تابعنا) الدوّار داخل المتجر</span>' +
            '<button type="button" class="btn btn-primary" id="sdvSaveOwnerSocialBtn">💾 حفظ بيانات المالك وحسابات التواصل</button>' +
          '</div>' +
        '</div>' +

        '<!-- التبويب 3: سجل وتجديد الاشتراكات (منسق بعمودين متوازنين) -->' +
        '<div class="apple-settings-group" data-tab-panel="subs" style="display:' + (curTab === 'subs' ? 'block' : 'none') + '">' +
          '<div class="asg-header">' +
            '<h3><span class="asg-num">3</span> تاريخ التسجيل وتجديد وسجل الاشتراكات (' + st.subscriptionHistory.length + ' اشتراك)</h3>' +
            '<span class="sym-badge st-plan">' + esc(stPlan.icon + ' الباقة الحالية: ' + stPlan.name) + '</span>' +
          '</div>' +
          '<div class="asg-body">' +
            '<div class="bento-2col">' +
              '<div class="sub-box">' +
                '<div class="sub-box-title"><span>⚡ التواريخ والتجديد الفوري للباقة</span></div>' +
                '<div class="form-grid">' +
                  '<label class="fld"><span>📅 تاريخ تسجيل المتجر</span><input type="date" id="sdvCreatedAt" value="' + esc(st.createdAt || todayISO()) + '"></label>' +
                  '<label class="fld"><span>⏳ تاريخ انتهاء الباقة</span><input type="date" id="sdvExpiresAt" value="' + esc((st.subscription && st.subscription.expires !== 'lifetime') ? st.subscription.expires : '2099-12-31') + '"></label>' +
                '</div>' +
                '<div>' +
                  '<span style="font-size:0.75rem;font-weight:800;color:var(--muted);display:block;margin-bottom:6px">اضغط على أي باقة لتفعيلها فوراً وتسجيلها مالياً:</span>' +
                  '<div id="sdvPlanBtns" style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px">' + planButtonsHtml + '</div>' +
                '</div>' +
              '</div>' +

              '<div class="sub-box">' +
                '<div class="sub-box-title"><span>📜 سجل اشتراكات المتجر</span><small style="color:var(--muted)">آخر العمليات</small></div>' +
                '<div class="table-wrap">' +
                  '<table class="data-table">' +
                    '<thead><tr><th style="width:12%">#</th><th style="width:24%">الباقة</th><th style="width:22%">المبلغ</th><th style="width:20%">التاريخ</th><th style="width:22%">البيان</th></tr></thead>' +
                    '<tbody>' + historyRowsHtml + '</tbody>' +
                  '</table>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<!-- التبويب 4 (دمج التبويبين 4 و 5): الروابط والصلاحيات والـ PIN + قفل وحذف المتجر في واجهة واحدة بعمودين -->' +
        '<div class="apple-settings-group" data-tab-panel="security" style="display:' + (curTab === 'security' ? 'block' : 'none') + '">' +
          '<div class="asg-header">' +
            '<h3><span class="asg-num">4</span> الروابط المباشرة، الصلاحيات، الرمز السري (PIN)، وقفل أو حذف المتجر</h3>' +
            '<span class="sym-badge ' + stStatus.cls + '">' + stStatus.icon + ' ' + esc(stStatus.label) + '</span>' +
          '</div>' +
          '<div class="asg-body">' +
            '<div class="bento-2col">' +

              '<!-- القسم الأيمن: الروابط والصلاحيات والرمز السري -->' +
              '<div class="sub-box">' +
                '<div class="sub-box-title">' +
                  '<span>🔗 الروابط والصلاحيات والرمز السري (PIN)</span>' +
                  '<button type="button" class="btn btn-ok btn-sm" id="sdvHandoverBtn">🎁 بطاقة التسليم و QR</button>' +
                '</div>' +
                '<div class="fld">' +
                  '<span>🛍️ رابط المتجر المباشر للزبائن (يوضع في البايو)</span>' +
                  '<div style="display:flex;gap:6px">' +
                    '<input readonly dir="ltr" value="' + esc(links.storeUrl) + '" style="flex:1">' +
                    '<button type="button" class="btn btn-ghost btn-sm" id="sdvCopyStoreUrl">📋 نسخ</button>' +
                  '</div>' +
                '</div>' +
                '<div class="fld">' +
                  '<span>⚙️ رابط لوحة تحكم التاجر</span>' +
                  '<div style="display:flex;gap:6px">' +
                    '<input readonly dir="ltr" value="' + esc(links.adminUrl) + '" style="flex:1">' +
                    '<button type="button" class="btn btn-ghost btn-sm" id="sdvCopyAdminUrl">📋 نسخ</button>' +
                  '</div>' +
                '</div>' +
                '<div class="form-grid">' +
                  '<label class="fld"><span>🔑 الرمز السري للتاجر (PIN)</span><input id="sdvAdminPin" dir="ltr" value="' + esc(st.adminPin || '1234') + '"></label>' +
                  '<label class="fld"><span>📦 سعة المنتجات (0 = مفتوح)</span><input type="number" id="sdvMaxProducts" value="' + esc((st.subscription && st.subscription.maxProducts) || 0) + '"></label>' +
                '</div>' +
                '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding-top:4px">' +
                  '<div style="display:flex;gap:14px;flex-wrap:wrap;font-size:0.79rem;font-weight:800">' +
                    '<label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="sdvAllowCoupons"' + ((!st.features || st.features.coupons !== false) ? ' checked' : '') + '> تفعيل الكوبونات</label>' +
                    '<label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="sdvHideBranding"' + ((st.subscription && st.subscription.hideBranding) ? ' checked' : '') + '> إخفاء شعار المنصة</label>' +
                  '</div>' +
                  '<button type="button" class="btn btn-primary btn-sm" id="sdvSavePermsBtn">💾 حفظ الصلاحيات والـ PIN</button>' +
                '</div>' +
              '</div>' +

              '<!-- القسم الأيسر: قفل المتجر بخيارات المشاكل والحذف النهائي -->' +
              '<div class="sub-box" style="border-color:rgba(239,68,68,0.28);background:var(--danger-soft)">' +
                '<div class="sub-box-title" style="color:var(--danger)">' +
                  '<span>🔒 قفل المتجر بخيارات المشاكل والحذف النهائي</span>' +
                '</div>' +
                '<label class="fld">' +
                  '<span>سبب قفل / إيقاف المتجر (يظهر للتاجر والزبائن عند القفل)</span>' +
                  '<select id="sdvLockReasonSelect">' + lockReasonsHtml + '</select>' +
                '</label>' +
                '<div class="fld">' +
                  '<span>تسجيل خيار مشكلة جديد وتثبيته دائماً في القائمة</span>' +
                  '<div style="display:flex;gap:6px">' +
                    '<input id="sdvNewReasonInp" placeholder="اكتب سبب مشكلة أو قفل جديد..." style="flex:1">' +
                    '<button type="button" class="btn btn-ghost btn-sm" id="sdvAddReasonBtn">+ تسجيل وحفظ</button>' +
                  '</div>' +
                '</div>' +
                '<div style="margin-top:auto;padding-top:8px;border-top:1px solid rgba(239,68,68,0.18);display:flex;gap:8px;justify-content:space-between;flex-wrap:wrap">' +
                  (st.subscription && st.subscription.suspended
                    ? '<button type="button" class="btn btn-ok" style="flex:1" id="sdvToggleLockBtn">🔓 إلغاء القفل وتفعيل المتجر</button>'
                    : '<button type="button" class="btn btn-warn" style="flex:1" id="sdvToggleLockBtn">🔒 قفل المتجر بالسبب المحدد</button>') +
                  '<button type="button" class="btn btn-danger" id="sdvDeleteStoreBtn">🗑️ حذف المتجر نهائياً</button>' +
                '</div>' +
              '</div>' +

            '</div>' +
          '</div>' +
        '</div>' +

      '</div>';

    // أحداث شريط التنقل المقسم داخل إعدادات المتجر (تبديل فوري فائق السلاسة بدون إعادة بناء الصفحة)
    $('#sdvSegBar', box).onclick = function (e) {
      var b = e.target.closest('button[data-stab]');
      if (!b) return;
      var targetTab = b.getAttribute('data-stab');
      uiState.storeDetailTab = targetTab;
      $$('button[data-stab]', box).forEach(function (btn) {
        btn.classList.toggle('active', btn === b);
      });
      $$('.apple-settings-group[data-tab-panel]', box).forEach(function (grp) {
        grp.style.display = grp.getAttribute('data-tab-panel') === targetTab ? 'block' : 'none';
      });
    };

    $('#sdvBackBtn', box).onclick = function () {
      uiState.selectedStoreSlug = null;
      renderStoresPanel();
    };
    $('#sdvHandoverTopBtn', box).onclick = function () { openHandoverCardModal(st); };

    $('#sdvPickLogoBtn', box).onclick = function () { $('#sdvLogoInput', box).click(); };
    $('#sdvLogoInput', box).onchange = function (e) {
      var file = (e.target.files || [])[0];
      if (!file) return;
      compressImageFile(file, 320, 0.85, function (dataUrl) {
        st.logo = dataUrl;
        syncStoreToTenantCache(st);
        saveAllState();
        UI.toast('تم تحديث صورة المتجر بنجاح ✓', 'success');
        renderStoresPanel();
      });
    };
    var delLogoBtn = $('#sdvDelLogoBtn', box);
    if (delLogoBtn) {
      delLogoBtn.onclick = function () {
        delete st.logo;
        syncStoreToTenantCache(st);
        saveAllState();
        UI.toast('تم حذف صورة المتجر', 'info');
        renderStoresPanel();
      };
    }

    $('#sdvTypeSelect', box).onchange = function (e) {
      var newType = e.target.value;
      var tpObj = storeTypes[newType] || DEFAULT_STORE_TYPES[newType] || DEFAULT_STORE_TYPES.fashion;
      st.templateId = newType;
      st.customSizePresets = JSON.parse(JSON.stringify(tpObj.sizePresets || []));
      st.customColorPresets = JSON.parse(JSON.stringify(tpObj.colorPresets || []));
      if (tpObj.categories && tpObj.categories.length) {
        st.categories = JSON.parse(JSON.stringify(tpObj.categories));
      }
      if (tpObj.color) {
        st.theme = Object.assign({}, st.theme || {}, { primary: tpObj.color });
      }
      syncStoreToTenantCache(st);
      saveAllState();
      UI.toast('تم تغيير نوع المتجر إلى (' + tpObj.title + ') وتحديث القياسات تلقائياً ✓', 'success');
      renderStoresPanel();
    };

    $('#sdvSaveIdentityBtn', box).onclick = function () {
      st.name = $('#sdvName', box).value.trim() || st.name;
      st.tagline = $('#sdvTagline', box).value.trim();
      st.templateId = $('#sdvTypeSelect', box).value;
      var tpObj = storeTypes[st.templateId] || DEFAULT_STORE_TYPES.fashion;
      st.customSizePresets = JSON.parse(JSON.stringify(tpObj.sizePresets || []));
      st.customColorPresets = JSON.parse(JSON.stringify(tpObj.colorPresets || []));
      syncStoreToTenantCache(st);
      saveAllState();
      UI.toast('تم حفظ هوية ونوع المتجر وتحديث القياسات ✓', 'success');
      renderStoresPanel();
    };

    $('#sdvSaveOwnerSocialBtn', box).onclick = function () {
      st.ownerName = $('#sdvOwnerName', box).value.trim();
      st.ownerPhone = $('#sdvOwnerPhone', box).value.trim();
      var wa = $('#sdvWhatsapp', box).value.replace(/\D/g, '');
      if (wa.startsWith('07')) wa = '964' + wa.slice(1);
      st.whatsapp = wa || st.whatsapp;
      st.instagram = $('#sdvSocIg', box).value.trim();
      st.socials = {
        instagram: st.instagram,
        facebook: $('#sdvSocFb', box).value.trim(),
        telegram: $('#sdvSocTg', box).value.trim(),
        tiktok: $('#sdvSocTk', box).value.trim(),
        whatsappChannel: $('#sdvSocWa', box).value.trim()
      };
      syncStoreToTenantCache(st);
      saveAllState();
      UI.toast('تم حفظ بيانات المالك وحسابات التواصل الاجتماعي ✓', 'success');
      renderStoresPanel();
    };

    $('#sdvCreatedAt', box).onchange = function (e) {
      st.createdAt = e.target.value;
      saveAllState();
      UI.toast('تم تحديث تاريخ التسجيل ✓', 'success');
      renderStoresPanel();
    };

    $('#sdvExpiresAt', box).onchange = function (e) {
      st.subscription.expires = e.target.value;
      syncStoreToTenantCache(st);
      saveAllState();
      UI.toast('تم تحديث تاريخ انتهاء الاشتراك ✓', 'success');
      renderStoresPanel();
    };

    $('#sdvPlanBtns', box).onclick = function (e) {
      var b = e.target.closest('button[data-activate-plan]');
      if (!b) return;
      var pKey = b.getAttribute('data-activate-plan');
      var pl = masterPlans[pKey] || DEFAULT_PLANS[pKey];
      if (!pl) return;

      st.subscription.plan = pKey;
      st.subscription.suspended = false;
      delete st.subscription.suspendReason;
      st.subscription.maxProducts = Number(pl.maxProducts || 0);
      st.subscription.expires = pl.isLifetime ? 'lifetime' : addDaysISO(pl.days || 30);

      st.subscriptionHistory.push({
        date: todayISO(),
        plan: pKey,
        amount: Number(pl.price || 0),
        note: 'تفعيل / تجديد باقة (' + pl.name + ')'
      });

      if (pl.price > 0) {
        payments.unshift({
          id: 'pay-' + Date.now(),
          storeSlug: st.slug,
          storeName: st.name,
          plan: pKey,
          amount: Number(pl.price),
          method: 'زين كاش (ZainCash)',
          date: todayISO(),
          note: 'تجديد اشتراك (' + pl.name + ')'
        });
      }

      syncStoreToTenantCache(st);
      saveAllState();
      UI.toast('تم تفعيل (' + pl.name + ') للمتجر وتسجيلها في السجل المالي 🎉', 'success');
      renderStoresPanel();
    };

    $('#sdvCopyStoreUrl', box).onclick = function () { UI.copy(links.storeUrl, 'تم نسخ رابط المتجر ✓'); };
    $('#sdvCopyAdminUrl', box).onclick = function () { UI.copy(links.adminUrl, 'تم نسخ رابط لوحة التاجر ✓'); };
    $('#sdvHandoverBtn', box).onclick = function () { openHandoverCardModal(st); };

    $('#sdvSavePermsBtn', box).onclick = function () {
      st.adminPin = $('#sdvAdminPin', box).value.trim() || '1234';
      st.subscription.maxProducts = Math.max(0, Number($('#sdvMaxProducts', box).value) || 0);
      st.subscription.hideBranding = $('#sdvHideBranding', box).checked;
      st.features = Object.assign({}, st.features || {}, { coupons: $('#sdvAllowCoupons', box).checked });
      syncStoreToTenantCache(st);
      saveAllState();
      UI.toast('تم حفظ الصلاحيات والرمز السري (PIN) بنجاح ✓', 'success');
      renderStoresPanel();
    };

    $('#sdvAddReasonBtn', box).onclick = function () {
      var nr = $('#sdvNewReasonInp', box).value.trim();
      if (!nr) {
        UI.alert('يرجى كتابة سبب القفل أو المشكلة أولاً ليتم حفظه في القائمة الدائمة.', { title: 'حقل مطلوب', type: 'warning' });
        return;
      }
      if (!cfg.lockReasons) cfg.lockReasons = JSON.parse(JSON.stringify(DEFAULT_LOCK_REASONS));
      if (cfg.lockReasons.indexOf(nr) === -1) cfg.lockReasons.unshift(nr);
      st.subscription.suspendReason = nr;
      saveAllState();
      UI.toast('تم تسجيل خيار المشكلة الجديد وحفظه دائماً ✓', 'success');
      renderStoresPanel();
    };

    $('#sdvToggleLockBtn', box).onclick = function () {
      var isCurrentlyLocked = Boolean(st.subscription && st.subscription.suspended);
      if (isCurrentlyLocked) {
        st.subscription.suspended = false;
        delete st.subscription.suspendReason;
        syncStoreToTenantCache(st);
        saveAllState();
        UI.toast('تم فك قفل المتجر وإعادة تفعيله فوراً ✓', 'success');
        renderStoresPanel();
      } else {
        var reason = $('#sdvLockReasonSelect', box).value;
        UI.confirm('هل تريد قفل متجر "' + st.name + '" الآن بسبب:\n«' + reason + '»؟', {
          title: 'تأكيد قفل المتجر',
          type: 'warning',
          okText: '🔒 نعم، قفل المتجر الآن'
        }).then(function (ok) {
          if (!ok) return;
          st.subscription.suspended = true;
          st.subscription.suspendReason = reason;
          syncStoreToTenantCache(st);
          saveAllState();
          UI.toast('تم قفل المتجر بالسبب المحدد 🔒', 'warning');
          renderStoresPanel();
        });
      }
    };

    $('#sdvDeleteStoreBtn', box).onclick = function () {
      UI.confirm('هل أنت متأكد تماماً من حذف متجر "' + st.name + '" (' + (st.serialId || st.slug) + ') نهائياً من المنصة؟ لا يمكن التراجع عن هذا الإجراء.', {
        title: 'حذف المتجر نهائياً',
        type: 'danger',
        okText: '🗑️ نعم، احذف المتجر نهائياً'
      }).then(function (ok) {
        if (!ok) return;
        var deletedName = st.name;
        var slugToDelete = st.slug;
        delete masterStores[slugToDelete];
        localStorage.removeItem('store_data_' + slugToDelete);
        uiState.selectedStoreSlug = null;
        saveAllState();
        UI.toast('تم حذف متجر "' + deletedName + '" نهائياً', 'info');
        renderStoresPanel();
      });
    };
  }

  /* =========================================================================
     3. القائمة الثالثة: مصنع المتاجر (#panel-factory)
        • إصلاح شامل لنافذة إنشاء وتعديل نوع المتجر وتثبيته دائماً
        • تنسيق الصفحة بأسلوب إعدادات أبل الواضح والمنظم
     ========================================================================= */
  function openStoreTypeEditorModal(existingTypeId) {
    var isEdit = Boolean(existingTypeId && storeTypes[existingTypeId]);
    var src = isEdit ? JSON.parse(JSON.stringify(storeTypes[existingTypeId])) : {
      id: 'type-' + Date.now().toString(36),
      title: '',
      shortTitle: '',
      icon: '🛍️',
      color: '#4F46E5',
      tagline: 'تشكيلة مميزة · توصيل سريع لجميع المحافظات',
      categories: ['القسم الرئيسي', 'وصلنا حديثاً', 'عروض خاصة'],
      sizePresets: [
        { label: 'قياسات بالأرقام (36 - 46)', sizes: ['36', '38', '40', '42', '44', '46'] }
      ],
      colorPresets: JSON.parse(JSON.stringify(DEFAULT_COLORS.slice(0, 6)))
    };

    var sizesText = (src.sizePresets || []).map(function (sp) {
      return sp.label + ' : ' + (sp.sizes || []).join(', ');
    }).join('\n');

    var colorsText = (src.colorPresets || []).map(function (c) {
      return c.name + ' : ' + c.hex;
    }).join('\n');

    var typeIconChoices = ['👗', '💄', '👠', '⌚', '📱', '🛋️', '🍼', '⚽', '🍰', '🎁', '💎', '🛍️', '🏠', '🚀', '👑', '🏷️'];
    var iconPickerHtml = '<div class="icon-pick-grid" id="teIconGrid">' +
      typeIconChoices.map(function (ic) {
        var isAct = (src.icon || '🛍️') === ic;
        return '<button type="button" class="icon-pick-btn' + (isAct ? ' active' : '') + '" data-pick-ico="' + esc(ic) + '">' +
          (window.spIcon ? window.spIcon(ic) : esc(ic)) +
        '</button>';
      }).join('') +
    '</div>';

    var bodyHtml =
      '<div class="form-grid">' +
        '<label class="fld"><span>اسم نوع المتجر الكامل *</span><input id="teTitle" value="' + esc(src.title) + '" placeholder="مثال: إلكترونيات وأجهزة ذكية"></label>' +
        '<label class="fld"><span>الاسم المختصر للبطاقة</span><input id="teShort" value="' + esc(src.shortTitle || src.title) + '" placeholder="مثال: إلكترونيات"></label>' +
        '<div class="fld" style="grid-column:1/-1"><span>اختر شكل أيقونة النوع (Corporate Iconography)</span><input type="hidden" id="teIcon" value="' + esc(src.icon || '🛍️') + '">' + iconPickerHtml + '</div>' +
        '<label class="fld"><span>اللون الرئيسي للثيم</span><input type="color" id="teColor" value="' + esc(src.color || '#4F46E5') + '" style="height:46px;padding:4px"></label>' +
        '<label class="fld"><span>الوصف الترويجي الافتراضي</span><input id="teTagline" value="' + esc(src.tagline || '') + '"></label>' +
        '<label class="fld" style="grid-column:1/-1"><span>أقسام المتجر الافتراضية (افصل بينها بفاصلة)</span><input id="teCats" value="' + esc((src.categories || []).join('، ')) + '"></label>' +
        '<div class="fld" style="grid-column:1/-1">' +
          '<span>قوائم القياسات الدائمة لهذا النوع (كل سطر بصيغة: اسم القائمة : قياس1, قياس2, ...)</span>' +
          '<div style="display:flex;gap:6px;margin-bottom:6px">' +
            '<input id="teQuickSizeLbl" placeholder="اسم القائمة (مثال: قياسات شاشات)" style="flex:1">' +
            '<input id="teQuickSizeVals" placeholder="القياسات (مثال: 55 بوصة, 65 بوصة)" style="flex:1.2">' +
            '<button type="button" class="btn btn-ghost btn-sm" id="teQuickAddSizeBtn">+ إدراج</button>' +
          '</div>' +
          '<textarea id="teSizes" rows="4" placeholder="قياسات بالأرقام : 36, 38, 40, 42">' + esc(sizesText) + '</textarea>' +
        '</div>' +
        '<label class="fld" style="grid-column:1/-1">' +
          '<span>قائمة الألوان الدائمة لهذا النوع (كل سطر بصيغة: اسم اللون : #HEX)</span>' +
          '<textarea id="teColors" rows="3" placeholder="أسود ملكي : #1B1B1B">' + esc(colorsText) + '</textarea>' +
        '</label>' +
      '</div>';

    UI.modal({
      title: isEdit ? ('تعديل نوع المتجر: ' + src.title) : 'إنشاء نوع متجر جديد وتثبيته بشكل دائم',
      icon: src.icon || '🏗️',
      width: '650px',
      html: bodyHtml,
      onMount: function (dlgEl) {
        var ig = $('#teIconGrid', dlgEl);
        if (ig) {
          ig.onclick = function (e) {
            var b = e.target.closest('button[data-pick-ico]');
            if (!b) return;
            var val = b.getAttribute('data-pick-ico');
            $('#teIcon', dlgEl).value = val;
            $$('button[data-pick-ico]', ig).forEach(function (btn) { btn.classList.toggle('active', btn === b); });
          };
        }
        var qBtn = $('#teQuickAddSizeBtn', dlgEl);
        if (qBtn) {
          qBtn.onclick = function () {
            var l = ($('#teQuickSizeLbl', dlgEl).value || '').trim();
            var v = ($('#teQuickSizeVals', dlgEl).value || '').trim();
            if (!l || !v) return;
            var ta = $('#teSizes', dlgEl);
            ta.value = (ta.value.trim() ? ta.value.trim() + '\n' : '') + l + ' : ' + v;
            $('#teQuickSizeLbl', dlgEl).value = '';
            $('#teQuickSizeVals', dlgEl).value = '';
          };
        }
      },
      actions: [
        { text: 'إلغاء', className: 'ui-btn-ghost' },
        {
          text: '💾 حفظ وتثبيت نوع المتجر دائماً',
          className: 'ui-btn-primary',
          keepOpen: true,
          onClick: function (dlgEl, close) {
            var title = ($('#teTitle', dlgEl).value || '').trim();
            if (!title) {
              UI.alert('يرجى إدخال اسم نوع المتجر أولاً.', { title: 'حقل مطلوب', type: 'warning' });
              $('#teTitle', dlgEl).focus();
              return;
            }
            var cats = ($('#teCats', dlgEl).value || '').split(/[,،]/).map(function (x) { return x.trim(); }).filter(Boolean);
            var parsedSizes = [];
            ($('#teSizes', dlgEl).value || '').split('\n').forEach(function (line) {
              var parts = line.split(':');
              if (parts.length >= 2) {
                var lbl = parts[0].trim();
                var sz = parts.slice(1).join(':').split(/[,،]/).map(function (x) { return x.trim(); }).filter(Boolean);
                if (lbl && sz.length) parsedSizes.push({ label: lbl, sizes: sz });
              }
            });
            var parsedColors = [];
            ($('#teColors', dlgEl).value || '').split('\n').forEach(function (line) {
              var parts = line.split(':');
              if (parts.length >= 2) {
                var nm = parts[0].trim();
                var hx = parts[1].trim() || '#4F46E5';
                if (nm) parsedColors.push({ name: nm, hex: hx });
              }
            });

            src.title = title;
            src.shortTitle = ($('#teShort', dlgEl).value || '').trim() || title;
            src.icon = ($('#teIcon', dlgEl).value || '').trim() || '🛍️';
            src.color = $('#teColor', dlgEl).value || '#4F46E5';
            src.tagline = ($('#teTagline', dlgEl).value || '').trim();
            src.categories = cats.length ? cats : ['عام'];
            src.sizePresets = parsedSizes.length ? parsedSizes : [{ label: 'قياسات عامة', sizes: ['فري سايز'] }];
            src.colorPresets = parsedColors.length ? parsedColors : JSON.parse(JSON.stringify(DEFAULT_COLORS));

            storeTypes[src.id] = src;
            uiState.factorySelectedType = src.id;
            saveAllState();
            close();
            UI.toast('تم حفظ وتثبيت نوع المتجر (' + src.title + ') بشكل دائم ✓', 'success');
            renderFactoryPanel();
          }
        }
      ]
    });
  }

  function renderFactoryPanel() {
    var box = $('#panel-factory');
    if (!box) return;
    normalizeStoreTypes();

    if (!storeTypes[uiState.factorySelectedType]) {
      uiState.factorySelectedType = Object.keys(storeTypes)[0] || 'fashion';
    }
    var activeType = storeTypes[uiState.factorySelectedType];
    var nextId = peekNextSequentialStoreId();

    var typeKeys = Object.keys(storeTypes);
    var typeCardsHtml = typeKeys.map(function (k, idx) {
      var tp = storeTypes[k];
      var isSel = (k === uiState.factorySelectedType);
      var tpColor = tp.color || SIZE_CARD_PALETTE[idx % SIZE_CARD_PALETTE.length];
      return '<div class="type-card ' + (isSel ? 'selected' : '') + '" data-select-type="' + esc(k) + '" style="--tp-color:' + esc(tpColor) + '">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;gap:6px">' +
          '<div style="display:flex;align-items:center;gap:9px;min-width:0">' +
            '<div class="sp-bento-ico" style="color:' + esc(tpColor) + ';border-color:' + esc(tpColor) + '33">' + esc(tp.icon || '🛍️') + '</div>' +
            '<div style="min-width:0">' +
              '<b style="display:block;font-size:0.86rem;font-weight:900;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(tp.shortTitle || tp.title) + '</b>' +
              '<span style="font-size:0.7rem;color:var(--muted);font-weight:700">' + (tp.categories ? tp.categories.length : 0) + ' أقسام رئيسية</span>' +
            '</div>' +
          '</div>' +
          '<div style="display:flex;gap:4px;flex-shrink:0">' +
            '<button type="button" class="btn btn-ghost btn-sm" style="padding:3px 7px" data-edit-type="' + esc(k) + '" title="تعديل اسم ولون وأيقونة هذا النوع">✏️</button>' +
            (typeKeys.length > 1 ? '<button type="button" class="btn btn-danger btn-sm" style="padding:3px 7px" data-del-type="' + esc(k) + '" title="حذف هذا النوع">🗑️</button>' : '') +
          '</div>' +
        '</div>' +
        '<div style="display:flex;align-items:center;justify-content:space-between;font-size:0.72rem;color:var(--muted);font-weight:800;padding-top:4px;border-top:1px dashed var(--border)">' +
          '<span>📐 ' + (tp.sizePresets ? tp.sizePresets.length : 0) + ' بطاقات قياسات</span>' +
          '<span style="color:' + esc(tpColor) + '">' + (isSel ? '✓ النوع النشط' : 'اضغط للاختيار') + '</span>' +
        '</div>' +
      '</div>';
    }).join('');

    var sizePresetsArr = activeType.sizePresets || [];
    if (uiState.factoryOpenSizeCardIdx != null && !sizePresetsArr[uiState.factoryOpenSizeCardIdx]) {
      uiState.factoryOpenSizeCardIdx = null;
      uiState.factoryEditingSizeItemIdx = null;
    }

    var sizeSectionBodyHtml = '';
    if (uiState.factoryOpenSizeCardIdx != null && sizePresetsArr[uiState.factoryOpenSizeCardIdx]) {
      // عرض البطاقة المفتوحة (عند الدخول على بطاقة قياسات: تظهر القياسات أو الأرقام مع إمكانية حذفها أو تعديلها، وتعديل اسم البطاقة ولونها وأيقونتها)
      var openIdx = uiState.factoryOpenSizeCardIdx;
      var spCard = sizePresetsArr[openIdx];
      var spCol = spCard.color || SIZE_CARD_PALETTE[openIdx % SIZE_CARD_PALETTE.length];
      var spIco = spCard.icon || SIZE_CARD_ICONS[openIdx % SIZE_CARD_ICONS.length];

      var colorDotsHtml = SIZE_CARD_PALETTE.map(function (hx) {
        var isActCol = String(spCol).toLowerCase() === hx.toLowerCase();
        return '<button type="button" class="sp-color-dot' + (isActCol ? ' active' : '') + '" data-sp-pick-col="' + esc(hx) + '" style="background:' + esc(hx) + '" title="تغيير لون البطاقة"></button>';
      }).join('');

      var iconBtnsHtml = SIZE_CARD_ICONS.map(function (ic) {
        var isActIco = spIco === ic;
        return '<button type="button" class="icon-pick-btn' + (isActIco ? ' active' : '') + '" data-sp-pick-ico="' + esc(ic) + '" style="width:36px;height:36px">' +
          (window.spIcon ? window.spIcon(ic) : esc(ic)) +
        '</button>';
      }).join('');

      var sizesItemsHtml = (spCard.sizes || []).map(function (sz, sIdx) {
        if (uiState.factoryEditingSizeItemIdx === sIdx) {
          return '<div class="sp-size-chip" style="--sp-color:' + esc(spCol) + ';border-color:' + esc(spCol) + '">' +
            '<input type="text" class="sp-inline-edit-inp" id="spInlineSizeInp" value="' + esc(sz) + '" data-save-idx="' + sIdx + '">' +
            '<button type="button" class="sp-sz-btn" data-confirm-size-edit="' + sIdx + '" title="حفظ القياس" style="background:var(--ok-soft);color:#059669">✓</button>' +
            '<button type="button" class="sp-sz-btn del" data-cancel-size-edit="1" title="إلغاء">✕</button>' +
          '</div>';
        }
        return '<div class="sp-size-chip" style="--sp-color:' + esc(spCol) + '">' +
          '<span class="sp-sz-val" data-start-size-edit="' + sIdx + '" title="اضغط لتعديل هذا القياس أو الرقم">' + esc(sz) + '</span>' +
          '<button type="button" class="sp-sz-btn" data-start-size-edit="' + sIdx + '" title="تعديل القياس">✏️</button>' +
          '<button type="button" class="sp-sz-btn del" data-del-size-item="' + sIdx + '" title="حذف القياس من البطاقة">×</button>' +
        '</div>';
      }).join('');

      var spDescVal = (typeof spCard.desc === 'string' && spCard.desc.trim()) ? spCard.desc.trim() : inferSizeCardDesc(spCard, activeType);

      sizeSectionBodyHtml =
        '<div class="sp-opened-card" id="facOpenedSizeCard" style="--sp-color:' + esc(spCol) + '">' +
          '<div class="sp-opened-hdr">' +
            '<div style="display:flex;align-items:center;gap:10px;min-width:0">' +
              '<div class="sp-bento-ico" style="width:42px;height:42px;color:' + esc(spCol) + ';border-color:' + esc(spCol) + '44;background:' + esc(spCol) + '12">' + esc(spIco) + '</div>' +
              '<div style="min-width:0">' +
                '<b style="display:block;font-size:0.95rem;font-weight:900;color:var(--text)">' +
                  esc(spCard.label) +
                  (uiState.factoryIsCreatingSizeCard ? ' <span class="sym-badge st-active" style="margin-right:6px">بطاقة جديدة</span>' : '') +
                '</b>' +
                '<span style="font-size:0.74rem;color:var(--muted);font-weight:700">القائمة الشاملة والمتحكمة بالبطاقة (الاسم · الوصف والاستخدام · اللون · الأيقونة · القياسات)</span>' +
              '</div>' +
            '</div>' +
            '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">' +
              '<button type="button" class="btn btn-ghost btn-sm" id="spBackToCardsBtn">← العودة لبطاقات القياسات</button>' +
              '<button type="button" class="btn btn-danger btn-sm" id="spDeleteWholeCardBtn">🗑️ حذف البطاقة</button>' +
            '</div>' +
          '</div>' +

          '<!-- تعديل اسم البطاقة ووصفها ولونها وأيقونتها -->' +
          '<div class="form-grid" style="align-items:end">' +
            '<label class="fld">' +
              '<span>🏷️ اسم بطاقة القياسات</span>' +
              '<input type="text" class="sf-input" id="spCardLabelInp" value="' + esc(spCard.label) + '" placeholder="مثال: قياسات الملابس بالأحرف">' +
            '</label>' +
            '<label class="fld">' +
              '<span>📝 وصف البطاقة أو مثال بسيط أو لمن تستخدم</span>' +
              '<div style="display:flex;gap:6px">' +
                '<input type="text" class="sf-input" id="spCardDescInp" value="' + esc(spDescVal) + '" placeholder="مثال: للقمصان والفساتين والملابس الكاجوال · مثال: S, M, L">' +
                '<button type="button" class="btn btn-primary btn-sm" id="spSaveCardNameBtn">حفظ الهوية</button>' +
              '</div>' +
            '</label>' +
            '<div class="fld" style="grid-column:1/-1">' +
              '<span>🎨 لون البطاقة المميز</span>' +
              '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
                '<input type="color" id="spCardCustomColorInp" value="' + esc(spCol) + '" style="width:36px;height:32px;padding:2px;border-radius:8px;border:1px solid var(--border);cursor:pointer">' +
                '<div class="sp-color-swatches">' + colorDotsHtml + '</div>' +
              '</div>' +
            '</div>' +
            '<div class="fld" style="grid-column:1/-1">' +
              '<span>✨ أيقونة البطاقة (اضغط لاختيار الأيقونة وتطبيقها فوراً)</span>' +
              '<div class="icon-pick-grid" style="grid-template-columns:repeat(auto-fill,minmax(36px,1fr));gap:6px;padding:8px">' + iconBtnsHtml + '</div>' +
            '</div>' +
          '</div>' +

          '<!-- القياسات والأرقام داخل البطاقة (تعديل أو حذف أو إضافة) -->' +
          '<div>' +
            '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;gap:8px;flex-wrap:wrap">' +
              '<b style="font-size:0.82rem;font-weight:900;color:var(--text)">📏 القياسات والأرقام داخل البطاقة (تظهر فقط داخل هذه القائمة الشاملة — اضغط على أي رقم لتعديله أو × لحذفه):</b>' +
              '<span style="font-size:0.73rem;color:var(--muted);font-weight:700">تُحفظ التعديلات تلقائياً</span>' +
            '</div>' +
            '<div class="sp-sizes-grid" id="spSizesItemsGrid">' +
              (sizesItemsHtml || '<span style="color:var(--muted);font-size:0.8rem;font-weight:700">لا توجد قياسات داخل هذه البطاقة حالياً — أضف القياسات من الحقل أدناه.</span>') +
            '</div>' +
            '<div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">' +
              '<input type="text" class="sf-input" id="spNewSizeItemInp" placeholder="أضف قياساً أو رقماً جديداً للبطاقة (مثال: 42 أو XL، أو عدة قياسات مفصولة بفاصلة)..." style="flex:1">' +
              '<button type="button" class="btn btn-primary btn-sm" id="spAddSizeItemBtn">➕ إضافة للبطاقة</button>' +
              '<button type="button" class="btn btn-ok btn-sm" id="spDoneCardBtn">✅ حفظ البطاقة والعودة للبطاقات</button>' +
            '</div>' +
          '</div>' +
        '</div>';
    } else {
      // عرض بطاقات القياسات بدون إظهار تفاصيل القياسات والأرقام على البطاقة — يظهر فقط اسم البطاقة ووصفها أو مثال بسيط أو لمن تستخدم
      var cardsGridHtml = sizePresetsArr.map(function (sp, idx) {
        var spCol = sp.color || SIZE_CARD_PALETTE[idx % SIZE_CARD_PALETTE.length];
        var spIco = sp.icon || SIZE_CARD_ICONS[idx % SIZE_CARD_ICONS.length];
        var spDesc = (typeof sp.desc === 'string' && sp.desc.trim()) ? sp.desc.trim() : inferSizeCardDesc(sp, activeType);

        return '<div class="sp-bento-card" data-open-sp-card="' + idx + '" style="--sp-color:' + esc(spCol) + '" title="اضغط لفتح القائمة الشاملة والمتحكمة بهذه البطاقة">' +
          '<div class="sp-bento-top">' +
            '<div class="sp-bento-id">' +
              '<div class="sp-bento-ico" style="color:' + esc(spCol) + ';border-color:' + esc(spCol) + '33">' + esc(spIco) + '</div>' +
              '<div class="sp-bento-title">' +
                '<b>' + esc(sp.label) + '</b>' +
                '<span>بطاقة قياسات مخصصة</span>' +
              '</div>' +
            '</div>' +
            '<button type="button" class="btn btn-danger btn-sm" style="padding:2px 7px" data-quick-del-sp="' + idx + '" title="حذف البطاقة">🗑️</button>' +
          '</div>' +
          '<p class="sp-bento-desc">' + esc(spDesc) + '</p>' +
          '<div class="sp-bento-ftr">' +
            '<span>فتح القائمة الشاملة للتحكم بالبطاقة</span>' +
            '<span>←</span>' +
          '</div>' +
        '</div>';
      }).join('');

      sizeSectionBodyHtml =
        '<div class="sp-cards-grid" id="facSizeCardsGrid">' +
          (cardsGridHtml || '<div style="grid-column:1/-1;padding:16px;text-align:center;color:var(--muted);font-weight:700">لا توجد بطاقات قياسات مضافة لهذا النوع بعد.</div>') +
        '</div>' +
        '<div class="sp-create-card-bar">' +
          '<button type="button" class="btn btn-primary" id="facAddSizeListBtn" style="width:100%;justify-content:center;padding:11px 16px;font-size:0.86rem">' +
            '➕ إنشاء بطاقة جديدة (فتح القائمة الشاملة والمتحكمة بالبطاقة)' +
          '</button>' +
        '</div>';
    }

    var colorPresetsHtml = (activeType.colorPresets || []).map(function (cp, idx) {
      return '<div class="preset-pill">' +
        '<i style="width:12px;height:12px;border-radius:50%;background:' + esc(cp.hex) + ';display:inline-block;border:1px solid rgba(0,0,0,0.18)"></i>' +
        '<b>' + esc(cp.name) + '</b>' +
        '<button type="button" class="btn btn-danger btn-sm" style="padding:0 5px" data-del-cp="' + idx + '" title="حذف اللون">×</button>' +
      '</div>';
    }).join('');

    var planOptsHtml = Object.keys(masterPlans).map(function (k) {
      var pl = masterPlans[k];
      return '<option value="' + esc(k) + '"' + (k === 'monthly' ? ' selected' : '') + '>' + esc(pl.icon + ' ' + pl.name + ' — ' + (pl.price > 0 ? fmt(pl.price) : 'مجاناً')) + '</option>';
    }).join('');

    var totalSizeCardsCount = sizePresetsArr.length;
    var totalColorsCount = (activeType.colorPresets || []).length;

    box.innerHTML =
      '<div class="cmd-hero-banner">' +
        '<div class="cmd-hero-left">' +
          '<div class="cmd-pulse-orb">🏗️</div>' +
          '<div class="cmd-hero-txt">' +
            '<h2>' +
              '<span>مصنع المتاجر واستوديو البطاقات الذكية</span>' +
              '<span class="cmd-live-pill"><i class="cmd-live-dot"></i> ' + esc(activeType.shortTitle || activeType.title) + '</span>' +
            '</h2>' +
            '<p>تخصيص أنواع المتاجر، إدارة بطاقات القياسات التفاعلية (الاسم واللون والأيقونة والأرقام)، وتأسيس متاجر جديدة</p>' +
          '</div>' +
        '</div>' +
        '<div class="cmd-quick-actions">' +
          '<button type="button" class="cmd-qa-pill primary" id="facNewTypeBtn">➕ إنشاء نوع متجر جديد وتثبيته دائماً</button>' +
        '</div>' +
      '</div>' +

      '<div class="kpi-grid-4">' +
        '<div class="kpi-card" style="--kpi-color:#4F46E5;--kpi-bg:#EEF2FF;cursor:default">' +
          '<div class="kpi-top"><span class="kpi-label">أنواع المتاجر المعتمدة</span><div class="kpi-ico">🏷️</div></div>' +
          '<div class="kpi-val">' + typeKeys.length + ' <small style="font-size:0.86rem;color:var(--muted);font-weight:700">قطاعات جاهزة</small></div>' +
          '<div class="kpi-sub"><span>قابلة للتعديل والإضافة الدائمة</span></div>' +
        '</div>' +
        '<div class="kpi-card" style="--kpi-color:' + esc(activeType.color || '#0EA5E9') + ';--kpi-bg:#E0F2FE;cursor:default">' +
          '<div class="kpi-top"><span class="kpi-label">النوع المحدد حالياً</span><div class="kpi-ico">' + esc(activeType.icon || '🛍️') + '</div></div>' +
          '<div class="kpi-val" style="font-size:1.22rem">' + esc(activeType.shortTitle || activeType.title) + '</div>' +
          '<div class="kpi-sub"><span>' + (activeType.categories ? activeType.categories.length : 0) + ' أقسام افتراضية مدمجة</span></div>' +
        '</div>' +
        '<div class="kpi-card" style="--kpi-color:#10B981;--kpi-bg:#ECFDF5;cursor:default">' +
          '<div class="kpi-top"><span class="kpi-label">بطاقات القياسات والألوان</span><div class="kpi-ico">📏</div></div>' +
          '<div class="kpi-val">' + totalSizeCardsCount + ' <small style="font-size:0.86rem;color:var(--muted);font-weight:700">بطاقات قياس · ' + totalColorsCount + ' لون</small></div>' +
          '<div class="kpi-sub"><span>اضغط على أي بطاقة لتعديل أرقامها وهويتها</span></div>' +
        '</div>' +
        '<div class="kpi-card" style="--kpi-color:#8B5CF6;--kpi-bg:#F3E8FF;cursor:default">' +
          '<div class="kpi-top"><span class="kpi-label">كود التأسيس التلقائي</span><div class="kpi-ico">🆔</div></div>' +
          '<div class="kpi-val" dir="ltr">' + esc(nextId) + '</div>' +
          '<div class="kpi-sub"><span>جاهز لتوليد المتجر وبطاقة التسليم</span></div>' +
        '</div>' +
      '</div>' +

      '<!-- تخطيط استوديو أبل بعمودين متوازنين على قياس 100% -->' +
      '<div class="factory-studio-grid">' +

        '<!-- العمود الأيمن: 1. أنواع المتاجر + 2. بطاقات القياسات التفاعلية ولوحة الألوان -->' +
        '<div style="display:flex;flex-direction:column;gap:14px;min-width:0">' +
          '<div class="apple-settings-group" style="margin-bottom:0">' +
            '<div class="asg-header">' +
              '<h3><span class="asg-num">1</span> بطاقات أنواع المتاجر المعتمدة</h3>' +
              '<span class="sym-badge st-plan">المحدد: ' + esc(activeType.icon + ' ' + (activeType.shortTitle || activeType.title)) + '</span>' +
            '</div>' +
            '<div class="asg-body">' +
              '<div class="type-cards-grid" id="facTypesGrid">' + typeCardsHtml + '</div>' +
            '</div>' +
          '</div>' +

          '<div class="apple-settings-group" style="margin-bottom:0">' +
            '<div class="asg-header">' +
              '<h3><span class="asg-num">2</span> بطاقات القياسات والألوان لنوع: ' + esc(activeType.shortTitle || activeType.title) + '</h3>' +
              (uiState.factoryOpenSizeCardIdx != null
                ? '<span class="sym-badge st-active">وضع تعديل البطاقة المفتوحة</span>'
                : '<span class="sym-badge st-type">' + totalSizeCardsCount + ' بطاقات قياسات</span>') +
            '</div>' +
            '<div class="asg-body" style="display:flex;flex-direction:column;gap:14px">' +
              '<div class="sub-box">' +
                '<div class="sub-box-title">' +
                  '<span>📏 بطاقات قوائم القياسات (اضغط على أي بطاقة لعرض وتعديل القياسات والاسم واللون والأيقونة)</span>' +
                '</div>' +
                sizeSectionBodyHtml +
              '</div>' +

              '<div class="sub-box">' +
                '<div class="sub-box-title"><span>🎨 لوحة الألوان المثبتة دائماً لهذا النوع</span><small style="color:var(--muted)">' + totalColorsCount + ' لون</small></div>' +
                '<div class="preset-pill-list" id="facColorList">' + colorPresetsHtml + '</div>' +
                '<div style="display:grid;grid-template-columns:42px 1fr auto;gap:6px;align-items:center;margin-top:4px">' +
                  '<input type="color" id="facNewColorHex" value="#7A4E2D" style="width:42px;height:34px;padding:2px;border-radius:9px;border:1px solid var(--border)">' +
                  '<input class="sf-input" id="facNewColorName" placeholder="اسم اللون الجديد (مثال: أخضر زمردي)">' +
                  '<button type="button" class="btn btn-ghost btn-sm" id="facAddColorBtn">📌 تثبيت اللون</button>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<!-- العمود الأيسر: 3. إنشاء متجر جديد وحسابات التواصل الاجتماعي (زر تابعنا الدوّار) -->' +
        '<div class="apple-settings-group" style="margin-bottom:0">' +
          '<div class="asg-header">' +
            '<h3><span class="asg-num">3</span> إنشاء متجر جديد وحسابات التواصل (زر تابعنا الدوّار 🎡)</h3>' +
            '<span class="sym-badge st-plan" dir="ltr">🆔 الكود التلقائي: ' + esc(nextId) + '</span>' +
          '</div>' +
          '<div class="asg-body" style="display:flex;flex-direction:column;gap:12px">' +

            '<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--surface-2);border-radius:16px;border:1px solid var(--border)">' +
              '<div class="asr-avatar" style="width:46px;height:46px;background:' + esc(activeType.color || '#4F46E5') + '">' +
                (uiState.factoryLogoDataUrl ? '<img src="' + esc(uiState.factoryLogoDataUrl) + '">' : esc(activeType.icon || '🏪')) +
              '</div>' +
              '<div style="flex:1;min-width:0">' +
                '<b style="font-size:0.84rem;display:block">شعار المتجر والكود التسلسلي التلقائي</b>' +
                '<span style="font-size:0.72rem;color:var(--muted)">يتولد الكود متسلسلاً تلقائياً مع ربط بطاقات القياسات المحددة</span>' +
              '</div>' +
              '<input type="file" id="facLogoFile" accept="image/*" style="display:none">' +
              '<button type="button" class="btn btn-ghost btn-sm" id="facPickLogoBtn">📷 رفع شعار</button>' +
              '<input id="facSerialId" dir="ltr" value="' + esc(nextId) + '" readonly style="width:92px;padding:6px 8px;border-radius:10px;border:1px solid var(--border);text-align:center;font-weight:900;font-size:0.8rem;color:var(--brand);background:var(--surface)">' +
            '</div>' +

            '<div class="form-grid">' +
              '<label class="fld"><span>🏪 اسم المتجر الجديد *</span><input id="facStoreName" placeholder="مثال: بوتيك نور للأزياء"></label>' +
              '<label class="fld"><span>💎 باقة الاشتراك المفعّلة *</span><select id="facPlanSelect">' + planOptsHtml + '</select></label>' +
              '<label class="fld"><span>👤 اسم صاحب المتجر</span><input id="facOwnerName" placeholder="الاسم الكامل للتاجر"></label>' +
              '<label class="fld"><span>💬 رقم واتساب الطلبات *</span><input id="facWhatsapp" dir="ltr" placeholder="0770XXXXXXX"></label>' +
              '<label class="fld"><span>🔑 الرمز السري للتاجر (PIN)</span><input id="facAdminPin" dir="ltr" value="1234"></label>' +
              '<label class="fld"><span>✨ الوصف الترويجي للمتجر</span><input id="facTagline" value="' + esc(activeType.tagline || '') + '"></label>' +
            '</div>' +

            '<div class="sub-box">' +
              '<div class="sub-box-title"><span>🎡 روابط منصات التواصل الاجتماعي (تظهر في زر تابعنا الدائري)</span></div>' +
              '<div class="form-grid">' +
                '<label class="fld"><span>📸 إنستغرام (Instagram)</span><input id="facSocIg" dir="ltr" placeholder="@username أو الرابط"></label>' +
                '<label class="fld"><span>📘 فيسبوك (Facebook)</span><input id="facSocFb" dir="ltr" placeholder="https://facebook.com/..."></label>' +
                '<label class="fld"><span>✈️ قناة تلجرام (Telegram)</span><input id="facSocTg" dir="ltr" placeholder="https://t.me/..."></label>' +
                '<label class="fld"><span>🎵 تيك توك (TikTok)</span><input id="facSocTk" dir="ltr" placeholder="@tiktok"></label>' +
                '<label class="fld" style="grid-column:1/-1"><span>📢 قناة واتساب الرسمية (WhatsApp Channel)</span><input id="facSocWa" dir="ltr" placeholder="https://whatsapp.com/channel/..."></label>' +
              '</div>' +
            '</div>' +

          '</div>' +
          '<div class="asg-footer">' +
            '<button type="button" class="btn btn-primary btn-lg" id="facCreateStoreBtn" style="width:100%">🚀 إنشاء المتجر الآن وتوليد الروابط القصيرة وبطاقة التسليم فوراً</button>' +
          '</div>' +
        '</div>' +

      '</div>';

    // مزامنة بطاقات القياسات المحدّثة مع المتاجر التابعة لهذا النوع
    var syncTypePresetsToStores = function () {
      Object.keys(masterStores).forEach(function (slug) {
        var st = masterStores[slug];
        if (st && st.templateId === activeType.id) {
          st.customSizePresets = JSON.parse(JSON.stringify(activeType.sizePresets || []));
          st.customColorPresets = JSON.parse(JSON.stringify(activeType.colorPresets || []));
          syncStoreToTenantCache(st);
        }
      });
      saveAllState();
    };

    // أحداث مصنع المتاجر
    $('#facNewTypeBtn', box).onclick = function () { openStoreTypeEditorModal(null); };

    $('#facTypesGrid', box).onclick = function (e) {
      var editBtn = e.target.closest('button[data-edit-type]');
      if (editBtn) {
        e.stopPropagation();
        openStoreTypeEditorModal(editBtn.getAttribute('data-edit-type'));
        return;
      }
      var delBtn = e.target.closest('button[data-del-type]');
      if (delBtn) {
        e.stopPropagation();
        var tid = delBtn.getAttribute('data-del-type');
        var tp = storeTypes[tid];
        if (!tp) return;
        UI.confirm('هل أنت متأكد من حذف نوع المتجر "' + tp.title + '" من قائمة الأنواع؟', {
          title: 'حذف نوع المتجر',
          type: 'danger',
          okText: 'نعم، احذف النوع'
        }).then(function (ok) {
          if (!ok) return;
          delete storeTypes[tid];
          uiState.factorySelectedType = Object.keys(storeTypes)[0] || 'fashion';
          uiState.factoryOpenSizeCardIdx = null;
          uiState.factoryEditingSizeItemIdx = null;
          saveAllState();
          UI.toast('تم حذف نوع المتجر ✓', 'info');
          renderFactoryPanel();
        });
        return;
      }
      var card = e.target.closest('[data-select-type]');
      if (card) {
        uiState.factorySelectedType = card.getAttribute('data-select-type');
        uiState.factoryOpenSizeCardIdx = null;
        uiState.factoryEditingSizeItemIdx = null;
        renderFactoryPanel();
      }
    };

    // أحداث شبكة بطاقات القياسات (الدخول إلى البطاقة أو حذفها أو إنشاء بطاقة جديدة)
    var cardsGrid = $('#facSizeCardsGrid', box);
    if (cardsGrid) {
      cardsGrid.onclick = function (e) {
        var delBtn = e.target.closest('button[data-quick-del-sp]');
        if (delBtn) {
          e.stopPropagation();
          var dIdx = Number(delBtn.getAttribute('data-quick-del-sp'));
          var targetSp = activeType.sizePresets[dIdx];
          if (!targetSp) return;
          UI.confirm('هل تريد حذف بطاقة القياسات "' + targetSp.label + '"؟', {
            title: 'حذف بطاقة القياسات',
            type: 'danger',
            okText: 'نعم، احذف البطاقة'
          }).then(function (ok) {
            if (!ok) return;
            activeType.sizePresets.splice(dIdx, 1);
            syncTypePresetsToStores();
            UI.toast('تم حذف بطاقة القياسات ✓', 'info');
            renderFactoryPanel();
          });
          return;
        }
        var spCardEl = e.target.closest('[data-open-sp-card]');
        if (spCardEl) {
          uiState.factoryOpenSizeCardIdx = Number(spCardEl.getAttribute('data-open-sp-card'));
          uiState.factoryIsCreatingSizeCard = false;
          uiState.factoryEditingSizeItemIdx = null;
          renderFactoryPanel();
        }
      };
    }

    var addSizeListBtn = $('#facAddSizeListBtn', box);
    if (addSizeListBtn) {
      addSizeListBtn.onclick = function () {
        if (!activeType.sizePresets) activeType.sizePresets = [];
        var newIdx = activeType.sizePresets.length;
        var newCard = {
          label: 'بطاقة قياسات جديدة ' + (newIdx + 1),
          desc: 'مخصصة لمنتجات (' + (activeType.shortTitle || activeType.title) + ') · أضف وصف الاستخدام أو مثال بسيط',
          icon: SIZE_CARD_ICONS[newIdx % SIZE_CARD_ICONS.length],
          color: SIZE_CARD_PALETTE[newIdx % SIZE_CARD_PALETTE.length],
          sizes: []
        };
        activeType.sizePresets.push(newCard);
        uiState.factoryOpenSizeCardIdx = newIdx;
        uiState.factoryIsCreatingSizeCard = true;
        uiState.factoryEditingSizeItemIdx = null;
        syncTypePresetsToStores();
        UI.toast('تم فتح القائمة الشاملة لإنشاء وتخصيص البطاقة الجديدة ✓', 'info');
        renderFactoryPanel();
        setTimeout(function () {
          var nameInp = $('#spCardLabelInp', box);
          if (nameInp) { nameInp.focus(); nameInp.select(); }
        }, 40);
      };
    }

    // أحداث البطاقة المفتوحة (تعديل اسم البطاقة، وصفها، لونها، أيقونتها، وتعديل/حذف/إضافة القياسات بداخلها)
    var openedCardEl = $('#facOpenedSizeCard', box);
    if (openedCardEl && uiState.factoryOpenSizeCardIdx != null) {
      var currSp = activeType.sizePresets[uiState.factoryOpenSizeCardIdx];

      var syncCardMetaFields = function () {
        var nameInp = $('#spCardLabelInp', openedCardEl);
        var descInp = $('#spCardDescInp', openedCardEl);
        if (nameInp && nameInp.value.trim()) currSp.label = nameInp.value.trim();
        if (descInp && descInp.value.trim()) currSp.desc = descInp.value.trim();
      };

      var backBtn = $('#spBackToCardsBtn', openedCardEl);
      if (backBtn) {
        backBtn.onclick = function () {
          syncCardMetaFields();
          syncTypePresetsToStores();
          uiState.factoryOpenSizeCardIdx = null;
          uiState.factoryIsCreatingSizeCard = false;
          uiState.factoryEditingSizeItemIdx = null;
          renderFactoryPanel();
        };
      }

      var doneBtn = $('#spDoneCardBtn', openedCardEl);
      if (doneBtn) {
        doneBtn.onclick = function () {
          syncCardMetaFields();
          syncTypePresetsToStores();
          uiState.factoryOpenSizeCardIdx = null;
          uiState.factoryIsCreatingSizeCard = false;
          uiState.factoryEditingSizeItemIdx = null;
          UI.toast('تم حفظ البطاقة وهويتها وقياساتها بنجاح ✓', 'success');
          renderFactoryPanel();
        };
      }

      var delWholeBtn = $('#spDeleteWholeCardBtn', openedCardEl);
      if (delWholeBtn) {
        delWholeBtn.onclick = function () {
          UI.confirm('هل أنت متأكد من حذف بطاقة "' + currSp.label + '" بالكامل؟', {
            title: 'حذف بطاقة القياسات',
            type: 'danger',
            okText: 'نعم، احذف البطاقة'
          }).then(function (ok) {
            if (!ok) return;
            activeType.sizePresets.splice(uiState.factoryOpenSizeCardIdx, 1);
            uiState.factoryOpenSizeCardIdx = null;
            uiState.factoryIsCreatingSizeCard = false;
            uiState.factoryEditingSizeItemIdx = null;
            syncTypePresetsToStores();
            UI.toast('تم حذف بطاقة القياسات ✓', 'info');
            renderFactoryPanel();
          });
        };
      }

      var saveCardName = function () {
        syncCardMetaFields();
        syncTypePresetsToStores();
        UI.toast('تم تحديث اسم ووصف البطاقة ✓', 'success');
        renderFactoryPanel();
      };
      var saveNameBtn = $('#spSaveCardNameBtn', openedCardEl);
      if (saveNameBtn) saveNameBtn.onclick = saveCardName;
      var cardLblInp = $('#spCardLabelInp', openedCardEl);
      if (cardLblInp) {
        cardLblInp.onkeydown = function (e) { if (e.key === 'Enter') saveCardName(); };
      }
      var cardDescInp = $('#spCardDescInp', openedCardEl);
      if (cardDescInp) {
        cardDescInp.onkeydown = function (e) { if (e.key === 'Enter') saveCardName(); };
      }

      var customColInp = $('#spCardCustomColorInp', openedCardEl);
      if (customColInp) {
        customColInp.onchange = function (e) {
          syncCardMetaFields();
          currSp.color = e.target.value || '#4F46E5';
          syncTypePresetsToStores();
          UI.toast('تم تحديث لون البطاقة ✓', 'success');
          renderFactoryPanel();
        };
      }

      openedCardEl.onclick = function (e) {
        var colDot = e.target.closest('button[data-sp-pick-col]');
        if (colDot) {
          syncCardMetaFields();
          currSp.color = colDot.getAttribute('data-sp-pick-col');
          syncTypePresetsToStores();
          UI.toast('تم تحديث لون البطاقة ✓', 'success');
          renderFactoryPanel();
          return;
        }
        var icoBtn = e.target.closest('button[data-sp-pick-ico]');
        if (icoBtn) {
          syncCardMetaFields();
          currSp.icon = icoBtn.getAttribute('data-sp-pick-ico');
          syncTypePresetsToStores();
          UI.toast('تم تحديث أيقونة البطاقة ✓', 'success');
          renderFactoryPanel();
          return;
        }
        var startEdit = e.target.closest('[data-start-size-edit]');
        if (startEdit) {
          syncCardMetaFields();
          uiState.factoryEditingSizeItemIdx = Number(startEdit.getAttribute('data-start-size-edit'));
          renderFactoryPanel();
          setTimeout(function () {
            var inp = $('#spInlineSizeInp', box);
            if (inp) { inp.focus(); inp.select(); }
          }, 30);
          return;
        }
        var confirmEdit = e.target.closest('button[data-confirm-size-edit]');
        if (confirmEdit) {
          syncCardMetaFields();
          var sIdx = Number(confirmEdit.getAttribute('data-confirm-size-edit'));
          var inpEl = $('#spInlineSizeInp', openedCardEl);
          var newVal = inpEl ? inpEl.value.trim() : '';
          if (newVal) {
            currSp.sizes[sIdx] = newVal;
            syncTypePresetsToStores();
            UI.toast('تم تعديل القياس داخل البطاقة ✓', 'success');
          }
          uiState.factoryEditingSizeItemIdx = null;
          renderFactoryPanel();
          return;
        }
        var cancelEdit = e.target.closest('button[data-cancel-size-edit]');
        if (cancelEdit) {
          syncCardMetaFields();
          uiState.factoryEditingSizeItemIdx = null;
          renderFactoryPanel();
          return;
        }
        var delSizeBtn = e.target.closest('button[data-del-size-item]');
        if (delSizeBtn) {
          syncCardMetaFields();
          var delIdx = Number(delSizeBtn.getAttribute('data-del-size-item'));
          currSp.sizes.splice(delIdx, 1);
          syncTypePresetsToStores();
          UI.toast('تم حذف القياس من البطاقة ✓', 'info');
          renderFactoryPanel();
        }
      };

      var inlineInp = $('#spInlineSizeInp', openedCardEl);
      if (inlineInp) {
        inlineInp.onkeydown = function (e) {
          if (e.key === 'Enter') {
            syncCardMetaFields();
            var idxToSave = Number(inlineInp.getAttribute('data-save-idx'));
            var valToSave = inlineInp.value.trim();
            if (valToSave) {
              currSp.sizes[idxToSave] = valToSave;
              syncTypePresetsToStores();
              UI.toast('تم تعديل القياس داخل البطاقة ✓', 'success');
            }
            uiState.factoryEditingSizeItemIdx = null;
            renderFactoryPanel();
          } else if (e.key === 'Escape') {
            syncCardMetaFields();
            uiState.factoryEditingSizeItemIdx = null;
            renderFactoryPanel();
          }
        };
      }

      var addOneSizeItem = function () {
        syncCardMetaFields();
        var inp = $('#spNewSizeItemInp', openedCardEl);
        if (!inp) return;
        var items = (inp.value || '').split(/[,،]/).map(function (x) { return x.trim(); }).filter(Boolean);
        if (!items.length) return;
        if (!Array.isArray(currSp.sizes)) currSp.sizes = [];
        items.forEach(function (it) {
          if (currSp.sizes.indexOf(it) === -1) currSp.sizes.push(it);
        });
        syncTypePresetsToStores();
        UI.toast('تمت إضافة القياس داخل البطاقة ✓', 'success');
        renderFactoryPanel();
      };
      var addItemBtn = $('#spAddSizeItemBtn', openedCardEl);
      if (addItemBtn) addItemBtn.onclick = addOneSizeItem;
      var newItemInp = $('#spNewSizeItemInp', openedCardEl);
      if (newItemInp) {
        newItemInp.onkeydown = function (e) { if (e.key === 'Enter') addOneSizeItem(); };
      }
    }

    $('#facAddColorBtn', box).onclick = function () {
      var name = $('#facNewColorName', box).value.trim();
      var hex = $('#facNewColorHex', box).value || '#7A4E2D';
      if (!name) {
        UI.alert('يرجى كتابة اسم اللون قبل إضافته.', { title: 'حقل مطلوب', type: 'warning' });
        return;
      }
      if (!activeType.colorPresets) activeType.colorPresets = [];
      activeType.colorPresets.push({ name: name, hex: hex });
      syncTypePresetsToStores();
      UI.toast('تم تثبيت اللون (' + name + ') بشكل دائم ✓', 'success');
      renderFactoryPanel();
    };

    $('#facColorList', box).onclick = function (e) {
      var delCp = e.target.closest('button[data-del-cp]');
      if (!delCp) return;
      var idx = Number(delCp.getAttribute('data-del-cp'));
      activeType.colorPresets.splice(idx, 1);
      syncTypePresetsToStores();
      UI.toast('تم حذف اللون ✓', 'info');
      renderFactoryPanel();
    };

    $('#facPickLogoBtn', box).onclick = function () { $('#facLogoFile', box).click(); };
    $('#facLogoFile', box).onchange = function (e) {
      var file = (e.target.files || [])[0];
      if (!file) return;
      compressImageFile(file, 320, 0.85, function (dataUrl) {
        uiState.factoryLogoDataUrl = dataUrl;
        renderFactoryPanel();
      });
    };

    $('#facCreateStoreBtn', box).onclick = function () {
      var name = $('#facStoreName', box).value.trim();
      var ownerName = $('#facOwnerName', box).value.trim();
      var rawWa = $('#facWhatsapp', box).value.replace(/\D/g, '');
      if (!name) {
        UI.alert('يرجى إدخال اسم المتجر الجديد.', { title: 'اسم المتجر مطلوب', type: 'warning' });
        $('#facStoreName', box).focus();
        return;
      }
      if (!rawWa) {
        UI.alert('يرجى إدخال رقم واتساب صاحب المتجر لاستلام طلبات الزبائن.', { title: 'رقم الواتساب مطلوب', type: 'warning' });
        $('#facWhatsapp', box).focus();
        return;
      }
      if (rawWa.startsWith('07')) rawWa = '964' + rawWa.slice(1);

      var serialId = consumeNextSequentialStoreId();
      var slug = serialId.toLowerCase();
      var planKey = $('#facPlanSelect', box).value || 'monthly';
      var pl = masterPlans[planKey] || DEFAULT_PLANS.monthly;
      var pin = $('#facAdminPin', box).value.trim() || '1234';

      var socials = {
        instagram: $('#facSocIg', box).value.trim(),
        facebook: $('#facSocFb', box).value.trim(),
        telegram: $('#facSocTg', box).value.trim(),
        tiktok: $('#facSocTk', box).value.trim(),
        whatsappChannel: $('#facSocWa', box).value.trim()
      };

      var newStore = {
        slug: slug,
        serialId: serialId,
        name: name,
        tagline: $('#facTagline', box).value.trim() || activeType.tagline || '',
        logo: uiState.factoryLogoDataUrl || '',
        ownerName: ownerName || ('مالك ' + name),
        ownerPhone: rawWa,
        whatsapp: rawWa,
        instagram: socials.instagram,
        socials: socials,
        adminPin: pin,
        templateId: activeType.id,
        createdAt: todayISO(),
        currency: 'د.ع',
        orderPrefix: serialId.replace('-', ''),
        announcement: '✨ أهلاً بكم في ' + name + ' — التوصيل السريع لجميع المحافظات ✨',
        theme: { primary: activeType.color || '#7A4E2D', accent: '#C89B6E', bg: '#FAF7F2', text: '#1F1A17' },
        hero: { title: 'أهلاً بكم في ' + name + ' 🌸', subtitle: activeType.tagline || 'تصفحوا أحدث المنتجات والطلب يوصل لباب البيت' },
        subscription: {
          plan: planKey,
          expires: pl.isLifetime ? 'lifetime' : addDaysISO(pl.days || 30),
          graceDays: 3,
          maxProducts: Number(pl.maxProducts || 0),
          suspended: false,
          hideBranding: Boolean(pl.isLifetime || planKey === 'yearly')
        },
        subscriptionHistory: [
          {
            date: todayISO(),
            plan: planKey,
            amount: Number(pl.price || 0),
            note: 'تأسيس المتجر عبر مصنع المتاجر'
          }
        ],
        delivery: { default: 5000, freeOver: 75000, provinces: { 'بغداد': 4000 } },
        payment: ['الدفع عند الاستلام', 'زين كاش (ZainCash)', 'سوبر كي (SuperQi)'],
        categories: JSON.parse(JSON.stringify(activeType.categories || ['عام'])),
        customSizePresets: JSON.parse(JSON.stringify(activeType.sizePresets || [])),
        customColorPresets: JSON.parse(JSON.stringify(activeType.colorPresets || [])),
        products: [],
        productsCount: 0,
        coupons: [{ code: 'WELCOME10', type: 'percent', value: 10, active: true }]
      };

      masterStores[slug] = newStore;
      localStorage.setItem('store_data_' + slug, JSON.stringify(newStore));

      if (pl.price > 0) {
        payments.unshift({
          id: 'pay-' + Date.now(),
          storeSlug: slug,
          storeName: name,
          plan: planKey,
          amount: Number(pl.price),
          method: 'زين كاش (ZainCash)',
          date: todayISO(),
          note: 'اشتراك تأسيس المتجر (' + pl.name + ')'
        });
      }

      uiState.factoryLogoDataUrl = '';
      saveAllState();
      UI.toast('تم إنشاء المتجر (' + name + ') بالكود التسلسلي ' + serialId + ' بنجاح 🎉', 'success');
      renderFactoryPanel();
      openHandoverCardModal(newStore);
    };
  }

  /* =========================================================================
     4. القائمة الرابعة: الباقات والمالية (#panel-plans)
        • إصلاح شامل لإنشاء باقة جديدة، تعديل الباقة والميزات، وتسجيل دفعة مالية
        • إمكانية إضافة وحذف ميزات لكل باقة مباشرة من البطاقة أو من نافذة التعديل
        • شريط بحث متقدم وتبديل سلس بين حسابات المشتركين وسجل الدفعات المالية
     ========================================================================= */
  function openPlanEditorModal(existingPlanId) {
    var isEdit = Boolean(existingPlanId && masterPlans[existingPlanId]);
    var idxColor = PLAN_PALETTE[Object.keys(masterPlans).length % PLAN_PALETTE.length];
    var src = isEdit ? JSON.parse(JSON.stringify(masterPlans[existingPlanId])) : {
      id: 'plan-' + Date.now().toString(36),
      name: '',
      icon: '💎',
      color: idxColor,
      price: 25000,
      days: 30,
      maxProducts: 0,
      isLifetime: false,
      features: ['دعم فني متواصل', 'كوبونات خصم للزبائن', 'زر تابعنا الدوّار لمنصات التواصل']
    };

    var planIconChoices = ['🌱', '💎', '🚀', '👑', '♾️', '🌟', '🛡️', '🎟️'];
    var planIconPickerHtml = '<div class="icon-pick-grid" id="peIconGrid">' +
      planIconChoices.map(function (ic) {
        var isAct = (src.icon || '💎') === ic;
        return '<button type="button" class="icon-pick-btn' + (isAct ? ' active' : '') + '" data-pick-pico="' + esc(ic) + '">' +
          (window.spIcon ? window.spIcon(ic) : esc(ic)) +
        '</button>';
      }).join('') +
    '</div>';

    var bodyHtml =
      '<div class="form-grid">' +
        '<label class="fld"><span>اسم الباقة *</span><input id="peName" value="' + esc(src.name) + '" placeholder="مثال: الباقة الذهبية للأعمال"></label>' +
        '<label class="fld"><span>سعر الباقة (د.ع) *</span><input type="number" id="pePrice" value="' + esc(src.price) + '"></label>' +
        '<div class="fld" style="grid-column:1/-1"><span>اختر شكل أيقونة الباقة (Corporate Iconography)</span><input type="hidden" id="peIcon" value="' + esc(src.icon || '💎') + '">' + planIconPickerHtml + '</div>' +
        '<label class="fld"><span>مدة الباقة بالأيام (مثال: 30 أو 365)</span><input type="number" id="peDays" value="' + esc(src.days || 30) + '"></label>' +
        '<label class="fld"><span>الحد الأقصى للمنتجات (0 = غير محدود)</span><input type="number" id="peMaxProd" value="' + esc(src.maxProducts || 0) + '"></label>' +
        '<label class="fld" style="grid-column:1/-1"><span>لون شارة الباقة المميز</span><input type="color" id="peColor" value="' + esc(src.color || idxColor) + '" style="height:42px;padding:4px"></label>' +
        '<label style="grid-column:1/-1;display:flex;align-items:center;gap:8px;font-weight:800;font-size:0.9rem;cursor:pointer;padding:6px 0">' +
          '<input type="checkbox" id="peLifetime"' + (src.isLifetime ? ' checked' : '') + '> هذه الباقة دائمية مدى الحياة ♾️ (بدون تاريخ انتهاء)' +
        '</label>' +
        '<div class="fld" style="grid-column:1/-1">' +
          '<span>ميزات الباقة المخصصة (اكتب كل ميزة في سطر أو استخدم زر الإضافة السريعة)</span>' +
          '<div style="display:flex;gap:8px;margin-bottom:8px">' +
            '<input id="peNewFeatInp" placeholder="اكتب ميزة جديدة لهذه الباقة واضغط إضافة..." style="flex:1">' +
            '<button type="button" class="btn btn-primary btn-sm" id="peAddFeatBtn">+ إضافة الميزة</button>' +
          '</div>' +
          '<textarea id="peFeatures" rows="5" placeholder="اكتب كل ميزة في سطر مستقل...">' + esc((src.features || []).join('\n')) + '</textarea>' +
        '</div>' +
      '</div>';

    UI.modal({
      title: isEdit ? ('تعديل الباقة: ' + src.name) : 'إنشاء باقة اشتراك جديدة وتثبيتها دائماً',
      icon: src.icon || '💳',
      width: '600px',
      html: bodyHtml,
      onMount: function (dlgEl) {
        var pig = $('#peIconGrid', dlgEl);
        if (pig) {
          pig.onclick = function (e) {
            var b = e.target.closest('button[data-pick-pico]');
            if (!b) return;
            var val = b.getAttribute('data-pick-pico');
            $('#peIcon', dlgEl).value = val;
            $$('button[data-pick-pico]', pig).forEach(function (btn) { btn.classList.toggle('active', btn === b); });
          };
        }
        var addBtn = $('#peAddFeatBtn', dlgEl);
        if (addBtn) {
          addBtn.onclick = function () {
            var inp = $('#peNewFeatInp', dlgEl);
            var ta = $('#peFeatures', dlgEl);
            var v = (inp.value || '').trim();
            if (!v) return;
            ta.value = (ta.value.trim() ? ta.value.trim() + '\n' : '') + v;
            inp.value = '';
            inp.focus();
          };
        }
      },
      actions: [
        { text: 'إلغاء', className: 'ui-btn-ghost' },
        {
          text: '💾 حفظ وتثبيت الباقة',
          className: 'ui-btn-primary',
          keepOpen: true,
          onClick: function (dlgEl, close) {
            var name = ($('#peName', dlgEl).value || '').trim();
            if (!name) {
              UI.alert('يرجى إدخال اسم الباقة أولاً.', { title: 'حقل مطلوب', type: 'warning' });
              $('#peName', dlgEl).focus();
              return;
            }
            var feats = ($('#peFeatures', dlgEl).value || '').split('\n').map(function (x) { return x.trim(); }).filter(Boolean);
            src.name = name;
            src.icon = ($('#peIcon', dlgEl).value || '').trim() || '💎';
            src.price = Math.max(0, Number($('#pePrice', dlgEl).value) || 0);
            src.days = Math.max(1, Number($('#peDays', dlgEl).value) || 30);
            src.maxProducts = Math.max(0, Number($('#peMaxProd', dlgEl).value) || 0);
            src.color = $('#peColor', dlgEl).value || idxColor;
            src.isLifetime = $('#peLifetime', dlgEl).checked;
            src.features = feats.length ? feats : ['اشتراك فعّال بكامل المزايا'];

            masterPlans[src.id] = src;
            saveAllState();
            close();
            UI.toast('تم حفظ وتثبيت الباقة (' + src.name + ') بنجاح ✓', 'success');
            renderPlansPanel();
          }
        }
      ]
    });
  }

  function openRecordPaymentModal(preselectedSlug) {
    var slugs = Object.keys(masterStores);
    if (!slugs.length) {
      UI.alert('لا توجد متاجر مسجلة حالياً لتسجيل دفعة لها.', { title: 'تنبيه', type: 'warning' });
      return;
    }
    var storeOpts = slugs.map(function (s) {
      var st = masterStores[s];
      return '<option value="' + esc(s) + '"' + (preselectedSlug === s ? ' selected' : '') + '>' + esc(st.name + ' (' + (st.serialId || s) + ')') + '</option>';
    }).join('');
    var planOpts = Object.keys(masterPlans).map(function (k) {
      var pl = masterPlans[k];
      return '<option value="' + esc(k) + '"' + (k === 'monthly' ? ' selected' : '') + '>' + esc(pl.icon + ' ' + pl.name + ' — ' + fmt(pl.price)) + '</option>';
    }).join('');

    var bodyHtml =
      '<div class="form-grid">' +
        '<label class="fld" style="grid-column:1/-1"><span>اختر المتجر *</span><select id="rpStore">' + storeOpts + '</select></label>' +
        '<label class="fld"><span>باقة الاشتراك المفعّلة *</span><select id="rpPlan">' + planOpts + '</select></label>' +
        '<label class="fld"><span>المبلغ المستلم (د.ع) *</span><input type="number" id="rpAmount" value="15000"></label>' +
        '<label class="fld"><span>وسيلة الدفع</span>' +
          '<select id="rpMethod">' +
            '<option value="زين كاش (ZainCash)">زين كاش (ZainCash)</option>' +
            '<option value="سوبر كي (SuperQi)">سوبر كي (SuperQi)</option>' +
            '<option value="ماستر كارد الرافدين">ماستر كارد الرافدين</option>' +
            '<option value="نقدي مباشر">نقدي مباشر</option>' +
          '</select>' +
        '</label>' +
        '<label class="fld"><span>تاريخ العملية</span><input type="date" id="rpDate" value="' + todayISO() + '"></label>' +
        '<label class="fld" style="grid-column:1/-1"><span>ملاحظة / رقم الحوالة</span><input id="rpNote" placeholder="مثال: تجديد اشتراك وتفعيل فوري"></label>' +
      '</div>';

    UI.modal({
      title: 'تسجيل دفعة مالية وتجديد اشتراك متجر',
      icon: '💵',
      width: '560px',
      html: bodyHtml,
      onMount: function (dlgEl) {
        var pSel = $('#rpPlan', dlgEl);
        var aInp = $('#rpAmount', dlgEl);
        if (pSel && aInp) {
          pSel.onchange = function () {
            var pl = masterPlans[pSel.value];
            if (pl) aInp.value = pl.price;
          };
          pSel.onchange();
        }
      },
      actions: [
        { text: 'إلغاء', className: 'ui-btn-ghost' },
        {
          text: '✅ تسجيل الدفعة وتفعيل الاشتراك الآن',
          className: 'ui-btn-ok',
          keepOpen: true,
          onClick: function (dlgEl, close) {
            var slug = $('#rpStore', dlgEl).value;
            var pKey = $('#rpPlan', dlgEl).value;
            var amount = Math.max(0, Number($('#rpAmount', dlgEl).value) || 0);
            var method = $('#rpMethod', dlgEl).value;
            var date = $('#rpDate', dlgEl).value || todayISO();
            var note = ($('#rpNote', dlgEl).value || '').trim() || 'تسجيل دفعة وتجديد باقة';

            var st = masterStores[slug];
            var pl = masterPlans[pKey] || DEFAULT_PLANS.monthly;
            if (st) {
              if (!st.subscription) st.subscription = {};
              st.subscription.plan = pKey;
              st.subscription.suspended = false;
              delete st.subscription.suspendReason;
              st.subscription.maxProducts = Number(pl.maxProducts || 0);
              st.subscription.expires = pl.isLifetime ? 'lifetime' : addDaysISO(pl.days || 30);
              if (!st.subscriptionHistory) st.subscriptionHistory = [];
              st.subscriptionHistory.push({ date: date, plan: pKey, amount: amount, note: note });
              syncStoreToTenantCache(st);
            }

            payments.unshift({
              id: 'pay-' + Date.now(),
              storeSlug: slug,
              storeName: st ? st.name : slug,
              plan: pKey,
              amount: amount,
              method: method,
              date: date,
              note: note
            });

            saveAllState();
            close();
            UI.toast('تم تسجيل الدفعة وتفعيل اشتراك المتجر بنجاح 🎉', 'success');
            renderPlansPanel();
          }
        }
      ]
    });
  }

  function renderPlansPanel() {
    var box = $('#panel-plans');
    if (!box) return;
    normalizeMasterPlans();
    var m = computePlatformMetrics();

    var plansGridHtml = Object.keys(masterPlans).map(function (k, idx) {
      var pl = masterPlans[k];
      var pColor = pl.color || PLAN_PALETTE[idx % PLAN_PALETTE.length];
      var subCount = Number(m.planCounts[k] || 0);
      var featsHtml = (pl.features || []).map(function (f, fIdx) {
        return '<li>' +
          '<span style="display:flex;align-items:center;gap:5px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="' + esc(f) + '"><b style="color:' + esc(pColor) + '">✓</b> ' + esc(f) + '</span>' +
          '<button type="button" class="btn btn-ghost btn-sm" style="padding:0 5px;font-size:0.7rem;color:var(--muted);flex-shrink:0" data-del-feat="' + esc(k) + ':' + fIdx + '" title="حذف هذه الميزة">×</button>' +
        '</li>';
      }).join('');

      return '<div class="plan-box" style="border-top:5px solid ' + esc(pColor) + '">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;gap:6px">' +
          '<span style="font-size:0.92rem;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc((pl.icon || '💎') + ' ' + pl.name) + '</span>' +
          '<span class="sym-badge st-plan" style="padding:2px 8px;font-size:0.7rem;color:' + esc(pColor) + ';background:' + esc(pColor) + '15;border-color:' + esc(pColor) + '30">' + subCount + ' مشترك</span>' +
        '</div>' +
        '<div class="plan-price" style="color:' + esc(pColor) + '">' +
          (pl.price > 0 ? fmt(pl.price) : 'مجاناً') +
          ' <small style="font-size:0.72rem;color:var(--muted);font-weight:700">/ ' + (pl.isLifetime ? 'مدى الحياة ♾️' : (pl.days + ' يوم')) + '</small>' +
        '</div>' +
        '<div style="font-size:0.73rem;color:var(--muted);font-weight:700">📦 المنتجات: ' + (pl.maxProducts > 0 ? (pl.maxProducts + ' منتج') : 'غير محدود ♾️') + '</div>' +
        '<ul class="plan-features-list">' + featsHtml + '</ul>' +
        '<div style="display:flex;gap:4px">' +
          '<input class="sf-input" data-feat-inp="' + esc(k) + '" placeholder="+ أضف ميزة..." style="padding:5px 8px;font-size:0.74rem">' +
          '<button type="button" class="btn btn-ghost btn-sm" style="padding:4px 8px" data-quick-add-feat="' + esc(k) + '">+</button>' +
        '</div>' +
        '<div style="display:flex;gap:5px;padding-top:6px;border-top:1px solid var(--border)">' +
          '<button type="button" class="btn btn-primary btn-sm" style="flex:1;padding:5px 8px;font-size:0.74rem" data-edit-plan="' + esc(k) + '">✏️ تعديل الباقة</button>' +
          (Object.keys(masterPlans).length > 1 ? '<button type="button" class="btn btn-danger btn-sm" style="padding:5px 8px" data-del-plan="' + esc(k) + '" title="حذف الباقة">🗑️</button>' : '') +
        '</div>' +
      '</div>';
    }).join('');

    var q = uiState.finSearch.trim().toLowerCase();
    var storeRows = Object.keys(masterStores).map(function (slug) {
      var st = masterStores[slug];
      var stStatus = getStoreStatusInfo(st);
      var stPlan = getStorePlanInfo(st);
      var dl = getStoreDaysLeft(st);
      return { st: st, status: stStatus, plan: stPlan, dl: dl };
    }).filter(function (row) {
      if (q) {
        var hay = [row.st.name, row.st.serialId, row.st.slug, row.st.ownerName, row.st.whatsapp, row.plan.name].join(' ').toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      if (uiState.finPlanFilter !== 'all' && row.plan.id !== uiState.finPlanFilter) return false;
      if (uiState.finStatusFilter !== 'all' && row.status.key !== uiState.finStatusFilter) return false;
      return true;
    });

    if (uiState.finSort === 'price_desc') {
      storeRows.sort(function (a, b) { return b.plan.price - a.plan.price; });
    } else if (uiState.finSort === 'expiry_asc') {
      storeRows.sort(function (a, b) { return a.dl - b.dl; });
    } else {
      storeRows.sort(function (a, b) { return String(b.st.createdAt || '').localeCompare(String(a.st.createdAt || '')); });
    }

    var subsTableRows = storeRows.length ? storeRows.map(function (r) {
      var expText = isStoreLifetime(r.st) ? 'مدى الحياة ♾️' : ((r.st.subscription && r.st.subscription.expires) || '—');
      var histCount = (r.st.subscriptionHistory && r.st.subscriptionHistory.length) || 1;
      return '<tr>' +
        '<td><b dir="ltr">' + esc(r.st.serialId || r.st.slug) + '</b></td>' +
        '<td><b>' + esc(r.st.name) + '</b> <small style="color:var(--muted)">(' + esc(r.st.ownerName || '') + ')</small></td>' +
        '<td><span class="sym-badge st-plan" style="color:' + esc(r.plan.color) + ';background:' + esc(r.plan.color) + '15">' + esc(r.plan.icon + ' ' + r.plan.name) + '</span></td>' +
        '<td><span class="sym-badge ' + r.status.cls + '">' + r.status.icon + ' ' + esc(r.status.label) + '</span></td>' +
        '<td><b>' + fmt(r.plan.price) + '</b></td>' +
        '<td dir="ltr">' + esc(expText) + '</td>' +
        '<td>' + histCount + ' اشتراك</td>' +
        '<td>' +
          '<div style="display:flex;gap:4px">' +
            '<button type="button" class="btn btn-ok btn-sm" style="padding:4px 9px;font-size:0.72rem" data-quick-renew="' + esc(r.st.slug) + '">⚡ تجديد</button>' +
            '<button type="button" class="btn btn-ghost btn-sm" style="padding:4px 9px;font-size:0.72rem" data-goto-store="' + esc(r.st.slug) + '">⚙️ إدارة</button>' +
          '</div>' +
        '</td>' +
      '</tr>';
    }).join('') : '<tr><td colspan="8" style="text-align:center;padding:22px;color:var(--muted)">لا توجد اشتراكات مطابقة للفلاتر المحددة.</td></tr>';

    var filteredPayments = payments.filter(function (p) {
      if (uiState.finPlanFilter !== 'all' && p.plan !== uiState.finPlanFilter) return false;
      if (q) {
        var hay = [p.storeName, p.storeSlug, p.method, p.note, p.date].join(' ').toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });

    var paymentsTableRows = filteredPayments.length ? filteredPayments.map(function (p, idx) {
      var plObj = masterPlans[p.plan] || DEFAULT_PLANS[p.plan] || { name: p.plan, icon: '💳', color: '#4F46E5' };
      return '<tr>' +
        '<td><b>#' + (filteredPayments.length - idx) + '</b></td>' +
        '<td><b>' + esc(p.storeName || p.storeSlug) + '</b></td>' +
        '<td><span class="sym-badge st-plan">' + esc((plObj.icon || '💳') + ' ' + (plObj.name || p.plan)) + '</span></td>' +
        '<td><b style="color:var(--ok)">' + fmt(p.amount) + '</b></td>' +
        '<td>' + esc(p.method || 'زين كاش') + '</td>' +
        '<td dir="ltr">' + esc(p.date || todayISO()) + '</td>' +
        '<td>' + esc(p.note || '—') + '</td>' +
        '<td><button type="button" class="btn btn-danger btn-sm" style="padding:3px 8px" data-del-pay="' + esc(p.id) + '">🗑️</button></td>' +
      '</tr>';
    }).join('') : '<tr><td colspan="8" style="text-align:center;padding:22px;color:var(--muted)">لا توجد دفعات مالية مسجلة مطابقة للبحث.</td></tr>';

    var planFilterOpts = Object.keys(masterPlans).map(function (k) {
      var pl = masterPlans[k];
      return '<option value="' + esc(k) + '"' + (uiState.finPlanFilter === k ? ' selected' : '') + '>الباقة: ' + esc(pl.name) + '</option>';
    }).join('');

    box.innerHTML =
      '<div class="page-hdr">' +
        '<div class="page-hdr-title">' +
          '<h2>💳 الباقات والمالية وإدارة الاشتراكات</h2>' +
          '<p>إنشاء وتثبيت وتعديل وحذف الباقات وميزاتها، تسجيل الدفعات المالية، وفلترة الحسابات الفعالة وغير الفعالة</p>' +
        '</div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
          '<button type="button" class="btn btn-ok" id="plRecordPayBtn">💵 + تسجيل دفعة / تجديد اشتراك</button>' +
          '<button type="button" class="btn btn-primary" id="plCreatePlanBtn">➕ إنشاء باقة جديدة وتثبيتها</button>' +
        '</div>' +
      '</div>' +

      '<!-- بطاقات الباقات التفاعلية منسقة بصف واحد متكامل على قياس 100% -->' +
      '<div class="plans-cards-grid" id="plansCardsGrid">' + plansGridHtml + '</div>' +

      '<!-- قسم الحسابات والاشتراكات والسجل المالي بدون أي تمرير أفقي -->' +
      '<div class="apple-settings-group" style="margin-bottom:0">' +
        '<div class="asg-header">' +
          '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
            '<h3>📊 السجل المالي وحسابات الاشتراكات</h3>' +
            '<div class="chart-tabs" id="finViewTabs">' +
              '<button type="button" class="chart-tab ' + (uiState.finTab === 'subs' ? 'active' : '') + '" data-ft="subs">🏪 حسابات واشتراكات المتاجر (' + storeRows.length + ')</button>' +
              '<button type="button" class="chart-tab ' + (uiState.finTab === 'payments' ? 'active' : '') + '" data-ft="payments">💵 سجل الدفعات المالية (' + filteredPayments.length + ')</button>' +
            '</div>' +
          '</div>' +
          '<span class="sym-badge st-active">إجمالي التحصيلات: ' + fmt(m.totalRevenue) + '</span>' +
        '</div>' +

        '<div class="asg-body">' +
          '<div class="smart-filter-bar" style="grid-template-columns:1.6fr repeat(3, minmax(0, 1fr));margin-bottom:12px;box-shadow:none;background:var(--surface-2)">' +
            '<input type="search" class="sf-input" id="finSearchInp" placeholder="🔍 ابحث باسم المتجر، الكود، اسم المالك، رقم الهاتف، أو البيان..." value="' + esc(uiState.finSearch) + '">' +
            '<select class="sf-select" id="finStatusSel">' +
              '<option value="all"' + (uiState.finStatusFilter === 'all' ? ' selected' : '') + '>الحسابات: جميع الحسابات</option>' +
              '<option value="active"' + (uiState.finStatusFilter === 'active' ? ' selected' : '') + '>🟢 الحسابات الفعّالة فقط</option>' +
              '<option value="expiring"' + (uiState.finStatusFilter === 'expiring' ? ' selected' : '') + '>⏳ الحسابات القريبة من الانتهاء</option>' +
              '<option value="locked"' + (uiState.finStatusFilter === 'locked' ? ' selected' : '') + '>🔒 الحسابات غير الفعّالة / المقفولة</option>' +
            '</select>' +
            '<select class="sf-select" id="finPlanSel">' +
              '<option value="all">الاشتراك: كل الباقات</option>' +
              planFilterOpts +
            '</select>' +
            '<select class="sf-select" id="finSortSel">' +
              '<option value="newest"' + (uiState.finSort === 'newest' ? ' selected' : '') + '>الترتيب: الأحدث تسجيلاً</option>' +
              '<option value="price_desc"' + (uiState.finSort === 'price_desc' ? ' selected' : '') + '>الترتيب: الأعلى قيمة باقة</option>' +
              '<option value="expiry_asc"' + (uiState.finSort === 'expiry_asc' ? ' selected' : '') + '>الترتيب: الأقرب لانتهاء الاشتراك</option>' +
            '</select>' +
          '</div>' +

          '<div class="table-wrap" id="finTableWrap">' +
            (uiState.finTab === 'subs'
              ? '<table class="data-table"><thead><tr><th style="width:9%">الكود</th><th style="width:22%">المتجر والمالك</th><th style="width:14%">الباقة</th><th style="width:14%">حالة الحساب</th><th style="width:11%">قيمة الباقة</th><th style="width:11%">الانتهاء</th><th style="width:8%">السجل</th><th style="width:11%">إجراءات</th></tr></thead><tbody>' + subsTableRows + '</tbody></table>'
              : '<table class="data-table"><thead><tr><th style="width:6%">#</th><th style="width:19%">المتجر</th><th style="width:15%">الباقة</th><th style="width:13%">المبلغ المستلم</th><th style="width:15%">وسيلة الدفع</th><th style="width:11%">التاريخ</th><th style="width:14%">البيان</th><th style="width:7%">حذف</th></tr></thead><tbody>' + paymentsTableRows + '</tbody></table>') +
          '</div>' +
        '</div>' +
      '</div>';

    // أحداث الباقات والمالية
    $('#plCreatePlanBtn', box).onclick = function () { openPlanEditorModal(null); };
    $('#plRecordPayBtn', box).onclick = function () { openRecordPaymentModal(null); };

    $('#finViewTabs', box).onclick = function (e) {
      var b = e.target.closest('button[data-ft]');
      if (!b) return;
      uiState.finTab = b.getAttribute('data-ft');
      renderPlansPanel();
    };

    $('#plansCardsGrid', box).onclick = function (e) {
      var editBtn = e.target.closest('button[data-edit-plan]');
      if (editBtn) {
        openPlanEditorModal(editBtn.getAttribute('data-edit-plan'));
        return;
      }
      var delBtn = e.target.closest('button[data-del-plan]');
      if (delBtn) {
        var pid = delBtn.getAttribute('data-del-plan');
        var pl = masterPlans[pid];
        if (!pl) return;
        UI.confirm('هل أنت متأكد من حذف باقة "' + pl.name + '" نهائياً من قائمة الباقات؟', {
          title: 'حذف الباقة',
          type: 'danger',
          okText: 'نعم، احذف الباقة'
        }).then(function (ok) {
          if (!ok) return;
          delete masterPlans[pid];
          saveAllState();
          UI.toast('تم حذف الباقة ✓', 'info');
          renderPlansPanel();
        });
        return;
      }
      var addFeatBtn = e.target.closest('button[data-quick-add-feat]');
      if (addFeatBtn) {
        var pk = addFeatBtn.getAttribute('data-quick-add-feat');
        var inp = $('input[data-feat-inp="' + pk + '"]', box);
        var val = inp ? inp.value.trim() : '';
        if (!val) {
          UI.alert('يرجى كتابة نص الميزة أولاً قبل إضافتها.', { title: 'حقل مطلوب', type: 'warning' });
          return;
        }
        if (masterPlans[pk]) {
          if (!Array.isArray(masterPlans[pk].features)) masterPlans[pk].features = [];
          masterPlans[pk].features.push(val);
          saveAllState();
          UI.toast('تمت إضافة الميزة للباقة ✓', 'success');
          renderPlansPanel();
        }
        return;
      }
      var delFeatBtn = e.target.closest('button[data-del-feat]');
      if (delFeatBtn) {
        var parts = delFeatBtn.getAttribute('data-del-feat').split(':');
        var pk2 = parts[0], fIdx = Number(parts[1]);
        if (masterPlans[pk2] && Array.isArray(masterPlans[pk2].features)) {
          masterPlans[pk2].features.splice(fIdx, 1);
          saveAllState();
          UI.toast('تم حذف الميزة من الباقة', 'info');
          renderPlansPanel();
        }
      }
    };

    $('#finSearchInp', box).oninput = function (e) {
      uiState.finSearch = e.target.value;
      renderPlansPanel();
      var inp = $('#finSearchInp', box);
      if (inp) { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
    };
    $('#finStatusSel', box).onchange = function (e) { uiState.finStatusFilter = e.target.value; renderPlansPanel(); };
    $('#finPlanSel', box).onchange = function (e) { uiState.finPlanFilter = e.target.value; renderPlansPanel(); };
    $('#finSortSel', box).onchange = function (e) { uiState.finSort = e.target.value; renderPlansPanel(); };

    $('#finTableWrap', box).onclick = function (e) {
      var gotoBtn = e.target.closest('button[data-goto-store]');
      if (gotoBtn) {
        uiState.selectedStoreSlug = gotoBtn.getAttribute('data-goto-store');
        switchPanel('stores');
        return;
      }
      var renewBtn = e.target.closest('button[data-quick-renew]');
      if (renewBtn) {
        openRecordPaymentModal(renewBtn.getAttribute('data-quick-renew'));
        return;
      }
      var delPayBtn = e.target.closest('button[data-del-pay]');
      if (delPayBtn) {
        var payId = delPayBtn.getAttribute('data-del-pay');
        UI.confirm('هل أنت متأكد من حذف هذه الدفعة المالية من السجل؟', {
          title: 'حذف دفعة مالية',
          type: 'danger',
          okText: 'نعم، احذف الدفعة'
        }).then(function (ok) {
          if (!ok) return;
          payments = payments.filter(function (x) { return x.id !== payId; });
          saveAllState();
          UI.toast('تم حذف الدفعة المالية من السجل', 'info');
          renderPlansPanel();
        });
      }
    };
  }

  /* =========================================================================
     5. القائمة الخامسة: الإعدادات (#panel-settings)
        • إلغاء إرسال رمز البريد واستبداله بنظام حماية مباشر يعمل باسم المستخدم وكلمة المرور
        • تنسيق الصفحة بأسلوب إعدادات أبل السلس والمنظم
        • نظام نسخ احتياطي قوي وآمن (SHA-256 + تشفير اختياري + نقاط استعادة)
     ========================================================================= */
  async function computeSha256Hex(str) {
    try {
      if (window.crypto && window.crypto.subtle) {
        var buf = new TextEncoder().encode(str);
        var hash = await window.crypto.subtle.digest('SHA-256', buf);
        return Array.from(new Uint8Array(hash)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
      }
    } catch (e) { }
    var h = 2166136261;
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return ('00000000' + (h >>> 0).toString(16)).slice(-8) + '-sha256-fallback';
  }

  function xorCipherBase64(plainText, pass) {
    if (!pass) return btoa(unescape(encodeURIComponent(plainText)));
    var utf8 = unescape(encodeURIComponent(plainText));
    var out = '';
    for (var i = 0; i < utf8.length; i++) {
      out += String.fromCharCode(utf8.charCodeAt(i) ^ pass.charCodeAt(i % pass.length));
    }
    return btoa(out);
  }

  function xorDecipherBase64(b64, pass) {
    var raw = atob(b64);
    if (!pass) return decodeURIComponent(escape(raw));
    var out = '';
    for (var i = 0; i < raw.length; i++) {
      out += String.fromCharCode(raw.charCodeAt(i) ^ pass.charCodeAt(i % pass.length));
    }
    return decodeURIComponent(escape(out));
  }

  function createAutoSnapshot(label) {
    var snap = {
      id: 'snap-' + Date.now(),
      date: new Date().toLocaleString('ar-IQ'),
      label: label || 'نقطة استعادة تلقائية',
      storesCount: Object.keys(masterStores).length,
      paymentsCount: payments.length,
      payload: {
        masterStores: masterStores,
        masterPlans: masterPlans,
        storeTypes: storeTypes,
        payments: payments,
        cfg: cfg
      }
    };
    snapshots.unshift(snap);
    snapshots = snapshots.slice(0, 8);
    localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(snapshots));
  }

  function renderSettingsPanel() {
    var box = $('#panel-settings');
    if (!box) return;

    var avatarHtml = cfg.adminAvatar
      ? '<img src="' + esc(cfg.adminAvatar) + '" alt="Admin" style="width:100%;height:100%;object-fit:cover">'
      : esc((cfg.adminDisplayName || cfg.adminUsername || 'إ').trim().charAt(0).toUpperCase());

    var snapsHtml = snapshots.length ? snapshots.map(function (s, idx) {
      return '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px;border:1px solid var(--border);border-radius:16px;background:var(--surface-2)">' +
        '<div>' +
          '<b>🛡️ ' + esc(s.label) + '</b>' +
          '<div style="font-size:0.78rem;color:var(--muted)">التاريخ: ' + esc(s.date) + ' · المتاجر: ' + s.storesCount + ' · العمليات المالية: ' + s.paymentsCount + '</div>' +
        '</div>' +
        '<div style="display:flex;gap:8px">' +
          '<button type="button" class="btn btn-ghost btn-sm" data-restore-snap="' + idx + '">🔄 استعادة</button>' +
          '<button type="button" class="btn btn-danger btn-sm" data-del-snap="' + idx + '">🗑️</button>' +
        '</div>' +
      '</div>';
    }).join('') : '<p style="color:var(--muted);font-size:0.86rem">لا توجد نقاط استعادة محفوظة بعد. اضغط "إنشاء نقطة استعادة فورية" لحفظ نسخة آمنة داخل المتصفح.</p>';

    box.innerHTML =
      '<div class="page-hdr">' +
        '<div class="page-hdr-title">' +
          '<h2>⚙️ الإعدادات وحماية المنصة والنسخ الاحتياطي</h2>' +
          '<p>إدارة هوية وصورة الإدارة العامة، حماية المنصة باسم المستخدم وكلمة المرور، ونظام النسخ الاحتياطي المشفر</p>' +
        '</div>' +
        '<button type="button" class="btn btn-warn" id="setLockNowBtn">🔒 قفل المنصة الآن وتجربة شاشة الدخول</button>' +
      '</div>' +

      '<div class="bento-2col">' +

        '<!-- المجموعة 1: هوية الإدارة العامة وحماية المنصة باسم المستخدم وكلمة المرور -->' +
        '<div class="apple-settings-group" style="margin-bottom:0">' +
          '<div class="asg-header">' +
            '<h3><span class="asg-num">1</span> هوية الإدارة والدخول باسم المستخدم وكلمة المرور</h3>' +
            '<span class="sym-badge ' + (cfg.requireLogin ? 'st-active' : 'st-type') + '">' +
              (cfg.requireLogin ? '🔒 القفل مفعل' : '🔓 دخول مباشر') +
            '</span>' +
          '</div>' +
          '<div class="asg-body" style="display:flex;flex-direction:column;gap:10px">' +
            '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;background:var(--surface-2);border-radius:14px;border:1px solid var(--border)">' +
              '<div class="asm-avatar" style="width:46px;height:46px;border-radius:50%;font-size:1.2rem">' + avatarHtml + '</div>' +
              '<div style="flex:1;min-width:0">' +
                '<b style="font-size:0.82rem;display:block">صورة الإدارة العامة وشعار المنصة</b>' +
                '<span style="font-size:0.72rem;color:var(--muted)">تظهر في الشريط الجانبي وشاشة الدخول</span>' +
              '</div>' +
              '<input type="file" id="setAvatarFile" accept="image/*" style="display:none">' +
              '<button type="button" class="btn btn-primary btn-sm" id="setPickAvatarBtn">📷 تغيير الصورة</button>' +
              (cfg.adminAvatar ? '<button type="button" class="btn btn-danger btn-sm" id="setDelAvatarBtn">حذف</button>' : '') +
            '</div>' +

            '<div class="form-grid">' +
              '<label class="fld"><span>🏢 اسم المنصة العام</span><input id="setAgencyName" value="' + esc(cfg.agencyName || '') + '" placeholder="اسم المنصة العام"></label>' +
              '<label class="fld"><span>👤 الاسم الظاهر للإدارة</span><input id="setAdminDisplayName" value="' + esc(cfg.adminDisplayName || 'الإدارة العامة') + '"></label>' +
              '<label class="fld"><span>🔑 اسم المستخدم للدخول (Username) *</span><input id="setAdminUser" dir="ltr" value="' + esc(cfg.adminUsername || 'admin') + '"></label>' +
              '<label class="fld"><span>💬 واتساب الإدارة العامة</span><input id="setAgencyWa" dir="ltr" value="' + esc(cfg.agencyWhatsapp || '') + '"></label>' +
              '<label class="fld"><span>🔒 كلمة المرور *</span><input type="password" id="setAdminPass" dir="ltr" value="' + esc(cfg.adminPassword || '') + '"></label>' +
              '<label class="fld"><span>🔒 تأكيد كلمة المرور *</span><input type="password" id="setAdminPassConfirm" dir="ltr" value="' + esc(cfg.adminPassword || '') + '"></label>' +
              '<label class="fld" style="grid-column:1/-1"><span>🛡️ رمز الأمان السري للطوارئ (لاستعادة المنصة عند نسيان كلمة المرور)</span><input id="setRecoveryPin" dir="ltr" value="' + esc(cfg.recoveryPin || '0000') + '"></label>' +
            '</div>' +

            '<label style="display:flex;align-items:center;gap:8px;font-weight:800;font-size:0.82rem;cursor:pointer;padding:6px 10px;background:var(--surface-2);border-radius:12px;border:1px solid var(--border)">' +
              '<input type="checkbox" id="setRequireLogin"' + (cfg.requireLogin ? ' checked' : '') + ' style="width:17px;height:17px">' +
              '<span>تفعيل شاشة تسجيل الدخول باسم المستخدم وكلمة المرور عند فتح المنصة</span>' +
            '</label>' +
          '</div>' +
          '<div class="asg-footer">' +
            '<button type="button" class="btn btn-primary" style="width:100%" id="setSaveProfileBtn">💾 حفظ إعدادات اسم المستخدم وكلمة المرور</button>' +
          '</div>' +
        '</div>' +

        '<!-- المجموعة 2: نظام النسخ الاحتياطي القوي والآمن -->' +
        '<div class="apple-settings-group" style="margin-bottom:0">' +
          '<div class="asg-header">' +
            '<h3><span class="asg-num">2</span> نظام النسخ الاحتياطي الآمن (SHA-256 + تشفير)</h3>' +
            '<span class="sym-badge st-active">محمي ببصمة رقمية</span>' +
          '</div>' +
          '<div class="asg-body" style="display:flex;flex-direction:column;gap:12px">' +
            '<label class="fld">' +
              '<span>🔐 كلمة مرور تشفير النسخة الاحتياطية (اختياري)</span>' +
              '<input type="password" id="bkPassInp" placeholder="اتركها فارغة للنسخ القياسي الموقّع أو اكتب كلمة سر للتشفير...">' +
            '</label>' +

            '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
              '<button type="button" class="btn btn-primary" style="flex:1" id="bkExportBtn">📥 تصدير نسخة احتياطية (.spbak.json)</button>' +
              '<input type="file" id="bkImportFile" accept=".json" style="display:none">' +
              '<button type="button" class="btn btn-ghost" style="flex:1" id="bkImportBtn">📤 استيراد وفحص نسخة</button>' +
              '<button type="button" class="btn btn-ok btn-sm" style="width:100%" id="bkCreateSnapBtn">⚡ إنشاء نقطة استعادة فورية داخل المتصفح</button>' +
            '</div>' +

            '<div>' +
              '<b style="font-size:0.8rem;display:block;margin-bottom:6px">🕒 نقاط الاستعادة المحلية الآمنة (' + snapshots.length + '):</b>' +
              '<div style="display:flex;flex-direction:column;gap:6px" id="bkSnapsList">' + snapsHtml + '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +

      '</div>';

    // أحداث الإعدادات والأمان
    $('#setPickAvatarBtn', box).onclick = function () { $('#setAvatarFile', box).click(); };
    $('#setAvatarFile', box).onchange = function (e) {
      var f = (e.target.files || [])[0];
      if (!f) return;
      compressImageFile(f, 300, 0.86, function (dataUrl) {
        cfg.adminAvatar = dataUrl;
        saveAllState();
        UI.toast('تم تحديث صورة الإدارة العامة بنجاح ✓', 'success');
        renderSettingsPanel();
      });
    };
    var delAv = $('#setDelAvatarBtn', box);
    if (delAv) {
      delAv.onclick = function () {
        delete cfg.adminAvatar;
        saveAllState();
        UI.toast('تم حذف صورة الإدارة العامة', 'info');
        renderSettingsPanel();
      };
    }

    $('#setSaveProfileBtn', box).onclick = function () {
      var user = ($('#setAdminUser', box).value || '').trim();
      var pass = ($('#setAdminPass', box).value || '').trim();
      var pass2 = ($('#setAdminPassConfirm', box).value || '').trim();
      if (!user) {
        UI.alert('يرجى إدخال اسم المستخدم للإدارة العامة.', { title: 'حقل مطلوب', type: 'warning' });
        return;
      }
      if (!pass) {
        UI.alert('يرجى إدخال كلمة المرور للمنصة.', { title: 'حقل مطلوب', type: 'warning' });
        return;
      }
      if (pass !== pass2) {
        UI.alert('كلمة المرور وتأكيد كلمة المرور غير متطابقتين. يرجى التأكد منهما.', { title: 'عدم تطابق كلمة المرور', type: 'danger' });
        return;
      }
      cfg.agencyName = ($('#setAgencyName', box).value || '').trim() || cfg.agencyName;
      cfg.adminDisplayName = ($('#setAdminDisplayName', box).value || '').trim() || 'الإدارة العامة';
      cfg.adminUsername = user;
      cfg.adminPassword = pass;
      cfg.recoveryPin = ($('#setRecoveryPin', box).value || '').trim() || '0000';
      cfg.agencyWhatsapp = ($('#setAgencyWa', box).value || '').replace(/\D/g, '') || cfg.agencyWhatsapp;
      cfg.requireLogin = $('#setRequireLogin', box).checked;
      sessionStorage.setItem(SESSION_UNLOCK_KEY, '1');
      saveAllState();
      UI.toast('تم حفظ اسم المستخدم وكلمة المرور وإعدادات الحماية بنجاح ✓', 'success');
      renderSettingsPanel();
    };

    $('#setLockNowBtn', box).onclick = function () {
      sessionStorage.removeItem(SESSION_UNLOCK_KEY);
      checkPlatformLockScreen(true);
    };

    // النسخ الاحتياطي
    $('#bkExportBtn', box).onclick = async function () {
      var pass = ($('#bkPassInp', box).value || '').trim();
      var rawPayload = JSON.stringify({
        masterStores: masterStores,
        masterPlans: masterPlans,
        storeTypes: storeTypes,
        payments: payments,
        cfg: cfg
      });
      var checksum = await computeSha256Hex(rawPayload);
      var pkg = {
        platform: 'IraqStoresCentralPlatform',
        version: '6.5.0',
        exportedAt: new Date().toISOString(),
        encrypted: Boolean(pass),
        sha256: checksum,
        stats: {
          stores: Object.keys(masterStores).length,
          plans: Object.keys(masterPlans).length,
          types: Object.keys(storeTypes).length,
          payments: payments.length
        },
        data: pass ? xorCipherBase64(rawPayload, pass) : JSON.parse(rawPayload)
      };

      var blob = new Blob([JSON.stringify(pkg, null, 2)], { type: 'application/json;charset=utf-8' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'Platform_Secure_Backup_' + todayISO() + '.spbak.json';
      a.click();
      UI.toast('تم تصدير النسخة الاحتياطية الآمنة مع بصمة SHA-256 ✓', 'success');
    };

    $('#bkImportBtn', box).onclick = function () { $('#bkImportFile', box).click(); };
    $('#bkImportFile', box).onchange = function (e) {
      var file = (e.target.files || [])[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = async function (ev) {
        try {
          var pkg = JSON.parse(ev.target.result);
          var pass = ($('#bkPassInp', box).value || '').trim();
          var extracted = null;

          if (pkg.encrypted) {
            if (!pass) {
              pass = await UI.prompt('هذه النسخة الاحتياطية مشفرة بكلمة مرور. أدخل كلمة المرور لفك التشفير:', '', {
                title: '🔐 فك تشفير النسخة الاحتياطية',
                inputType: 'password',
                okText: 'فك التشفير والاستعادة'
              });
              if (!pass) return;
            }
            var decStr = xorDecipherBase64(pkg.data, pass);
            var verifyHash = await computeSha256Hex(decStr);
            if (pkg.sha256 && verifyHash !== pkg.sha256) {
              UI.alert('كلمة مرور فك التشفير غير صحيحة أو أن ملف النسخة الاحتياطية تالف.', { title: 'فشل التحقق الأمني', type: 'danger' });
              return;
            }
            extracted = JSON.parse(decStr);
          } else if (pkg.data && pkg.data.masterStores) {
            var rawCheck = JSON.stringify(pkg.data);
            var vHash = await computeSha256Hex(rawCheck);
            if (pkg.sha256 && vHash !== pkg.sha256) {
              UI.alert('تحذير: بصمة الأمان SHA-256 للملف لا تطابق المحتوى!', { title: 'خطأ في سلامة الملف', type: 'danger' });
              return;
            }
            extracted = pkg.data;
          } else if (pkg.masterStores) {
            extracted = pkg;
          }

          if (!extracted || !extracted.masterStores) {
            UI.alert('ملف النسخة الاحتياطية غير صالح.', { title: 'ملف غير صالح', type: 'danger' });
            return;
          }

          var ok = await UI.confirm('تم التحقق من سلامة النسخة الاحتياطية بنجاح (تحتوي على ' + Object.keys(extracted.masterStores).length + ' متجر). هل تريد استعادتها الآن؟', {
            title: '✅ تأكيد استعادة النسخة الاحتياطية الآمنة',
            type: 'success',
            okText: 'نعم، استعد البيانات الآن'
          });
          if (!ok) return;

          createAutoSnapshot('قبل استيراد نسخة خارجية');
          masterStores = extracted.masterStores || {};
          if (extracted.masterPlans) masterPlans = extracted.masterPlans;
          if (extracted.storeTypes) storeTypes = extracted.storeTypes;
          if (extracted.payments) payments = extracted.payments;
          if (extracted.cfg) cfg = extracted.cfg;
          normalizeMasterPlans();
          normalizeStoreTypes();
          saveAllState();
          UI.toast('تمت استعادة النسخة الاحتياطية بنجاح 🎉', 'success');
          renderActivePanel();
        } catch (err) {
          UI.alert('تعذر قراءة ملف النسخة الاحتياطية أو أن كلمة المرور غير صحيحة.', { title: 'خطأ في الاستيراد', type: 'danger' });
        }
      };
      reader.readAsText(file);
      e.target.value = '';
    };

    $('#bkCreateSnapBtn', box).onclick = function () {
      createAutoSnapshot('نسخة فورية يدوية');
      UI.toast('تم حفظ نقطة استعادة آمنة داخل المتصفح ✓', 'success');
      renderSettingsPanel();
    };

    $('#bkSnapsList', box).onclick = function (e) {
      var resBtn = e.target.closest('button[data-restore-snap]');
      if (resBtn) {
        var idx = Number(resBtn.getAttribute('data-restore-snap'));
        var snap = snapshots[idx];
        if (!snap || !snap.payload) return;
        UI.confirm('هل تريد استعادة نقطة الاستعادة المؤرخة في (' + snap.date + ')؟', {
          title: 'استعادة نقطة محلية',
          type: 'warning',
          okText: 'نعم، استعد الآن'
        }).then(function (ok) {
          if (!ok) return;
          masterStores = JSON.parse(JSON.stringify(snap.payload.masterStores || {}));
          if (snap.payload.masterPlans) masterPlans = JSON.parse(JSON.stringify(snap.payload.masterPlans));
          if (snap.payload.storeTypes) storeTypes = JSON.parse(JSON.stringify(snap.payload.storeTypes));
          if (snap.payload.payments) payments = JSON.parse(JSON.stringify(snap.payload.payments));
          if (snap.payload.cfg) cfg = JSON.parse(JSON.stringify(snap.payload.cfg));
          normalizeMasterPlans();
          normalizeStoreTypes();
          saveAllState();
          UI.toast('تمت استعادة البيانات من نقطة الاستعادة بنجاح ✓', 'success');
          renderActivePanel();
        });
        return;
      }
      var delBtn = e.target.closest('button[data-del-snap]');
      if (delBtn) {
        var idx2 = Number(delBtn.getAttribute('data-del-snap'));
        snapshots.splice(idx2, 1);
        localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(snapshots));
        UI.toast('تم حذف نقطة الاستعادة', 'info');
        renderSettingsPanel();
      }
    };
  }

  /* ---------- شاشة الدخول للمنصة باسم المستخدم وكلمة المرور ---------- */
  function checkPlatformLockScreen(forceLock) {
    var ov = $('#platformLockOverlay');
    var card = $('#platformLockCard');
    if (!ov || !card) return;
    if (!forceLock && (!cfg.requireLogin || sessionStorage.getItem(SESSION_UNLOCK_KEY) === '1')) {
      ov.classList.remove('open');
      return;
    }
    var avatarHtml = cfg.adminAvatar
      ? '<img src="' + esc(cfg.adminAvatar) + '" style="width:78px;height:78px;border-radius:50%;object-fit:cover;margin:0 auto;box-shadow:0 8px 24px rgba(79,70,229,0.25)">'
      : '<div style="width:78px;height:78px;border-radius:50%;background:linear-gradient(135deg,#4F46E5,#7C3AED);color:#fff;display:grid;place-items:center;font-size:2rem;font-weight:900;margin:0 auto;box-shadow:0 8px 24px rgba(79,70,229,0.25)">🔒</div>';

    card.innerHTML =
      avatarHtml +
      '<div>' +
        '<h3 style="font-size:1.35rem;font-weight:900">' + esc(cfg.agencyName || 'منصة إدارة المتاجر المركزية') + '</h3>' +
        '<p style="font-size:0.86rem;color:var(--muted);margin-top:4px">أدخل اسم المستخدم وكلمة المرور لفتح المنصة</p>' +
      '</div>' +
      '<div style="display:flex;flex-direction:column;gap:10px;text-align:right">' +
        '<label class="fld"><span>اسم المستخدم</span><input type="text" class="sf-input" id="plockUserInp" dir="ltr" value="' + esc(cfg.adminUsername || 'admin') + '" placeholder="admin"></label>' +
        '<label class="fld"><span>كلمة المرور</span><input type="password" class="sf-input" id="plockPassInp" dir="ltr" placeholder="••••••••"></label>' +
      '</div>' +
      '<button type="button" class="btn btn-primary btn-lg" id="plockLoginBtn" style="width:100%">🔓 تسجيل الدخول للمنصة</button>' +
      '<button type="button" class="btn btn-ghost btn-sm" id="plockForgotBtn" style="width:100%">🔑 نسيت كلمة المرور؟ استعادة برمز الأمان السري</button>';

    ov.classList.add('open');
    setTimeout(function () { var p = $('#plockPassInp', card); if (p) p.focus(); }, 60);

    var doLogin = function () {
      var uVal = ($('#plockUserInp', card).value || '').trim().toLowerCase();
      var pVal = ($('#plockPassInp', card).value || '').trim();
      var expectedUser = String(cfg.adminUsername || 'admin').trim().toLowerCase();
      var expectedPass = String(cfg.adminPassword || '1234').trim();

      if (uVal === expectedUser && pVal === expectedPass) {
        sessionStorage.setItem(SESSION_UNLOCK_KEY, '1');
        ov.classList.remove('open');
        UI.toast('مرحباً بك في منصة الإدارة المركزية ✓', 'success');
      } else {
        UI.alert('اسم المستخدم أو كلمة المرور غير صحيحة.', { title: 'خطأ في بيانات الدخول', type: 'danger' });
      }
    };

    $('#plockLoginBtn', card).onclick = doLogin;
    $('#plockPassInp', card).onkeydown = function (e) { if (e.key === 'Enter') doLogin(); };
    $('#plockForgotBtn', card).onclick = function () {
      UI.prompt('أدخل رمز الأمان السري للطوارئ (الافتراضي: 0000) لإعادة تعيين كلمة المرور:', '', {
        title: '🔑 استعادة الدخول برمز الأمان السري',
        dir: 'ltr',
        okText: 'التحقق من الرمز'
      }).then(function (pin) {
        if (pin == null) return;
        if (pin.trim() !== String(cfg.recoveryPin || '0000').trim()) {
          UI.alert('رمز الأمان السري غير صحيح.', { title: 'خطأ', type: 'danger' });
          return;
        }
        UI.prompt('تم التحقق بنجاح! اكتب كلمة المرور الجديدة للمنصة:', '', {
          title: '🔐 تعيين كلمة مرور جديدة',
          inputType: 'password',
          okText: 'حفظ والدخول للمنصة'
        }).then(function (newPass) {
          if (!newPass || !newPass.trim()) return;
          cfg.adminPassword = newPass.trim();
          sessionStorage.setItem(SESSION_UNLOCK_KEY, '1');
          saveAllState();
          ov.classList.remove('open');
          UI.toast('تم تحديث كلمة المرور وفتح المنصة بنجاح ✓', 'success');
          renderActivePanel();
        });
      });
    };
  }

  /* ---------- التبديل بين القوائم والوضع النهاري/الليلي (الدخول للإعدادات من خلال الإدارة العامة) ---------- */
  function switchPanel(panelId) {
    uiState.panel = panelId;
    $$('#sideNav .nav-item').forEach(function (btn) {
      btn.classList.toggle('active', btn.getAttribute('data-panel') === panelId);
    });
    var admCardEl = $('#sideAdminCard');
    if (admCardEl) {
      admCardEl.classList.toggle('active', panelId === 'settings');
    }
    $$('.workspace > .panel').forEach(function (sec) {
      sec.classList.toggle('active', sec.id === 'panel-' + panelId);
    });
    renderActivePanel();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function renderActivePanel() {
    updateSidebarIdentity();
    if (uiState.panel === 'cmd') renderCmdPanel();
    else if (uiState.panel === 'stores') renderStoresPanel();
    else if (uiState.panel === 'factory') renderFactoryPanel();
    else if (uiState.panel === 'plans') renderPlansPanel();
    else if (uiState.panel === 'settings') renderSettingsPanel();
    if (window.UI && window.UI.upgradeIcons) window.UI.upgradeIcons(document.body);
  }

  function initThemeAndNav() {
    var savedTheme = localStorage.getItem('agency_ui_theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    var tBtn = $('#themeToggleBtn');
    var updThemeBtn = function (th) {
      var ico = $('#themeToggleIco');
      var txt = $('#themeToggleTxt');
      if (ico) ico.innerHTML = window.spIcon ? window.spIcon(th === 'dark' ? 'sun' : 'sparkle') : (th === 'dark' ? '☀️' : '🌙');
      if (txt) txt.textContent = th === 'dark' ? 'الوضع النهاري' : 'الوضع الليلي';
    };
    updThemeBtn(savedTheme);

    if (tBtn) {
      tBtn.onclick = function () {
        var curr = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', curr);
        localStorage.setItem('agency_ui_theme', curr);
        updThemeBtn(curr);
      };
    }

    var nav = $('#sideNav');
    if (nav) {
      nav.onclick = function (e) {
        var btn = e.target.closest('button[data-panel]');
        if (!btn) return;
        var target = btn.getAttribute('data-panel');
        if (target === 'stores') uiState.selectedStoreSlug = null;
        switchPanel(target);
      };
    }

    var admCard = $('#sideAdminCard');
    if (admCard) {
      admCard.style.cursor = 'pointer';
      admCard.onclick = function () { switchPanel('settings'); };
      admCard.onkeydown = function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          switchPanel('settings');
        }
      };
    }
  }

  /* ---------- تشغيل المنصة ---------- */
  loadAllState();
  initThemeAndNav();
  renderActivePanel();
  checkPlatformLockScreen(false);
  hydrateSeededStoresFromIndex();
})();
