/* =========================================================
   محرك متاجر إنستغرام — Insta Store Engine v4.0 (Future-Proof)
   • مجاني 100% بلا حدود (يدعم GitHub Cloud / Google Script Cloud / Local)
   • ترقية تلقائية لهيكل البيانات (Auto Schema Migration) تحفظ كل المشتركين
   • يدعم كوبونات الخصم ومزايا الباقات (أسبوعي، شهري، سنوي، دائمي)
   ========================================================= */
(function () {
  'use strict';

  var ENGINE_VERSION = '4.0.0';
  var MASTER_STORES_KEY = 'agency_master_stores_v1';
  var MASTER_CFG_KEY = 'agency_master_config_v1';

  /* ---------- مترجم التوافق التلقائي (يحمي بيانات المشتركين عند أي تطوير مستقبلي) ---------- */
  function migrateStoreSchema(raw) {
    if (!raw || typeof raw !== 'object') return {};
    var s = JSON.parse(JSON.stringify(raw));
    s.schemaVersion = ENGINE_VERSION;
    if (!s.currency) s.currency = 'د.ع';
    if (!s.categories) s.categories = [];
    if (!s.products) s.products = [];
    if (!s.delivery) s.delivery = { default: 5000, freeOver: 0, provinces: { 'بغداد': 4000 } };
    if (!s.delivery.provinces) s.delivery.provinces = { 'بغداد': 4000 };
    if (!s.payment || !s.payment.length) s.payment = ['الدفع عند الاستلام'];
    if (!s.theme) s.theme = { primary: '#7A4E2D', accent: '#C89B6E', bg: '#FAF7F2', text: '#1F1A17' };
    if (!s.hero) s.hero = { title: '', subtitle: '' };
    if (!s.subscription) s.subscription = { plan: 'monthly', expires: '2027-12-31', graceDays: 3 };
    if (!s.coupons) s.coupons = []; // ميزة الإصدار 4.0: كوبونات الخصم
    if (!s.features) s.features = { coupons: true, whatsappFloat: true, shareButton: true };
    if (!s.socials || typeof s.socials !== 'object') s.socials = {};
    if (!s.socials.instagram && s.instagram) s.socials.instagram = s.instagram;
    if (!s.socials.facebook && s.facebook) s.socials.facebook = s.facebook;
    if (!s.socials.telegram && s.telegram) s.socials.telegram = s.telegram;
    if (!s.socials.tiktok && s.tiktok) s.socials.tiktok = s.tiktok;
    if (!s.socials.whatsappChannel && s.whatsappChannel) s.socials.whatsappChannel = s.whatsappChannel;
    return s;
  }

  /* ---------- قوالب القطاعات المدمجة (لتوليد أي متجر فوراً من الرابط دون إعادة رفع المشروع) ---------- */
  var SECTOR_TEMPLATES = {
    fashion: {
      title: 'بوتيك أزياء نسائية وعبايات', color: '#7A4E2D', tagline: 'أزياء نسائية راقية · توصيل لكل المحافظات',
      categories: ['عبايات', 'فساتين', 'أطقم كاجوال', 'قمصان وبلوزات', 'حقائب', 'أحذية', 'عطور', 'إكسسوارات'],
      useDemoProducts: true
    },
    cosmetics: {
      title: 'عطور وكوزمتك وعناية', color: '#9D174D', tagline: 'عطور أصلية · عناية بالبشرة · مكياج',
      categories: ['عطور نسائية', 'عطور رجالية', 'عناية بالبشرة', 'مكياج', 'مجموعات هدايا'],
      products: [
        { id: 'c-1', name: 'عطر عود العنبر الملكي 100 مل', category: 'عطور نسائية', price: 42000, oldPrice: 52000, badge: 'ثبات 48 ساعة', images: ['images/perfume.jpg'], sizes: ['50 مل', '100 مل'], colors: [], desc: 'تركيبة شرقية فاخرة من العود الكمبودي والعنبر الدافئ والزعفران.' },
        { id: 'c-2', name: 'مجموعة العناية المتكاملة بالبشرة', category: 'عناية بالبشرة', price: 35000, badge: 'الأكثر مبيعاً', images: ['images/perfume.jpg'], sizes: ['مجموعة كاملة'], colors: [], desc: 'سيروم فيتامين C مع مرطب عميق وغسول يومي لنضارة فورية.' }
      ]
    },
    abaya: {
      title: 'دار عبايات وشالات خليجية', color: '#1C1917', tagline: 'عبايات خليجية فاخرة · تفصيل حسب الطلب',
      categories: ['عبايات سوداء', 'عبايات ملونة', 'عبايات مناسبات', 'شالات وحجابات'],
      products: [
        { id: 'ab-1', name: 'عباية كريب ملكي مطرزة يدوياً', category: 'عبايات سوداء', price: 48000, oldPrice: 60000, badge: 'الأكثر مبيعاً', images: ['images/abaya.jpg'], sizes: ['52', '54', '56', '58', '60'], colors: [{ name: 'أسود ملكي', hex: '#141414' }], desc: 'قماش كريب كوري أصلي درجة أولى مع تطريز يدوي وشال مطابق.' },
        { id: 'ab-2', name: 'فستان وعباية سهرة مخمل', category: 'عبايات مناسبات', price: 65000, badge: 'إصدار خاص', images: ['images/evening-dress.jpg'], sizes: ['52', '54', '56', '58'], colors: [{ name: 'ماروني', hex: '#5B1A18' }], desc: 'تصميم ملكي فاخر للمناسبات الخاصة.' }
      ]
    },
    sport: {
      title: 'ملابس رياضية وكاجوال شبابي', color: '#1E3A8A', tagline: 'تراكسوتات · كاجوال · أحذية رياضية',
      categories: ['تراكسوتات', 'تيشيرتات', 'بناطيل كاجوال', 'أحذية رياضية', 'ساعات رياضية'],
      products: [
        { id: 'sp-1', name: 'طقم تراكسوت قطني مريح', category: 'تراكسوتات', price: 38000, badge: 'جديد', images: ['images/sport-set.jpg'], sizes: ['M', 'L', 'XL', 'XXL'], colors: [{ name: 'أخضر ميرمية', hex: '#8FA394' }, { name: 'أسود', hex: '#1F1F1F' }], desc: 'قطن تركي ممتاز مناسب للرياضة والطلعات اليومية.' }
      ]
    },
    shoes: {
      title: 'حقائب وأحذية جلدية', color: '#641E16', tagline: 'حقائب ماركات · أحذية مريحة · جلد طبيعي',
      categories: ['حقائب يد', 'حقائب كتف', 'أحذية كعب', 'أحذية فلات ومريحة'],
      products: [
        { id: 'sh-1', name: 'حقيبة جلد كراميل كلاسيك', category: 'حقائب يد', price: 35000, badge: 'الأكثر طلباً', images: ['images/handbag.jpg'], sizes: [], colors: [{ name: 'كراميل', hex: '#A86532' }, { name: 'أسود', hex: '#1B1B1B' }], desc: 'حقيبة جلدية فاخرة مع حزام كتف.' },
        { id: 'sh-2', name: 'حذاء كعب عالي نود أنيق', category: 'أحذية كعب', price: 29000, images: ['images/heels.jpg'], sizes: ['37', '38', '39', '40'], colors: [{ name: 'نود بيج', hex: '#D6B79E' }], desc: 'قالب طبي مريح جداً للمناسبات والدوام.' }
      ]
    },
      watches: {
      title: 'ساعات وإكسسوارات وهدايا', color: '#1C1917', tagline: 'ساعات أصلية · إكسسوارات · هدايا فخمة',
      categories: ['ساعات نسائية', 'ساعات رجالية', 'إكسسوارات ومجوهرات', 'بوكسات هدايا'],
      products: [
        { id: 'wt-1', name: 'ساعة ذهبية حصير ضد الماء', category: 'ساعات نسائية', price: 28000, oldPrice: 35000, badge: 'ضمان سنة', images: ['images/watch.jpg'], sizes: [], colors: [{ name: 'ذهبي', hex: '#D4AF37' }], desc: 'ساعة ستانلس ستيل أصلية ضد الماء مع علبة فخمة.' }
      ]
    },
    sweets: {
      title: 'مخبز وحلويات وكيك', color: '#9D174D', tagline: 'كيك · حلويات شرقية · بوكسات مناسبات',
      categories: ['كيك مناسبات', 'حلويات شرقية', 'بوكسات ضيافة', 'معجنات'],
      products: []
    },
    electronics: {
      title: 'إلكترونيات وإكسسوارات موبايل', color: '#1E3A8A', tagline: 'إكسسوارات موبايل · شواحن · سماعات',
      categories: ['سماعات', 'شواحن وكوابل', 'كفرات وحماية', 'ساعات ذكية'],
      products: []
    },
    kids: {
      title: 'ملابس وألعاب أطفال', color: '#047857', tagline: 'ملابس أطفال · ألعاب تعليمية · مستلزمات',
      categories: ['ملابس مواليد', 'ملابس بناتي', 'ملابس ولادي', 'ألعاب وهدايا'],
      products: []
    },
    decor: {
      title: 'ديكور ومنزل ومفروشات', color: '#7A4E2D', tagline: 'ديكور منزلي · إضاءة · مفارش',
      categories: ['تحفيات وديكور', 'إضاءة ومصابيح', 'مفارش وسجاد', 'مستلزمات مطبخ'],
      products: []
    }
  };

  var SEEDED_STORES_META = {
    'lujain': { n: 'بوتيك لُجين', tg: 'أزياء نسائية راقية · عطور · إكسسوارات', t: 'fashion', w: '9647700000001', ig: 'lujain.boutique.iq', pl: 'monthly', cl: '#7A4E2D' },
    'noor-beauty': { n: 'نور بيوتي', tg: 'عطور أصلية · عناية بالبشرة · مكياج', t: 'cosmetics', w: '9647700000002', ig: 'noor.beauty.iq', pl: 'yearly', cl: '#9D174D' },
    'dar-alabaya': { n: 'دار العبايات الملكية', tg: 'عبايات خليجية فاخرة · تفصيل حسب الطلب', t: 'abaya', w: '9647700000003', ig: 'dar.alabaya', pl: 'lifetime', cl: '#1C1917' },
    'sport-zone': { n: 'سبورت زون', tg: 'تراكسوتات · كاجوال · أحذية رياضية', t: 'sport', w: '9647700000004', ig: 'sportzone.iq', pl: 'weekly', cl: '#1E3A8A' },
    'kaab-alghazal': { n: 'كعب الغزال', tg: 'أحذية نسائية · حقائب جلد طبيعي', t: 'shoes', w: '9647700000005', ig: 'kaab.alghazal', pl: 'monthly', cl: '#641E16' },
    'time-gallery': { n: 'تايم كاليري', tg: 'ساعات أصلية · إكسسوارات · هدايا فخمة', t: 'watches', w: '9647700000006', ig: 'time.gallery.iq', pl: 'yearly', cl: '#1C1917' },
    'baghdad-sweets': { n: 'حلويات بغداد', tg: 'كيك · حلويات شرقية · بوكسات مناسبات', t: 'sweets', w: '9647700000007', ig: 'baghdad.sweets', pl: 'trial', cl: '#9D174D' },
    'smart-tech': { n: 'سمارت تك', tg: 'إكسسوارات موبايل · شواحن · سماعات', t: 'electronics', w: '9647700000008', ig: 'smarttech.iq', pl: 'monthly', cl: '#1E3A8A' },
    'little-stars': { n: 'نجوم صغار', tg: 'ملابس أطفال · ألعاب تعليمية · مستلزمات', t: 'kids', w: '9647700000009', ig: 'little.stars.iq', pl: 'lifetime', cl: '#047857' },
    'bayt-alfan': { n: 'بيت الفن للديكور', tg: 'ديكور منزلي · إضاءة · مفارش', t: 'decor', w: '9647700000010', ig: 'bayt.alfan', pl: 'weekly', cl: '#7A4E2D' },
    'stress-test': { n: 'متجر اختبار الأداء (150 منتج)', tg: 'متجر تجريبي لاختبار التحميل المجزأ 20 منتج في كل دفعة', t: 'fashion', w: '9647700000099', ig: 'stress.test.iq', pl: 'lifetime', cl: '#7A4E2D' }
  };

  try {
    var customTypes = JSON.parse(localStorage.getItem('agency_store_types_v1') || '{}') || {};
    Object.keys(customTypes).forEach(function (k) {
      if (customTypes[k] && customTypes[k].title) {
        SECTOR_TEMPLATES[k] = Object.assign({}, SECTOR_TEMPLATES[k] || {}, customTypes[k]);
      }
    });
  } catch (e) { }

  function buildStoreFromMiniObj(slug, mini) {
    if (!mini || !mini.n) return null;
    var tpl = SECTOR_TEMPLATES[mini.t] || SECTOR_TEMPLATES.fashion;
    var prods = (tpl.useDemoProducts && window.STORE && window.STORE.products)
      ? JSON.parse(JSON.stringify(window.STORE.products))
      : JSON.parse(JSON.stringify(tpl.products || []));
    return {
      slug: slug || mini.s || 'store-1',
      name: mini.n,
      tagline: mini.tg || tpl.tagline,
      whatsapp: mini.w || '9647700000000',
      instagram: mini.ig || '',
      socials: {
        instagram: mini.ig || '',
        facebook: mini.fb || '',
        telegram: mini.tgm || '',
        tiktok: mini.tk || '',
        whatsappChannel: mini.wac || ''
      },
      adminPin: mini.p || '1234',
      templateId: mini.t || 'fashion',
      currency: 'د.ع',
      orderPrefix: (slug || mini.s || 'STR').slice(0, 3).toUpperCase(),
      announcement: '✨ الدفع عند الاستلام والتوصيل السريع لجميع المحافظات ✨',
      theme: { primary: mini.cl || tpl.color || '#7A4E2D', accent: '#C89B6E', bg: '#FAF7F2', text: '#1F1A17' },
      hero: { title: 'أهلاً بكم في ' + mini.n + ' 🌸', subtitle: 'تصفحوا أحدث الموديلات والطلب يوصل لباب البيت' },
      subscription: {
        plan: mini.pl || 'monthly',
        expires: mini.ex || '2027-12-31',
        graceDays: 3,
        maxProducts: Number(mini.mp || 0),
        suspended: Boolean(mini.sp),
        hideBranding: Boolean(mini.hb)
      },
      delivery: {
        default: Number(mini.dd || 5000),
        freeOver: 75000,
        provinces: { 'بغداد': Number(mini.db || 4000) }
      },
      payment: ['الدفع عند الاستلام', 'زين كاش (ZainCash)', 'سوبر كي (SuperQi)'],
      categories: JSON.parse(JSON.stringify(tpl.categories || [])),
      products: prods,
      coupons: [{ code: 'WELCOME10', type: 'percent', value: 10, active: true }],
      footerNote: 'جميع الطلبات تُفحص قبل الإرسال · الاستبدال متاح خلال 48 ساعة'
    };
  }

  function buildStoreFromToken(slug, tokenStr) {
    if (!tokenStr) {
      if (slug && SEEDED_STORES_META[slug] && slug !== 'lujain') {
        return buildStoreFromMiniObj(slug, SEEDED_STORES_META[slug]);
      }
      return null;
    }
    try {
      var b64 = tokenStr.replace(/-/g, '+').replace(/_/g, '/');
      while (b64.length % 4) b64 += '=';
      var mini = JSON.parse(decodeURIComponent(escape(atob(b64))));
      return buildStoreFromMiniObj(slug, mini);
    } catch (e) { return null; }
  }

  /* ---------- تحديد المتجر المطلوب ---------- */
  var urlParams = new URLSearchParams(location.search);
  var requestedSlug = urlParams.get('store');
  var kToken = urlParams.get('k') || '';
  var baseStore = window.STORE || {};

  var masterStores = {};
  var agencyCfg = {};
  try { masterStores = JSON.parse(localStorage.getItem(MASTER_STORES_KEY) || '{}') || {}; } catch (e) { }
  try { agencyCfg = JSON.parse(localStorage.getItem(MASTER_CFG_KEY) || '{}') || {}; } catch (e) { }

  var activeSlug = requestedSlug || baseStore.slug || 'lujain';
  var tokenStore = buildStoreFromToken(activeSlug, kToken);

  if (requestedSlug && masterStores[requestedSlug]) {
    baseStore = masterStores[requestedSlug];
  } else if (tokenStore) {
    baseStore = tokenStore;
  } else if (masterStores[activeSlug]) {
    var ms = masterStores[activeSlug];
    baseStore = Object.assign({}, baseStore, ms, {
      products: (ms.products && ms.products.length) ? ms.products : baseStore.products,
      categories: (ms.categories && ms.categories.length) ? ms.categories : baseStore.categories
    });
  }

  if (!baseStore || !baseStore.name) {
    document.body.innerHTML = '<p style="padding:2rem;text-align:center">المتجر غير موجود أو لم يتم إعداده بعد.</p>';
    return;
  }

  /* ---------- دمج التعديلات المحفوظة وترقية الهيكل تلقائياً ---------- */
  var DATA_KEY = 'store_data_' + activeSlug;
  var S = migrateStoreSchema(baseStore);
  try {
    var savedStore = localStorage.getItem(DATA_KEY);
    if (savedStore) {
      var parsed = migrateStoreSchema(JSON.parse(savedStore));
      if (baseStore.subscription) parsed.subscription = baseStore.subscription;
      if (baseStore.poweredBy) parsed.poweredBy = baseStore.poweredBy;
      if (baseStore.features) parsed.features = Object.assign({}, parsed.features, baseStore.features);
      S = Object.assign({}, S, parsed);
    } else if (tokenStore && kToken) {
      localStorage.setItem(DATA_KEY, JSON.stringify(S));
    }
  } catch (e) { }

  /* ---------- المزامنة السحابية المجانية والتحميل المجزأ المستقل لكل متجر ---------- */
  var PAGE_SIZE = 20;
  var shardedPagesCache = {}; // key: "<catKey>-<page>" -> array of products
  var isShardedMode = false;

  function resolveRelUrl(relPath) {
    if (!relPath) return '';
    if (/^(https?:|data:|blob:|\/)/.test(relPath)) return relPath;
    if (location.pathname.indexOf('/stores/') !== -1 && (relPath.indexOf('data/') === 0 || relPath.indexOf('images/') === 0)) {
      if (relPath.indexOf('data/') === 0) return '../../' + relPath;
    }
    return relPath;
  }

  function getCatShardMeta(catName) {
    if (!S.catalog) return null;
    if (!catName || catName === 'all') return S.catalog.all || { key: 'all', count: 0, pages: 1 };
    var found = (S.catalog.cats || []).filter(function (c) { return c.name === catName; })[0];
    return found || { key: 'all', count: 0, pages: 1 };
  }

  function loadCategoryShardPage(catName, pageNum, cb) {
    var meta = getCatShardMeta(catName);
    if (!meta) { if (cb) cb([]); return; }
    var cacheKey = meta.key + '-' + pageNum;
    if (shardedPagesCache[cacheKey]) {
      if (cb) cb(shardedPagesCache[cacheKey]);
      return;
    }
    var shardUrl = resolveRelUrl('data/stores/' + encodeURIComponent(activeSlug) + '/p/' + cacheKey + '.json');
    fetch(shardUrl)
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        var items = (data && data.items) ? data.items : [];
        shardedPagesCache[cacheKey] = items;
        items.forEach(function (p) {
          byId[p.id] = p;
          if (!products.some(function (x) { return x.id === p.id; })) {
            products.push(p);
          }
        });
        if (cb) cb(items);
      })
      .catch(function () { if (cb) cb([]); });
  }

  function fetchShardedStoreIfAvailable() {
    // إذا كان التاجر قد عدّل المتجر محلياً في المتصفح وكان يحتوي على منتجات مخصصة، نحترم تعديلاته مع الإبقاء على تقسيم 20 منتج
    var localRaw = null;
    try { localRaw = JSON.parse(localStorage.getItem(DATA_KEY) || 'null'); } catch (e) { }
    if (localRaw && localRaw._merchantEdited) return;

    var storeMetaUrl = resolveRelUrl('data/stores/' + encodeURIComponent(activeSlug) + '/store.json');
    fetch(storeMetaUrl)
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (meta) {
        if (!meta || !meta.name) return;
        // دمج إعدادات المالك (الاسم، الصورة، النوع، الحسابات الاجتماعية، الاشتراك) إذا تم تحديثها من المنصة المركزية
        if (masterStores && masterStores[activeSlug]) {
          var ms = masterStores[activeSlug];
          if (ms.name) meta.name = ms.name;
          if (ms.logo) meta.logo = ms.logo;
          if (ms.templateId) meta.templateId = ms.templateId;
          if (ms.whatsapp) meta.whatsapp = ms.whatsapp;
          if (ms.instagram) meta.instagram = ms.instagram;
          if (ms.socials) meta.socials = Object.assign({}, meta.socials || {}, ms.socials);
          if (ms.subscription) meta.subscription = ms.subscription;
          if (ms.theme) meta.theme = Object.assign({}, meta.theme || {}, ms.theme);
        }
        isShardedMode = Boolean(meta.catalog);
        S = migrateStoreSchema(meta);
        shardedPagesCache = {};
        products = [];
        // جلب أول 20 منتج فقط للقسم الحالي بدلاً من كل المنتجات!
        loadCategoryShardPage(state.cat || 'all', 1, function () {
          bootStore();
        });
      })
      .catch(function () { });
  }

  function fetchCloudStoreIfConfigured() {
    var defaultCloud = (location.protocol.indexOf('http') === 0) ? ('/api/cloud?store=' + encodeURIComponent(activeSlug)) : '';
    var cloudUrl = (S.cloud && S.cloud.dataUrl) || (agencyCfg.cloudReadUrl ? agencyCfg.cloudReadUrl + '?store=' + encodeURIComponent(activeSlug) : defaultCloud);
    if (!cloudUrl) return;
    fetch(cloudUrl, { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (remoteData) {
        var actual = (remoteData && remoteData.store && remoteData.store.name) ? remoteData.store : remoteData;
        if (!actual || !actual.name) return;
        var migrated = migrateStoreSchema(actual);
        localStorage.setItem(DATA_KEY, JSON.stringify(migrated));
        if (JSON.stringify(migrated.products) !== JSON.stringify(S.products) ||
            JSON.stringify(migrated.subscription) !== JSON.stringify(S.subscription)) {
          isShardedMode = false;
          S = migrated;
          bootStore();
        }
      })
      .catch(function () { /* يعمل بالنسخة المحلية فوراً بدون انقطاع */ });
  }

  if (agencyCfg.agencyName && (!S.subscription || !S.subscription.hideBranding)) {
    var agWa = String(agencyCfg.agencyWhatsapp || '9647700000000').replace(/\D/g, '');
    S.poweredBy = {
      text: '⚡ ' + agencyCfg.agencyName + ' — اطلب متجرك الإلكتروني الآن',
      url: 'https://wa.me/' + agWa + '?text=' + encodeURIComponent('مرحباً، شفت متجر (' + S.name + ') وأريد متجر إلكتروني مثله لصفحتي')
    };
  } else if (S.subscription && S.subscription.hideBranding) {
    S.poweredBy = null;
  }

  window.addEventListener('storage', function (e) {
    if (e.key === DATA_KEY || e.key === MASTER_STORES_KEY || e.key === MASTER_CFG_KEY) location.reload();
  });

  /* ---------- أدوات مساعدة ---------- */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var CUR = S.currency || 'د.ع';
  var fmt = function (n) { return Number(n || 0).toLocaleString('en-US') + ' ' + CUR; };
  var toEnDigits = function (s) {
    return String(s || '').replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); })
      .replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); });
  };
  var waNumber = String(S.whatsapp || '').replace(/\D/g, '');
  var waLink = function (text) { return 'https://wa.me/' + waNumber + (text ? '?text=' + encodeURIComponent(text) : ''); };

  var PROVINCES = ['بغداد', 'البصرة', 'نينوى', 'أربيل', 'السليمانية', 'دهوك', 'حلبجة', 'كركوك', 'الأنبار', 'بابل',
    'كربلاء', 'النجف', 'واسط', 'ذي قار', 'ميسان', 'المثنى', 'القادسية', 'ديالى', 'صلاح الدين'];

  var PLAN_LABELS = {
    trial: 'تجريبي',
    weekly: 'أسبوعي',
    monthly: 'شهري',
    yearly: 'سنوي',
    lifetime: 'دائمي مدى الحياة ♾️'
  };

  var ICON = {
    cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6h15l-1.5 9h-12z"/><path d="M6 6 5 3H2"/><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/></svg>',
    wa: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.3-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.4.1-.6.3-.2.2-.8.8-.8 2s.8 2.3.9 2.5c.1.2 1.6 2.5 4 3.5 1.5.6 2 .7 2.8.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2l-.5-.2z"/></svg>',
    ig: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>',
    fb: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.5 22v-8.2h2.8l.4-3.2h-3.2V8.5c0-.9.3-1.6 1.6-1.6h1.7V4.1c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.3H7.3v3.2h2.8V22h3.4z"/></svg>',
    tg: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.5 4.4 2.9 11.6c-1.2.5-1.2 1.2-.2 1.5l4.8 1.5 11-6.9c.5-.3 1-.1.6.2l-8.9 8-.3 4.9c.5 0 .7-.2 1-.5l2.4-2.3 5 3.7c.9.5 1.6.2 1.8-.9l3.1-14.8c.3-1.3-.5-1.9-1.7-1.6z"/></svg>',
    tk: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16.6 5.8A4.3 4.3 0 0 1 15.4 3h-3.1v12.4a2.6 2.6 0 1 1-1.8-2.5V9.7a5.8 5.8 0 1 0 5 5.7V9.1a7.4 7.4 0 0 0 4.3 1.4V7.4c-1.2 0-2.4-.6-3.2-1.6z"/></svg>',
    wheel: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.5"/><path d="M12 3v6.5M12 14.5V21M3 12h6.5M14.5 12H21M5.6 5.6l4.6 4.6M13.8 13.8l4.6 4.6M18.4 5.6l-4.6 4.6M10.2 13.8l-4.6 4.6"/></svg>',
    video: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.14v13.72a1 1 0 0 0 1.55.83l11-6.86a1 1 0 0 0 0-1.66l-11-6.86A1 1 0 0 0 8 5.14z"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M10 11v6M14 11v6M5 7l1 13h12l1-13M9 7V4h6v3"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5L20 7"/></svg>'
  };

  function normalizeExternalVideoUrl(rawUrl) {
    var v = String(rawUrl || '').trim();
    if (!v) return '';
    if (/^https?:\/\//i.test(v)) return v;
    return 'https://' + v.replace(/^\/+/, '');
  }

  function normalizeSocialUrl(platform, val) {
    var v = String(val || '').trim();
    if (!v) return '';
    if (/^https?:\/\//i.test(v)) return v;
    var clean = v.replace(/^@/, '').replace(/^\/+/, '');
    if (platform === 'instagram') return 'https://instagram.com/' + clean;
    if (platform === 'facebook') return 'https://facebook.com/' + clean;
    if (platform === 'telegram') return 'https://t.me/' + clean;
    if (platform === 'tiktok') return 'https://tiktok.com/@' + clean;
    if (platform === 'whatsapp') {
      if (/^\+?\d{8,15}$/.test(clean.replace(/\D/g, ''))) {
        return 'https://wa.me/' + clean.replace(/\D/g, '');
      }
      return 'https://' + clean;
    }
    return 'https://' + clean;
  }

  function getStoreSocialList() {
    var sc = S.socials || {};
    var list = [];
    var igVal = sc.instagram || S.instagram || '';
    var fbVal = sc.facebook || S.facebook || '';
    var tgVal = sc.telegram || S.telegram || '';
    var tkVal = sc.tiktok || S.tiktok || '';
    var waVal = sc.whatsappChannel || S.whatsappChannel || (waNumber ? ('https://wa.me/' + waNumber) : '');

    if (fbVal) list.push({ id: 'fb', title: 'صفحة فيسبوك', url: normalizeSocialUrl('facebook', fbVal), icon: ICON.fb });
    if (igVal) list.push({ id: 'ig', title: 'حساب إنستغرام', url: normalizeSocialUrl('instagram', igVal), icon: ICON.ig });
    if (tgVal) list.push({ id: 'tg', title: 'قناة تلجرام', url: normalizeSocialUrl('telegram', tgVal), icon: ICON.tg });
    if (tkVal) list.push({ id: 'tk', title: 'حساب تيك توك', url: normalizeSocialUrl('tiktok', tkVal), icon: ICON.tk });
    if (waVal) list.push({ id: 'wa', title: 'قناة / تواصل واتساب', url: normalizeSocialUrl('whatsapp', waVal), icon: ICON.wa });
    return list;
  }

  function buildFollowWheelHtml() {
    var list = getStoreSocialList();
    if (!list.length) return '';
    var total = list.length;
    var orbs = list.map(function (item, idx) {
      return '<a class="social-orb ' + item.id + '" style="--i:' + idx + ';--total:' + total + '" href="' + esc(item.url) + '" target="_blank" rel="noopener noreferrer" title="' + esc(item.title) + '" aria-label="' + esc(item.title) + '">' + item.icon + '</a>';
    }).join('');
    return '<div class="social-wheel" id="socialWheel">' +
      '<div class="social-wheel-hub">' +
        '<button type="button" class="social-wheel-disc" id="followWheelBtn" aria-expanded="false" title="تابعنا على منصات التواصل">' +
          '<span class="sw-wheel-ico">' + ICON.wheel + '</span>' +
          '<span class="sw-close-ico">' + ICON.close + '</span>' +
        '</button>' +
        '<span class="social-wheel-caption">تابعنا</span>' +
      '</div>' +
      '<div class="social-wheel-tray" id="socialWheelTray">' + orbs + '</div>' +
    '</div>';
  }

  window.__imgFail = function (img) {
    var ph = document.createElement('div');
    ph.className = 'img-ph';
    ph.textContent = (img.getAttribute('alt') || S.name || '؟').trim().charAt(0);
    img.replaceWith(ph);
  };
  var imgTag = function (src, alt, cls) {
    if (!src) return '<div class="img-ph ' + (cls || '') + '">' + esc((alt || '؟').trim().charAt(0)) + '</div>';
    return '<img class="' + (cls || '') + '" src="' + esc(resolveRelUrl(src)) + '" alt="' + esc(alt) + '" loading="lazy" decoding="async" onerror="__imgFail(this)">';
  };

  /* ---------- منطق الاشتراكات ---------- */
  var sub = S.subscription || {};
  function isLifetime() {
    return sub.plan === 'lifetime' || sub.expires === 'lifetime' || sub.expires === '9999-12-31';
  }
  function expiryDate() {
    if (isLifetime() || !sub.expires) return null;
    var d = new Date(sub.expires + 'T23:59:59');
    return isNaN(d) ? null : d;
  }
  function daysLeft() {
    if (isLifetime()) return Infinity;
    var d = expiryDate(); if (!d) return Infinity;
    return Math.ceil((d - new Date()) / 86400000);
  }
  function isLocked() {
    if (sub.suspended) return true;
    if (isLifetime()) return false;
    var d = expiryDate(); if (!d) return false;
    var grace = Number(sub.graceDays || 0);
    return daysLeft() < -grace;
  }

  /* ---------- السلة وكوبونات الخصم ---------- */
  var CART_KEY = 'cart_' + activeSlug;
  var cart = [];
  var activeCoupon = null;
  var products = [];
  var byId = {};

  function initProductsAndCart() {
    sub = S.subscription || {};
    CUR = S.currency || 'د.ع';
    waNumber = String(S.whatsapp || '').replace(/\D/g, '');
    try { cart = JSON.parse(localStorage.getItem(CART_KEY) || '[]') || []; } catch (e) { cart = []; }
    if (!isShardedMode) {
      products = (S.products || []).filter(function (p) { return !p.hidden; });
      if (sub.maxProducts && Number(sub.maxProducts) > 0) {
        products = products.slice(0, Number(sub.maxProducts));
      }
      byId = {};
      products.forEach(function (p) { byId[p.id] = p; });
    } else {
      products.forEach(function (p) { byId[p.id] = p; });
    }
    cart = cart.filter(function (i) { return byId[i.id]; });
  }

  function saveCart() { try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch (e) { } updateFab(); }
  function cartCount() { return cart.reduce(function (a, i) { return a + i.qty; }, 0); }
  function subtotal() { return cart.reduce(function (a, i) { return a + byId[i.id].price * i.qty; }, 0); }
  function couponDiscountAmount() {
    if (!activeCoupon) return 0;
    var st = subtotal();
    if (activeCoupon.type === 'percent') {
      return Math.round(st * (Number(activeCoupon.value || 0) / 100));
    }
    return Math.min(st, Number(activeCoupon.value || 0));
  }
  function deliveryFee(prov) {
    var d = S.delivery || {};
    var afterDisc = Math.max(0, subtotal() - couponDiscountAmount());
    if (d.freeOver && afterDisc >= d.freeOver) return 0;
    if (!prov) return null;
    var p = d.provinces || {};
    return p[prov] != null ? p[prov] : (d.default || 0);
  }
  function addToCart(id, size, color, qty) {
    var key = id + '|' + (size || '') + '|' + (color || '');
    var found = cart.filter(function (i) { return i.key === key; })[0];
    if (found) found.qty += qty; else cart.push({ key: key, id: id, size: size || '', color: color || '', qty: qty });
    saveCart();
  }

  function applyTheme() {
    var t = S.theme || {}, r = document.documentElement.style;
    if (t.primary) r.setProperty('--primary', t.primary);
    if (t.accent) r.setProperty('--accent', t.accent);
    if (t.bg) r.setProperty('--bg', t.bg);
    if (t.text) r.setProperty('--text', t.text);
    document.title = S.name + (S.tagline ? ' | ' + S.tagline : '');
  }

  function logoHtml(big) {
    var cls = 'logo' + (big ? ' logo-big' : '');
    if (S.logo) return '<img class="' + cls + '" src="' + esc(S.logo) + '" alt="' + esc(S.name) + '" onerror="__imgFail(this)">';
    return '<div class="' + cls + ' logo-txt">' + esc(S.name.replace(/^(بوتيك|متجر|محل)\s+/, '').trim().charAt(0)) + '</div>';
  }

  function getAdminHref() {
    var kPart = kToken ? '&k=' + encodeURIComponent(kToken) : '';
    if (location.pathname.indexOf('/stores/') !== -1) {
      return 'admin.html?store=' + encodeURIComponent(activeSlug) + kPart;
    }
    return '?admin=' + encodeURIComponent(activeSlug) + kPart;
  }

  function renderLock() {
    var lockNote = sub.suspendReason || agencyCfg.lockMessage || 'المتجر الإلكتروني متوقف مؤقتاً لتجديد الاشتراك';
    document.getElementById('app').innerHTML =
      '<div class="lock"><div class="lock-card">' + logoHtml(true) +
      '<h1>' + esc(S.name) + '</h1>' +
      '<p class="lock-msg">' + esc(lockNote) + '</p>' +
      '<p class="muted">للطلب المباشر أو الاستفسار تواصلوا معنا عبر واتساب</p>' +
      (waNumber ? '<a class="btn btn-wa" href="' + waLink('مرحباً، أريد أستفسر عن المنتجات') + '" target="_blank" rel="noopener">' + ICON.wa + ' تواصل عبر واتساب</a>' : '') +
      '<a href="' + getAdminHref() + '" style="font-size:0.8rem;color:var(--muted);margin-top:8px">دخول مالك المتجر ⚙️</a>' +
      '</div></div>';
  }

  function renderShell() {
    var cats = S.categories || [];
    var hero = S.hero || {};
    var admin = /[?&]owner=1\b/.test(location.search);
    var dl = daysLeft();
    var planName = PLAN_LABELS[sub.plan || 'monthly'] || 'شهري';
    var adminHref = getAdminHref();
    var html = '';
    if (admin) {
      var subTxt = isLifetime() ? 'اشتراك دائمي مدى الحياة ♾️' :
        (dl !== Infinity ? (dl >= 0 ? 'باقة (' + planName + ') — متبقي ' + dl + ' يوم' : 'انتهى الاشتراك منذ ' + (-dl) + ' يوم') : 'فعّال');
      html += '<div class="admin-bar ' + (!isLifetime() && dl <= 5 ? 'warn' : '') + '">' +
        '<span>وضع المالك: ' + esc(subTxt) + '</span> ' +
        '<a href="' + adminHref + '" style="background:#fff;color:#1F1A17;padding:3px 10px;border-radius:99px;margin-right:8px;font-weight:800">⚙️ فتح لوحة إدارة المنتجات</a>' +
        '</div>';
    }
    if (S.announcement) html += '<div class="announce">' + esc(S.announcement) + '</div>';
    html +=
      '<header class="hdr"><div class="brand">' + logoHtml(false) +
      '<div><div class="brand-name">' + esc(S.name) + '</div>' +
      (S.tagline ? '<div class="brand-tag">' + esc(S.tagline) + '</div>' : '') + '</div></div>' +
      '<div class="hdr-actions">' +
      buildFollowWheelHtml() +
      '</div></header>';
    if (hero.title || hero.subtitle) {
      html += '<section class="hero"' + (hero.image ? ' style="--hero-img:url(\'' + esc(hero.image) + '\')"' : '') + '>' +
        '<div class="hero-in"><h1>' + esc(hero.title || '') + '</h1>' +
        (hero.subtitle ? '<p>' + esc(hero.subtitle) + '</p>' : '') + '</div></section>';
    }
    html +=
      '<div class="toolbar"><label class="search">' + ICON.search +
      '<input id="q" type="search" placeholder="ابحث عن منتج..." autocomplete="off"></label>' +
      '<div class="chips" id="chips"><button class="chip ' + (state.cat === 'all' ? 'active' : '') + '" data-cat="all">الكل</button>' +
      cats.map(function (c) { return '<button class="chip ' + (state.cat === c ? 'active' : '') + '" data-cat="' + esc(c) + '">' + esc(c) + '</button>'; }).join('') +
      '</div></div>' +
      '<main class="grid" id="grid"></main>' +
      '<div id="gridSentinel" style="height:2px" aria-hidden="true"></div>' +
      '<footer class="ftr">' +
      (S.footerNote ? '<p>' + esc(S.footerNote) + '</p>' : '') +
      '<p class="muted">© ' + new Date().getFullYear() + ' ' + esc(S.name) + '</p>' +
      (S.poweredBy ? '<p class="powered">' + (S.poweredBy.url ? '<a href="' + esc(S.poweredBy.url) + '" target="_blank" rel="noopener">' + esc(S.poweredBy.text) + '</a>' : esc(S.poweredBy.text)) + '</p>' : '') +
      '</footer>' +
      '<button class="fab" id="fab" aria-label="السلة">' + ICON.cart + '<span>السلة</span><b id="fabCount">0</b><em id="fabTotal"></em></button>' +
      '<div class="backdrop" id="backdrop"></div>' +
      '<section class="sheet" id="sheet" role="dialog" aria-modal="true"></section>' +
      '<div class="toast" id="toast"></div>';
    document.getElementById('app').innerHTML = html;

    var fwBtn = $('#followWheelBtn');
    var swWrap = $('#socialWheel');
    if (fwBtn && swWrap) {
      fwBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var isOpen = swWrap.classList.toggle('open');
        fwBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      });
      document.addEventListener('click', function (e) {
        if (swWrap.classList.contains('open') && !swWrap.contains(e.target)) {
          swWrap.classList.remove('open');
          fwBtn.setAttribute('aria-expanded', 'false');
        }
      });
    }
    $('#q').addEventListener('input', function (e) {
      state.q = e.target.value.trim();
      state.page = 1;
      state.limit = PAGE_SIZE;
      renderGrid();
    });
    $('#chips').addEventListener('click', function (e) {
      var b = e.target.closest('.chip'); if (!b) return;
      $$('.chip').forEach(function (c) { c.classList.toggle('active', c === b); });
      state.cat = b.getAttribute('data-cat');
      state.page = 1;
      state.limit = PAGE_SIZE;
      if (isShardedMode) {
        loadCategoryShardPage(state.cat, 1, function () { renderGrid(); });
      } else {
        renderGrid();
      }
    });
    $('#grid').addEventListener('click', function (e) {
      if (e.target.closest('.card-video-pill')) {
        e.stopPropagation();
        return;
      }
      var c = e.target.closest('.card'); if (c) openProduct(c.getAttribute('data-id'));
    });
    $('#fab').addEventListener('click', openCart);
    $('#backdrop').addEventListener('click', closeSheet);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSheet(); });
    window.addEventListener('hashchange', routeHash);
    setupAutoInfiniteScroll();
  }

  var state = { cat: 'all', q: '', page: 1, limit: PAGE_SIZE, loadingMore: false };
  function discount(p) { return p.oldPrice && p.oldPrice > p.price ? Math.round((1 - p.price / p.oldPrice) * 100) : 0; }

  function loadNextBatchSilently() {
    if (state.loadingMore) return;
    var res = getActiveCategoryList();
    if (!res.hasMore) return;
    state.loadingMore = true;
    state.page += 1;
    state.limit += PAGE_SIZE;
    if (isShardedMode) {
      loadCategoryShardPage(state.cat, state.page, function () {
        state.loadingMore = false;
        renderGrid();
      });
    } else {
      state.loadingMore = false;
      renderGrid();
    }
  }

  function setupAutoInfiniteScroll() {
    var sentinel = $('#gridSentinel');
    if (sentinel && 'IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        if (document.body.classList.contains('noscroll')) return;
        entries.forEach(function (entry) {
          if (entry.isIntersecting) loadNextBatchSilently();
        });
      }, { rootMargin: '320px 0px' });
      io.observe(sentinel);
    }
    window.addEventListener('scroll', function () {
      if (document.body.classList.contains('noscroll')) return;
      if ((window.innerHeight + window.scrollY) >= (document.body.offsetHeight - 420)) {
        loadNextBatchSilently();
      }
    }, { passive: true });
  }

  function getActiveCategoryList() {
    var q = state.q.toLowerCase();
    if (isShardedMode && !q) {
      var meta = getCatShardMeta(state.cat);
      var combined = [];
      for (var pg = 1; pg <= state.page; pg++) {
        var chunk = shardedPagesCache[meta.key + '-' + pg] || [];
        combined = combined.concat(chunk);
      }
      return {
        visible: combined.slice(0, state.limit),
        totalCount: meta.count || combined.length,
        hasMore: (combined.length < (meta.count || 0)) || (state.page < (meta.pages || 1))
      };
    }
    var filtered = products.filter(function (p) {
      if (state.cat !== 'all' && p.category !== state.cat) return false;
      if (q && (p.name + ' ' + (p.desc || '') + ' ' + (p.category || '')).toLowerCase().indexOf(q) === -1) return false;
      return true;
    });
    return {
      visible: filtered.slice(0, state.limit),
      totalCount: filtered.length,
      hasMore: filtered.length > state.limit
    };
  }

  function renderGrid() {
    var res = getActiveCategoryList();
    var list = res.visible;

    if (!list.length) {
      $('#grid').innerHTML = '<p class="empty">ما لقينا منتجات مطابقة 🙁</p>';
      return;
    }

    $('#grid').innerHTML = list.map(function (p) {
      var d = discount(p);
      var videoHref = normalizeExternalVideoUrl(p.videoUrl);
      return '<article class="card' + (p.soldOut ? ' sold' : '') + '" data-id="' + esc(p.id) + '" tabindex="0">' +
        '<div class="card-img">' + imgTag((p.images || [])[0], p.name) +
        (d ? '<span class="badge sale">-' + d + '%</span>' : (p.badge ? '<span class="badge">' + esc(p.badge) + '</span>' : '')) +
        (videoHref ? '<a class="card-video-pill" href="' + esc(videoHref) + '" target="_blank" rel="noopener noreferrer" title="مشاهدة فيديو المنتج"><span class="cvp-play">' + ICON.video + '</span><span>فيديو</span></a>' : '') +
        (p.soldOut ? '<span class="soldout">نفذت الكمية</span>' : '') + '</div>' +
        '<div class="card-body"><h3>' + esc(p.name) + '</h3><div class="price"><b>' + fmt(p.price) + '</b>' +
        (d ? '<s>' + fmt(p.oldPrice) + '</s>' : '') + '</div></div></article>';
    }).join('');
  }

  function updateFab() {
    var n = cartCount(), fab = $('#fab'); if (!fab) return;
    $('#fabCount').textContent = n;
    $('#fabTotal').textContent = n ? fmt(Math.max(0, subtotal() - couponDiscountAmount())) : '';
    fab.classList.toggle('show', n > 0);
  }

  var lockedScrollY = 0;
  var isSheetScrollLocked = false;

  function lockBackgroundScroll() {
    if (isSheetScrollLocked) return;
    lockedScrollY = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
    isSheetScrollLocked = true;
    document.documentElement.classList.add('noscroll');
    document.body.classList.add('noscroll');
    document.body.style.position = 'fixed';
    document.body.style.top = (-lockedScrollY) + 'px';
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.width = '100%';
  }

  function unlockBackgroundScroll() {
    if (!isSheetScrollLocked) return;
    isSheetScrollLocked = false;
    document.documentElement.classList.remove('noscroll');
    document.body.classList.remove('noscroll');
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    document.body.style.width = '';
    var prevScrollBehavior = document.documentElement.style.scrollBehavior;
    document.documentElement.style.scrollBehavior = 'auto';
    window.scrollTo(0, lockedScrollY);
    requestAnimationFrame(function () {
      document.documentElement.style.scrollBehavior = prevScrollBehavior || '';
    });
  }

  function openSheet(html, cls) {
    var sh = $('#sheet');
    var bd = $('#backdrop');
    lockBackgroundScroll();
    sh.className = 'sheet ' + (cls || '');
    sh.innerHTML = '<button class="sheet-close" aria-label="إغلاق">' + ICON.close + '</button><div class="sheet-scroll" id="sheetScroll">' + html + '</div>';
    sh.querySelector('.sheet-close').addEventListener('click', closeSheet);
    if (bd && !bd._scrollGuarded) {
      bd._scrollGuarded = true;
      bd.addEventListener('wheel', function (e) { e.preventDefault(); }, { passive: false });
      bd.addEventListener('touchmove', function (e) { e.preventDefault(); }, { passive: false });
    }
    var sc = $('#sheetScroll', sh);
    if (sc) sc.scrollTop = 0;
    requestAnimationFrame(function () { sh.classList.add('open'); if (bd) bd.classList.add('open'); });
  }
  function closeSheet() {
    var sh = $('#sheet'); if (!sh) return;
    sh.classList.remove('open');
    var bd = $('#backdrop');
    if (bd) bd.classList.remove('open');
    unlockBackgroundScroll();
    if (/^#p=/.test(location.hash)) history.replaceState(null, '', location.pathname + location.search);
  }
  function toast(msg) {
    var t = $('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  function openProduct(id) {
    var p = byId[id]; if (!p) return;
    if (location.hash !== '#p=' + id) history.replaceState(null, '', '#p=' + encodeURIComponent(id));
    var imgs = (p.images && p.images.length) ? p.images : [''];
    var d = discount(p);
    var videoHref = normalizeExternalVideoUrl(p.videoUrl);
    var sel = { size: (p.sizes && p.sizes.length === 1) ? p.sizes[0] : '', color: (p.colors && p.colors.length === 1) ? p.colors[0].name : '', qty: 1 };

    var html =
      '<div class="gallery" id="gal">' + imgs.map(function (s) { return '<div class="slide">' + imgTag(s, p.name) + '</div>'; }).join('') + '</div>' +
      (imgs.length > 1 ? '<div class="dots">' + imgs.map(function (_, i) { return '<i class="' + (i ? '' : 'on') + '"></i>'; }).join('') + '</div>' : '') +
      '<div class="pd">' +
      '<div class="pd-top"><h2>' + esc(p.name) + '</h2><button class="icon-btn" id="shareBtn" aria-label="مشاركة">' + ICON.share + '</button></div>' +
      '<div class="price big"><b>' + fmt(p.price) + '</b>' + (d ? '<s>' + fmt(p.oldPrice) + '</s><span class="badge sale inline">-' + d + '%</span>' : '') + '</div>' +
      (videoHref ? '<a class="prod-video-cta" href="' + esc(videoHref) + '" target="_blank" rel="noopener noreferrer">' +
        '<span class="pvc-icon">' + ICON.video + '</span>' +
        '<span class="pvc-text"><strong>مشاهدة فيديو المنتج</strong><small>يفتح الفيديو مباشرة في نافذة خارجية</small></span>' +
        '<span class="pvc-arrow">↗</span></a>' : '') +
      (p.desc ? '<p class="desc">' + esc(p.desc) + '</p>' : '') +
      (p.sizes && p.sizes.length ? '<div class="opt"><div class="opt-l">المقاس</div><div class="opt-v" id="sizes">' +
        p.sizes.map(function (s) { return '<button class="pill' + (sel.size === s ? ' on' : '') + '" data-v="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') + '</div></div>' : '') +
      (p.colors && p.colors.length ? '<div class="opt"><div class="opt-l">اللون: <span id="colorName">' + esc(sel.color) + '</span></div><div class="opt-v" id="colors">' +
        p.colors.map(function (c) { return '<button class="swatch' + (sel.color === c.name ? ' on' : '') + '" data-v="' + esc(c.name) + '" title="' + esc(c.name) + '" style="--c:' + esc(c.hex || '#ccc') + '"></button>'; }).join('') + '</div></div>' : '') +
      (p.soldOut ? '<div class="sold-note">هذا المنتج نفذ حالياً، راسلنا حتى نبلغك أول ما يتوفر</div>' :
        '<div class="opt"><div class="opt-l">الكمية</div><div class="qty" id="qty"><button data-d="1">+</button><span>1</span><button data-d="-1">−</button></div></div>') +
      '<div class="pd-actions">' +
      (p.soldOut ? '' : '<button class="btn btn-primary" id="addBtn">' + ICON.cart + ' أضف إلى السلة</button>') +
      (waNumber ? '<a class="btn btn-ghost" target="_blank" rel="noopener" href="' + waLink('مرحباً، أريد أستفسر عن: ' + p.name + ' (' + fmt(p.price) + ')\n' + location.href.split('#')[0] + '#p=' + p.id) + '">' + ICON.wa + ' اسأل عن المنتج</a>' : '') +
      '</div></div>';
    openSheet(html, 'product');

    var sh = $('#sheet');
    var gal = $('#gal', sh);
    if (imgs.length > 1) gal.addEventListener('scroll', function () {
      var i = Math.round(Math.abs(gal.scrollLeft) / gal.clientWidth);
      $$('.dots i', sh).forEach(function (el, k) { el.classList.toggle('on', k === i); });
    });
    var sizes = $('#sizes', sh);
    if (sizes) sizes.addEventListener('click', function (e) {
      var b = e.target.closest('.pill'); if (!b) return;
      sel.size = b.getAttribute('data-v');
      $$('.pill', sizes).forEach(function (x) { x.classList.toggle('on', x === b); });
    });
    var colors = $('#colors', sh);
    if (colors) colors.addEventListener('click', function (e) {
      var b = e.target.closest('.swatch'); if (!b) return;
      sel.color = b.getAttribute('data-v'); $('#colorName', sh).textContent = sel.color;
      $$('.swatch', colors).forEach(function (x) { x.classList.toggle('on', x === b); });
    });
    var qty = $('#qty', sh);
    if (qty) qty.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      sel.qty = Math.max(1, Math.min(20, sel.qty + Number(b.getAttribute('data-d'))));
      $('span', qty).textContent = sel.qty;
    });
    var add = $('#addBtn', sh);
    if (add) add.addEventListener('click', function () {
      if (p.sizes && p.sizes.length && !sel.size) { toast('اختاري المقاس أولاً'); sizes.classList.add('shake'); setTimeout(function () { sizes.classList.remove('shake'); }, 500); return; }
      if (p.colors && p.colors.length && !sel.color) { toast('اختاري اللون أولاً'); colors.classList.add('shake'); setTimeout(function () { colors.classList.remove('shake'); }, 500); return; }
      addToCart(p.id, sel.size, sel.color, sel.qty);
      closeSheet(); toast('تمت الإضافة إلى السلة ✓');
    });
    $('#shareBtn', sh).addEventListener('click', function () {
      var url = location.href.split('#')[0] + '#p=' + encodeURIComponent(p.id);
      if (navigator.share) { navigator.share({ title: p.name, text: p.name + ' - ' + fmt(p.price), url: url }).catch(function () { }); }
      else if (window.UI && window.UI.copy) { window.UI.copy(url, 'تم نسخ رابط المنتج ✓'); }
      else if (navigator.clipboard) { navigator.clipboard.writeText(url).then(function () { toast('تم نسخ رابط المنتج ✓'); }); }
      else { toast('تم تجهيز رابط المنتج للمشاركة ✓'); }
    });
  }

  function openCart() {
    if (!cart.length) {
      openSheet('<div class="pad center"><div class="empty-ico">' + ICON.cart + '</div><h2>السلة فارغة</h2><p class="muted">تصفحي المنتجات وأضيفي اللي يعجبك</p><button class="btn btn-primary" id="goShop">تسوق الآن</button></div>', 'cart');
      $('#goShop').addEventListener('click', closeSheet); return;
    }
    var d = S.delivery || {};
    var st = subtotal();
    var disc = couponDiscountAmount();
    var afterDisc = Math.max(0, st - disc);
    var hasCoupons = S.coupons && S.coupons.length > 0 && (!S.features || S.features.coupons !== false);

    var html = '<div class="pad"><h2>سلة المشتريات</h2><div class="cart-list">' +
      cart.map(function (i) {
        var p = byId[i.id];
        return '<div class="ci" data-key="' + esc(i.key) + '">' + imgTag((p.images || [])[0], p.name, 'ci-img') +
          '<div class="ci-info"><div class="ci-name">' + esc(p.name) + '</div>' +
          '<div class="ci-opt">' + [i.size && ('المقاس: ' + esc(i.size)), i.color && ('اللون: ' + esc(i.color))].filter(Boolean).join(' · ') + '</div>' +
          '<div class="ci-row"><div class="qty sm"><button data-d="1">+</button><span>' + i.qty + '</span><button data-d="-1">−</button></div>' +
          '<b>' + fmt(p.price * i.qty) + '</b></div></div>' +
          '<button class="ci-del" aria-label="حذف">' + ICON.trash + '</button></div>';
      }).join('') + '</div>' +
      (hasCoupons ? '<div style="display:flex;gap:6px;margin:10px 0">' +
        '<input id="cpnInp" placeholder="عندك كود خصم؟ اكتبيه هنا" value="' + esc(activeCoupon ? activeCoupon.code : '') + '" style="flex:1;padding:9px 12px;border:1px solid var(--border);border-radius:10px;text-transform:uppercase" dir="ltr">' +
        '<button class="btn btn-ghost" id="cpnBtn" type="button" style="padding:9px 14px">تطبيق</button></div>' : '') +
      '<div class="sum"><div><span>المجموع</span><b>' + fmt(st) + '</b></div>' +
      (disc > 0 ? '<div style="color:#137547"><span>خصم الكوبون (' + esc(activeCoupon.code) + ')</span><b>− ' + fmt(disc) + '</b></div>' : '') +
      (d.freeOver ? (afterDisc >= d.freeOver ? '<div class="free ok">🎉 مبروك! التوصيل مجاني لطلبك</div>' :
        '<div class="free">أضيفي بـ ' + fmt(d.freeOver - afterDisc) + ' وخذي توصيل مجاني 🚚</div>') : '') +
      '<p class="muted small">أجور التوصيل تُحسب حسب المحافظة في الخطوة الجاية</p></div>' +
      '<button class="btn btn-primary block" id="toCheckout">إتمام الطلب</button>' +
      '<button class="btn btn-link block" id="contShop">إكمال التسوق</button></div>';
    openSheet(html, 'cart');
    var sh = $('#sheet');
    $('.cart-list', sh).addEventListener('click', function (e) {
      var row = e.target.closest('.ci'); if (!row) return;
      var item = cart.filter(function (i) { return i.key === row.getAttribute('data-key'); })[0]; if (!item) return;
      if (e.target.closest('.ci-del')) { cart = cart.filter(function (i) { return i !== item; }); }
      else { var b = e.target.closest('button[data-d]'); if (!b) return; item.qty = Math.max(1, Math.min(20, item.qty + Number(b.getAttribute('data-d')))); }
      saveCart(); openCart();
    });
    var cpnBtn = $('#cpnBtn', sh);
    if (cpnBtn) cpnBtn.addEventListener('click', function () {
      var code = ($('#cpnInp', sh).value || '').trim().toUpperCase();
      if (!code) { activeCoupon = null; openCart(); return; }
      var found = (S.coupons || []).filter(function (c) { return String(c.code || '').toUpperCase() === code && c.active !== false; })[0];
      if (!found) { toast('كود الخصم غير صالح أو منتهي'); return; }
      activeCoupon = found;
      toast('تم تفعيل كود الخصم: ' + found.code + ' 🎉');
      updateFab();
      openCart();
    });
    $('#toCheckout', sh).addEventListener('click', openCheckout);
    $('#contShop', sh).addEventListener('click', closeSheet);
  }

  var CUST_KEY = 'cust_' + activeSlug;
  function openCheckout() {
    var saved = {}; try { saved = JSON.parse(localStorage.getItem(CUST_KEY) || '{}') || {}; } catch (e) { }
    var pays = S.payment && S.payment.length ? S.payment : ['الدفع عند الاستلام'];
    var html = '<div class="pad"><h2>معلومات التوصيل</h2><form id="co" novalidate>' +
      field('name', 'الاسم الكامل', 'text', saved.name, 'مثال: زهراء علي') +
      field('phone', 'رقم الهاتف', 'tel', saved.phone, '07XXXXXXXXX') +
      '<label class="fld"><span>المحافظة</span><select name="prov" required><option value="">اختاري المحافظة</option>' +
      PROVINCES.map(function (p) { return '<option' + (saved.prov === p ? ' selected' : '') + '>' + p + '</option>'; }).join('') + '</select></label>' +
      field('area', 'المنطقة / الحي', 'text', saved.area, 'مثال: المنصور - شارع 14 رمضان') +
      field('landmark', 'أقرب نقطة دالة', 'text', saved.landmark, 'مثال: قرب جامع / مول / مدرسة...') +
      '<label class="fld"><span>طريقة الدفع</span><div class="pays">' +
      pays.map(function (p, i) { return '<label class="pay"><input type="radio" name="pay" value="' + esc(p) + '"' + (i ? '' : ' checked') + '><span>' + esc(p) + '</span></label>'; }).join('') + '</div></label>' +
      '<label class="fld"><span>ملاحظات (اختياري)</span><textarea name="notes" rows="2" placeholder="أي ملاحظة على الطلب أو وقت التوصيل"></textarea></label>' +
      '<div class="sum" id="coSum"></div>' +
      '<button class="btn btn-wa block" type="submit">' + ICON.wa + ' إرسال الطلب عبر واتساب</button>' +
      '<p class="muted small center">راح ينفتح واتساب والطلب مكتوب جاهز، بس اضغطي إرسال ✓</p>' +
      '<button class="btn btn-link block" type="button" id="backCart">رجوع للسلة</button>' +
      '</form></div>';
    openSheet(html, 'checkout');
    var f = $('#co');
    var upd = function () {
      var prov = f.prov.value, fee = deliveryFee(prov), st = subtotal(), disc = couponDiscountAmount();
      var afterDisc = Math.max(0, st - disc);
      $('#coSum').innerHTML = '<div><span>المجموع</span><b>' + fmt(st) + '</b></div>' +
        (disc > 0 ? '<div style="color:#137547"><span>خصم الكوبون (' + esc(activeCoupon.code) + ')</span><b>− ' + fmt(disc) + '</b></div>' : '') +
        '<div><span>التوصيل' + (prov ? ' (' + esc(prov) + ')' : '') + '</span><b>' + (fee === null ? 'اختاري المحافظة' : (fee === 0 ? 'مجاني 🎉' : fmt(fee))) + '</b></div>' +
        '<div class="total"><span>الإجمالي</span><b>' + fmt(afterDisc + (fee || 0)) + '</b></div>';
    };
    f.prov.addEventListener('change', upd); upd();
    $('#backCart').addEventListener('click', openCart);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      $$('.fld.err', f).forEach(function (x) { x.classList.remove('err'); });
      var v = {
        name: f.name.value.trim(), phone: toEnDigits(f.phone.value).replace(/[\s-]/g, ''), prov: f.prov.value,
        area: f.area.value.trim(), landmark: f.landmark.value.trim(), pay: (f.querySelector('input[name=pay]:checked') || {}).value || pays[0],
        notes: f.notes.value.trim()
      };
      v.phone = v.phone.replace(/^(\+?964)/, '0');
      var bad = [];
      if (v.name.length < 3) bad.push('name');
      if (!/^07\d{9}$/.test(v.phone)) bad.push('phone');
      if (!v.prov) bad.push('prov');
      if (v.area.length < 3) bad.push('area');
      if (bad.length) {
        bad.forEach(function (n) { f[n].closest('.fld').classList.add('err'); });
        f[bad[0]].focus();
        toast(bad[0] === 'phone' ? 'رقم الهاتف لازم يكون 11 رقم ويبدأ بـ 07' : 'كمّلي الحقول المطلوبة');
        return;
      }
      try { localStorage.setItem(CUST_KEY, JSON.stringify({ name: v.name, phone: v.phone, prov: v.prov, area: v.area, landmark: v.landmark })); } catch (er) { }
      sendOrder(v);
    });
  }
  function field(name, label, type, val, ph) {
    return '<label class="fld"><span>' + label + '</span><input name="' + name + '" type="' + type + '" value="' + esc(val || '') + '" placeholder="' + esc(ph || '') + '"' +
      (type === 'tel' ? ' inputmode="tel" dir="ltr"' : '') + '></label>';
  }

  function orderNo() {
    var d = new Date(), pre = (S.orderPrefix || 'ORD').toUpperCase();
    return pre + '-' + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0') + '-' + Math.floor(1000 + Math.random() * 9000);
  }

  function sendOrder(v) {
    var no = orderNo(), st = subtotal(), disc = couponDiscountAmount(), afterDisc = Math.max(0, st - disc), fee = deliveryFee(v.prov) || 0, line = '━━━━━━━━━━━━';
    var msg = ['🛍️ *طلب جديد* #' + no, line];
    cart.forEach(function (i, k) {
      var p = byId[i.id];
      msg.push((k + 1) + ') *' + p.name + '*');
      var opts = [i.size && ('المقاس: ' + i.size), i.color && ('اللون: ' + i.color)].filter(Boolean).join(' | ');
      if (opts) msg.push('   ' + opts);
      msg.push('   ' + i.qty + ' × ' + fmt(p.price) + ' = ' + fmt(p.price * i.qty));
    });
    msg.push(line,
      'المجموع: ' + fmt(st),
      disc > 0 ? '🎁 خصم كوبون (' + activeCoupon.code + '): −' + fmt(disc) : '',
      'التوصيل (' + v.prov + '): ' + (fee ? fmt(fee) : 'مجاني'),
      '*الإجمالي الصافي: ' + fmt(afterDisc + fee) + '*',
      line,
      '👤 الاسم: ' + v.name,
      '📞 الهاتف: ' + v.phone,
      '📍 العنوان: ' + v.prov + ' - ' + v.area,
      v.landmark ? '🏠 أقرب نقطة دالة: ' + v.landmark : '',
      '💳 الدفع: ' + v.pay,
      v.notes ? '📝 ملاحظات: ' + v.notes : '');
    var text = msg.filter(Boolean).join('\n');
    var url = waLink(text);
    var w = window.open(url, '_blank');
    if (!w) location.href = url;

    var total = afterDisc + fee;
    cart = []; activeCoupon = null; saveCart();
    openSheet('<div class="pad center"><div class="ok-ico">' + ICON.check + '</div><h2>تم تجهيز طلبك!</h2>' +
      '<p>رقم الطلب: <b dir="ltr">#' + no + '</b></p><p class="muted">الإجمالي: ' + fmt(total) + '</p>' +
      '<p class="muted small">إذا ما انفتح واتساب تلقائياً اضغطي الزر أدناه</p>' +
      '<a class="btn btn-wa block" href="' + url + '" target="_blank" rel="noopener">' + ICON.wa + ' فتح واتساب وإرسال الطلب</a>' +
      '<button class="btn btn-link block" id="doneBtn">رجوع للمتجر</button></div>', 'done');
    $('#doneBtn').addEventListener('click', closeSheet);
  }

  function routeHash() {
    var m = location.hash.match(/^#p=(.+)$/);
    if (m) { var id = decodeURIComponent(m[1]); if (byId[id]) openProduct(id); }
  }

  function bootStore() {
    initProductsAndCart();
    applyTheme();
    if (isLocked()) { renderLock(); return; }
    renderShell();
    renderGrid();
    updateFab();
    routeHash();
  }

  bootStore();
  fetchShardedStoreIfAvailable();
  fetchCloudStoreIfConfigured();
})();
