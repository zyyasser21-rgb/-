/* =========================================================
   مكتبة الواجهات والأيقونات المؤسسية الموحدة — Platform UI & Corporate Iconography v3.0
   مستوحاة بالكامل من نظام List — Corporate Iconography (شبكة 32×32 بخطوط هندسية ناعمة)
   تُستخدم في: المنصة المركزية · لوحة التاجر · واجهة المتجر
   ========================================================= */
(function () {
  'use strict';

  var CSS = '' +
    '.sp-ico{display:inline-flex;align-items:center;justify-content:center;width:1.24em;height:1.24em;vertical-align:-0.22em;flex-shrink:0;line-height:1;margin:0 1px}' +
    '.sp-ico .sp-svg{width:100%;height:100%;display:block;stroke:currentColor;fill:none;stroke-width:2.1;stroke-linecap:round;stroke-linejoin:round}' +
    '.nav-ico .sp-ico{width:20px;height:20px;margin:0}' +
    '.kpi-ico .sp-ico{width:24px;height:24px;margin:0}' +
    '.pm-icon-badge .sp-ico{width:22px;height:22px;margin:0}' +
    '.admin-mini-avatar .sp-ico{width:20px;height:20px;margin:0}' +
    '.ui-ico .sp-ico{width:34px;height:34px;margin:0}' +
    '.icon-pick-grid{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:6px;margin-top:6px}' +
    '.icon-pick-btn{height:40px;border-radius:11px;border:1.5px solid var(--border,#E2E8F0);background:var(--surface,#fff);color:var(--text,#1D1D1F);display:grid;place-items:center;cursor:pointer;transition:all .18s cubic-bezier(.22,1,.36,1)}' +
    '.icon-pick-btn:hover{border-color:var(--brand,#4F46E5);transform:translateY(-1px)}' +
    '.icon-pick-btn.active{background:var(--brand,#4F46E5);color:#fff;border-color:var(--brand,#4F46E5);box-shadow:0 4px 12px rgba(79,70,229,.25)}' +
    '.icon-pick-btn .sp-ico{width:22px;height:22px;margin:0}' +
    '.ui-ov{position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px;' +
    'background:rgba(15,23,42,.45);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);opacity:0;transition:opacity .22s ease;font-family:inherit}' +
    '.ui-ov.on{opacity:1}' +
    '.ui-dlg{direction:rtl;background:#FFFFFF;color:#0F172A;width:100%;max-width:460px;border-radius:26px;' +
    'box-shadow:0 32px 80px rgba(15,23,42,.24),0 0 0 1px rgba(15,23,42,.06);' +
    'transform:translateY(16px) scale(.96);transition:transform .28s cubic-bezier(.22,1,.36,1);overflow:hidden;max-height:92vh;display:flex;flex-direction:column}' +
    '[data-theme="dark"] .ui-dlg{background:#1E293B;color:#F8FAFC;box-shadow:0 32px 80px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.08)}' +
    '.ui-ov.on .ui-dlg{transform:none}' +
    '.ui-dlg.wide{max-width:680px}.ui-dlg.xwide{max-width:920px}' +
    '.ui-dlg-body{padding:28px 26px 12px;text-align:center;overflow-y:auto;scrollbar-width:none;-ms-overflow-style:none}' +
    '.ui-dlg-body::-webkit-scrollbar,.ui-mbody::-webkit-scrollbar{display:none;width:0;height:0}' +
    '.ui-dlg.left .ui-dlg-body{text-align:right}' +
    '.ui-ico{width:64px;height:64px;border-radius:22px;margin:0 auto 16px;display:grid;place-items:center;font-size:28px;' +
    'background:var(--ui-soft,#EEF2FF);color:var(--ui-c,#4F46E5)}' +
    '.ui-ico svg{width:32px;height:32px}' +
    '.ui-ico.danger{--ui-soft:#FEF2F2;--ui-c:#EF4444}.ui-ico.ok,.ui-ico.success{--ui-soft:#ECFDF5;--ui-c:#10B981}.ui-ico.warn,.ui-ico.warning{--ui-soft:#FFFBEB;--ui-c:#F59E0B}' +
    '.ui-ttl{font-size:1.18rem;font-weight:900;margin:0 0 8px;line-height:1.45}' +
    '.ui-msg{font-size:.92rem;color:#64748B;line-height:1.75;margin:0;white-space:pre-line}' +
    '[data-theme="dark"] .ui-msg{color:#94A3B8}' +
    '.ui-inp{width:100%;margin-top:16px;padding:13px 16px;border:1.5px solid #E2E8F0;border-radius:16px;font:inherit;font-size:.96rem;outline:none;' +
    'transition:border-color .18s,box-shadow .18s;background:#F8FAFC;color:inherit;box-sizing:border-box}' +
    '[data-theme="dark"] .ui-inp{background:#0F172A;border-color:#334155}' +
    '.ui-inp:focus{border-color:#4F46E5;box-shadow:0 0 0 4px rgba(79,70,229,.12);background:#fff}' +
    '[data-theme="dark"] .ui-inp:focus{background:#0F172A}' +
    '.ui-err{color:#EF4444;font-size:.82rem;font-weight:700;margin-top:6px;min-height:1em}' +
    '.ui-act{display:flex;gap:10px;padding:18px 26px 24px}' +
    '.ui-act button{flex:1;border:none;border-radius:16px;padding:13px 16px;font:inherit;font-weight:800;font-size:.92rem;cursor:pointer;transition:transform .12s,filter .15s;display:inline-flex;align-items:center;justify-content:center;gap:6px}' +
    '.ui-act button:active{transform:scale(.98)}' +
    '.ui-ok,.ui-btn-primary{background:linear-gradient(135deg,#4F46E5,#6366F1);color:#fff;box-shadow:0 8px 20px rgba(79,70,229,.25)}' +
    '.ui-ok.danger,.ui-btn-danger{background:linear-gradient(135deg,#EF4444,#DC2626);color:#fff;box-shadow:0 8px 20px rgba(239,68,68,.25)}' +
    '.ui-btn-ok{background:linear-gradient(135deg,#10B981,#059669);color:#fff;box-shadow:0 8px 20px rgba(16,185,129,.22)}' +
    '.ui-no,.ui-btn-ghost{background:#F1F5F9;color:#334155}' +
    '[data-theme="dark"] .ui-no,[data-theme="dark"] .ui-btn-ghost{background:#334155;color:#F8FAFC}' +
    '.ui-no:hover,.ui-btn-ghost:hover{filter:brightness(.96)}' +
    '.ui-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:20px 24px;border-bottom:1px solid #EEF2F6}' +
    '[data-theme="dark"] .ui-head{border-color:#334155}' +
    '.ui-head h3{margin:0;font-size:1.08rem;font-weight:900;display:flex;align-items:center;gap:10px}' +
    '.ui-x{width:36px;height:36px;border-radius:50%;border:none;background:#F1F5F9;color:#475569;cursor:pointer;display:grid;place-items:center;transition:transform .2s,background .2s}' +
    '[data-theme="dark"] .ui-x{background:#334155;color:#CBD5E1}' +
    '.ui-x:hover{transform:scale(1.06);background:#E2E8F0}.ui-x svg{width:16px;height:16px}' +
    '.ui-mbody{padding:22px 24px;overflow-y:auto;text-align:right;scrollbar-width:none;-ms-overflow-style:none}' +
    '.ui-mfoot{display:flex;gap:10px;justify-content:flex-end;padding:16px 24px 20px;border-top:1px solid #EEF2F6;flex-wrap:wrap;background:#FAFBFD}' +
    '[data-theme="dark"] .ui-mfoot{border-color:#334155;background:#0F172A}' +
    '.ui-mfoot button{border:none;border-radius:14px;padding:11px 20px;font:inherit;font-weight:800;font-size:.9rem;cursor:pointer;transition:transform .12s,filter .15s;display:inline-flex;align-items:center;justify-content:center;gap:6px}' +
    '.ui-mfoot button:active{transform:scale(.98)}' +
    '.ui-toasts{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:10000;display:flex;flex-direction:column;gap:8px;align-items:center;pointer-events:none}' +
    '.ui-toast{direction:rtl;display:flex;align-items:center;gap:10px;background:rgba(15,23,42,.94);backdrop-filter:blur(10px);color:#fff;padding:13px 20px;border-radius:999px;font-weight:700;font-size:.88rem;' +
    'box-shadow:0 16px 36px rgba(15,23,42,.28);opacity:0;transform:translateY(14px);transition:all .25s cubic-bezier(.22,1,.36,1);max-width:92vw}' +
    '.ui-toast.on{opacity:1;transform:none}' +
    '.ui-toast i{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-style:normal;font-size:12px;background:rgba(255,255,255,.16);flex-shrink:0}' +
    '.ui-toast.ok i,.ui-toast.success i{background:#10B981}.ui-toast.err i,.ui-toast.danger i{background:#EF4444}.ui-toast.warn i,.ui-toast.warning i{background:#F59E0B}' +
    '@media(max-width:520px){.ui-ov{align-items:flex-end;padding:0}.ui-dlg{border-radius:26px 26px 0 0;max-width:none!important}}';

  var oldSt = document.getElementById('ui-kit-css');
  if (oldSt) oldSt.remove();
  var st = document.createElement('style');
  st.id = 'ui-kit-css';
  st.textContent = CSS;
  (document.head || document.documentElement).appendChild(st);

  /* =========================================================
     مجموعة أيقونات List — Corporate Iconography (شبكة 32×32)
     ========================================================= */
  var SP_PATHS = {
    // القائمة الجانبية واللوحات الرئيسية
    home: '<path d="M5 14.2 14.7 5.6a2 2 0 0 1 2.6 0L27 14.2V25a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3V14.2Z"/><path d="M13 28v-6.5a3 3 0 0 1 6 0V28"/>',
    store: '<path d="M5 13h22v12a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3V13Z"/><path d="M4 9.5 6.5 5h19L28 9.5a3.5 3.5 0 0 1-7 0 3.5 3.5 0 0 1-5 3.1 3.5 3.5 0 0 1-5-3.1 3.5 3.5 0 0 1-7 0Z"/><path d="M13 28v-7a3 3 0 0 1 6 0v7"/>',
    factory: '<rect x="4" y="5" width="24" height="17" rx="3.5"/><path d="M11 27h10M16 22v5"/><circle cx="16" cy="13.5" r="2.8"/><path d="M16 8.5v2M16 16.5v2M11 13.5h2M19 13.5h2M12.5 10l1.4 1.4M18.1 15.6l1.4 1.4M19.5 10l-1.4 1.4M13.9 15.6l-1.4 1.4"/>',
    wallet: '<rect x="4" y="8" width="24" height="18" rx="4"/><path d="M7 8V6.5A2.5 2.5 0 0 1 9.5 4h13A2.5 2.5 0 0 1 25 6.5V8"/><path d="M28 14h-6a3 3 0 0 0 0 6h6"/><circle cx="22" cy="17" r="1" fill="currentColor"/>',
    settings: '<circle cx="16" cy="16" r="4"/><path d="M14 4.5h4l.7 2.6a9 9 0 0 1 2.2.9l2.4-1.3 2.8 2.8-1.3 2.4c.4.7.7 1.4.9 2.2l2.6.7v4l-2.6.7a9 9 0 0 1-.9 2.2l1.3 2.4-2.8 2.8-2.4-1.3a9 9 0 0 1-2.2.9L18 27.5h-4l-.7-2.6a9 9 0 0 1-2.2-.9l-2.4 1.3-2.8-2.8 1.3-2.4a9 9 0 0 1-.9-2.2L3.7 18v-4l2.6-.7c.2-.8.5-1.5.9-2.2L5.9 8.7l2.8-2.8 2.4 1.3c.7-.4 1.4-.7 2.2-.9L14 4.5Z"/>',

    // المالية والإحصائيات
    coinHand: '<circle cx="16" cy="10" r="5.5"/><path d="M16 7.5v5M14.5 9c0-.8.7-1.3 1.5-1.3s1.5.5 1.5 1.2c0 1.4-3 1-3 2.4 0 .7.7 1.2 1.5 1.2s1.5-.5 1.5-1.3"/><path d="M4 22.5h5.5l4.5 2.5h7.5a3.5 3.5 0 0 0 3.5-3.5h-7l-3.5-1.5H9.5L4 22.5ZM4 19.5v6"/>',
    pieChart: '<path d="M14.5 6.2A10 10 0 1 0 25.8 17.5H14.5V6.2Z"/><path d="M18 4.2A10 10 0 0 1 27.8 14H18V4.2Z"/>',
    trendUp: '<rect x="4" y="5" width="24" height="22" rx="4"/><path d="m9 20 5-5 3.5 3.5L23 13"/><path d="M18.5 13H23v4.5"/>',
    box: '<rect x="5" y="5" width="22" height="22" rx="4.5"/><path d="M12.5 5v8.5l3.5-2.2 3.5 2.2V5"/>',

    // أنواع المتاجر والتصنيفات (List Categories)
    fashion: '<path d="M11 5.5 5 9.5l2.5 5 3-1.5V25a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2V13l3 1.5 2.5-5-6-4a5 5 0 0 1-10 0Z"/><path d="M16 9.5v4"/>',
    cosmetics: '<rect x="9" y="12" width="14" height="15" rx="3.5"/><path d="M13 12V9h6v3M16 9V5.5M13 5.5h6.5l1.5 1.5"/><path d="M16 16.2s-2.5 2.7-2.5 4.3a2.5 2.5 0 0 0 5 0c0-1.6-2.5-4.3-2.5-4.3Z"/>',
    shoes: '<path d="M5 23.5h22v2a1.5 1.5 0 0 1-1.5 1.5h-19A1.5 1.5 0 0 1 5 25.5v-2ZM5 23.5V9a2 2 0 0 1 2-2h5.5l2 6 6.8 2.5A4.5 4.5 0 0 1 27 19.7v3.8"/><path d="M10.5 11h3.5M11.5 14h3.5"/>',
    watches: '<circle cx="16" cy="16" r="7.5"/><path d="M12 9.2V5.5A1.5 1.5 0 0 1 13.5 4h5A1.5 1.5 0 0 1 20 5.5v3.7M12 22.8v3.7a1.5 1.5 0 0 0 1.5 1.5h5a1.5 1.5 0 0 0 1.5-1.5v-3.7"/><path d="M16 12.5V16l2.5 2"/>',
    electronics: '<rect x="4" y="5" width="24" height="17" rx="3.5"/><path d="M11 27h10M16 22v5"/><path d="M11.5 12.5a6.5 6.5 0 0 1 9 0M13.5 15a3.5 3.5 0 0 1 5 0"/><circle cx="16" cy="17.5" r="1" fill="currentColor"/>',
    homeGarden: '<path d="M5 14.2 14.7 5.6a2 2 0 0 1 2.6 0L27 14.2V25a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3V14.2Z"/><path d="M16 28v-8"/><path d="M16 22c-3 0-4.5-2-4.5-4.5 2.5 0 4.5 1.5 4.5 4.5ZM16 20c3 0 4.5-2 4.5-4.5-2.5 0-4.5 1.5-4.5 4.5Z"/>',
    baby: '<path d="M6 14h19a1 1 0 0 1 1 1v1a9 9 0 0 1-9 9h-2a9 9 0 0 1-9-9v-2Zm11-7a8 8 0 0 1 8 7H17V7ZM4 10h3l2 4"/><circle cx="11" cy="27" r="2"/><circle cx="21" cy="27" r="2"/>',
    sports: '<circle cx="16" cy="16" r="11"/><path d="M5 16h22M16 5v22M8.2 8.2c4.3 4.3 4.3 11.3 0 15.6M23.8 8.2c-4.3 4.3-4.3 11.3 0 15.6"/>',
    food: '<path d="M9 5v7a3 3 0 0 0 3 3v12a1.5 1.5 0 0 0 3 0V5M12 5v6M20 5c2.5 0 4 2.5 4 6.5V16h-2v11a1.5 1.5 0 0 1-3 0V5h1Z"/>',
    appliances: '<rect x="5" y="5" width="22" height="22" rx="4"/><path d="M5 10.5h22"/><circle cx="16" cy="18.5" r="4.5"/><path d="M9 7.8h1.5M13 7.8h1.5"/>',
    cars: '<path d="M6 17 8.5 9.5A2.5 2.5 0 0 1 11 7.8h10a2.5 2.5 0 0 1 2.5 1.7L26 17"/><rect x="4" y="17" width="24" height="7" rx="2.5"/><path d="M7 24v2.5M25 24v2.5"/><circle cx="9.5" cy="20.5" r="1.2" fill="currentColor"/><circle cx="22.5" cy="20.5" r="1.2" fill="currentColor"/>',
    briefcase: '<rect x="4" y="9" width="24" height="17" rx="3.5"/><path d="M11 9V6.5A1.5 1.5 0 0 1 12.5 5h7A1.5 1.5 0 0 1 21 6.5V9M4 15.5h24"/><rect x="13.5" y="13.5" width="5" height="4" rx="1"/>',

    // الباقات والاشتراكات
    plant: '<path d="M11 22h10l-1.2 5.5H12.2L11 22ZM16 22V11"/><path d="M16 15c-4 0-6-2.5-6-6 3.5 0 6 2 6 6ZM16 13c4 0 6-2.5 6-6-3.5 0-6 2-6 6Z"/>',
    diamond: '<path d="M9.5 6h13L28 13 16 26.5 4 13 9.5 6Z"/><path d="M4 13h24M9.5 6 13 13l3 13.5L19 13l3.5-7"/>',
    rocket: '<path d="M18.5 13.5c4-4 6.5-8.5 6.5-8.5s-4.5 2.5-8.5 6.5L11 17l4 4 5.5-5.5Z"/><path d="M11 17 7 16l-2 3 4.5 1.5L11 25l3-2-1-4M8.5 23.5 5 27"/><circle cx="19.5" cy="12.5" r="1.5"/>',
    crown: '<rect x="4" y="4" width="24" height="24" rx="5"/><path d="M9 21h14l1.5-8.5-5 3.5L16 11l-3.5 5-5-3.5L9 21Z"/>',
    infinity: '<rect x="4" y="5" width="24" height="22" rx="4.5"/><path d="M16 16c-2-2.6-3.8-3.5-5.3-3.5a3.5 3.5 0 1 0 0 7c1.5 0 3.3-.9 5.3-3.5Zm0 0c2 2.6 3.8 3.5 5.3 3.5a3.5 3.5 0 1 0 0-7c-1.5 0-3.3.9-5.3 3.5Z"/>',
    starBadge: '<circle cx="16" cy="16" r="11"/><path d="m16 9.5 2 4 4.4.6-3.2 3.1.8 4.4-4-2.1-4 2.1.8-4.4-3.2-3.1 4.4-.6 2-4Z"/>',

    // الإجراءات والأدوات
    edit: '<path d="M15 6H8a3 3 0 0 0-3 3v15a3 3 0 0 0 3 3h15a3 3 0 0 0 3-3v-7"/><path d="M22.5 5.5a2.1 2.1 0 0 1 3 3L16 18l-4 1 1-4 9.5-9.5Z"/>',
    trash: '<path d="M6 9h20M8.5 9l1.2 16.5a2 2 0 0 0 2 1.8h8.6a2 2 0 0 0 2-1.8L23.5 9M12.5 9V6.5a1.5 1.5 0 0 1 1.5-1.5h4a1.5 1.5 0 0 1 1.5 1.5V9M13.5 14v8M18.5 14v8"/>',
    search: '<circle cx="14.5" cy="14.5" r="8.5"/><path d="m21 21 5.5 5.5"/>',
    plusCircle: '<circle cx="16" cy="16" r="11"/><path d="M16 11v10M11 16h10"/>',
    checkCircle: '<circle cx="16" cy="16" r="11"/><path d="m11.5 16 3 3 6-6"/>',
    closeCircle: '<circle cx="16" cy="16" r="11"/><path d="m12.5 12.5 7 7m0-7-7 7"/>',
    shieldCheck: '<path d="M16 4.5 6.5 8.5v7c0 6.2 4 10.8 9.5 12.5 5.5-1.7 9.5-6.3 9.5-12.5v-7L16 4.5Z"/><path d="m12.5 16 2.5 2.5 5-5"/>',
    shieldLock: '<path d="M16 4.5 6.5 8.5v7c0 6.2 4 10.8 9.5 12.5 5.5-1.7 9.5-6.3 9.5-12.5v-7L16 4.5Z"/><rect x="12.5" y="15" width="7" height="5.5" rx="1.2"/><path d="M14 15v-2a2 2 0 0 1 4 0v2"/>',
    unlock: '<rect x="7" y="14" width="18" height="13" rx="3"/><path d="M11 14v-3.5a5 5 0 0 1 9.5-2"/>',
    key: '<circle cx="11" cy="16" r="5.5"/><path d="M16.5 16H27v3.5M23 16v3"/>',
    gift: '<rect x="5" y="11" width="22" height="4.5" rx="1.5"/><path d="M7 15.5h18V25a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2v-9.5ZM16 11v16"/><path d="M16 11c-2.5 0-4.5-1.5-4.5-3.3S13.2 5 15 6.8L16 11Zm0 0c2.5 0 4.5-1.5 4.5-3.3S18.8 5 17 6.8L16 11Z"/>',
    calendar: '<path d="M18 26H8a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3h15a3 3 0 0 1 3 3v7M5 12h21M11 4v4M20 4v4"/><circle cx="22.5" cy="22.5" r="4.5"/><path d="M22.5 20.5v2.2l1.5 1"/>',
    clock: '<circle cx="16" cy="17" r="9.5"/><path d="M13.5 4.5h5M16 4.5v3M16 13v4.5l3 2"/>',
    user: '<circle cx="16" cy="16" r="11"/><circle cx="16" cy="13" r="3.5"/><path d="M9.5 24.5a7 7 0 0 1 13 0"/>',
    phoneChat: '<path d="M7.5 6.5h3.5l1.8 4.5-2.3 1.8a12 12 0 0 0 6.7 6.7l1.8-2.3 4.5 1.8v3.5a2 2 0 0 1-2 2A16 16 0 0 1 5.5 8.5a2 2 0 0 1 2-2Z"/><rect x="17" y="5.5" width="9.5" height="6.5" rx="2"/><path d="M19.5 9h.1M22 9h.1M24.5 9h.1"/>',
    chatBubble: '<rect x="4" y="6" width="24" height="17" rx="4"/><path d="m12 23 4 4 4-4M10 12h12M10 16.5h8"/>',
    image: '<rect x="5" y="5" width="22" height="22" rx="4.5"/><circle cx="11.5" cy="11.5" r="2"/><path d="m5 21 6.5-5.5 4.5 4 4.5-3.5 6.5 5.5"/>',
    camera: '<rect x="4" y="8" width="24" height="18" rx="4"/><circle cx="16" cy="17" r="4.5"/><path d="M11.5 8 13 5.5h6L20.5 8"/>',
    copy: '<rect x="6" y="8" width="14" height="18" rx="3"/><path d="M12 8V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-2"/><path d="M10 14h6M10 18h6M10 22h4"/>',
    doc: '<rect x="6" y="4" width="20" height="24" rx="3.5"/><path d="M11 11h10M11 16h10M11 21h6"/>',
    download: '<path d="M6 21v3a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-3M16 5v15m0 0-5-5m5 5 5-5"/>',
    upload: '<path d="M6 21v3a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-3M16 20V5m0 0-5 5m5-5 5 5"/>',
    save: '<path d="M7 5h15l4 4v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><path d="M10 5v7h11V5M10 27v-8h12v8"/>',
    tag: '<path d="M15.6 5.5H7.5a2 2 0 0 0-2 2v8.1a2 2 0 0 0 .6 1.4l9.4 9.4a2 2 0 0 0 2.8 0l8.1-8.1a2 2 0 0 0 0-2.8L17 6.1a2 2 0 0 0-1.4-.6Z"/><circle cx="11" cy="11" r="1.5" fill="currentColor"/>',
    discount: '<path d="m16 4 2.8 2.1 3.5-.3 1.3 3.2 3.2 1.3-.3 3.5L28.6 16l-2.1 2.8.3 3.5-3.2 1.3-1.3 3.2-3.5-.3L16 28.6l-2.8-2.1-3.5.3-1.3-3.2-3.2-1.3.3-3.5L3.4 16l2.1-2.8-.3-3.5 3.2-1.3 1.3-3.2 3.5.3L16 4Z"/><path d="m12.5 19.5 7-7"/><circle cx="13" cy="13" r="1.2" fill="currentColor"/><circle cx="19" cy="19" r="1.2" fill="currentColor"/>',
    bagCheck: '<path d="M7 10h18l-1.5 16a2 2 0 0 1-2 1.8h-11a2 2 0 0 1-2-1.8L7 10Z"/><path d="M12 10V7.5a4 4 0 0 1 8 0V10"/><circle cx="22" cy="22" r="5" fill="var(--surface,#fff)"/><path d="m20 22 1.5 1.5 3-3"/>',
    cart: '<circle cx="11" cy="25.5" r="2"/><circle cx="22" cy="25.5" r="2"/><path d="M4 6h4l2.4 12.5a2 2 0 0 0 2 1.6h10.8a2 2 0 0 0 2-1.5L27 10H9"/>',
    truck: '<path d="M4 8h14v12H4V8Zm14 4h5l4 4.5V20h-9v-8Z"/><circle cx="9.5" cy="22.5" r="2.5"/><circle cx="21.5" cy="22.5" r="2.5"/>',
    video: '<rect x="4" y="6" width="24" height="17" rx="3.5"/><path d="M11 27h10M16 23v4"/><path d="m14 11.5 5.5 3-5.5 3v-6Z" fill="currentColor"/>',
    sparkle: '<circle cx="16" cy="16" r="11"/><path d="m16 9.5 1.8 4.7 4.7 1.8-4.7 1.8-1.8 4.7-1.8-4.7-4.7-1.8 4.7-1.8L16 9.5Z"/>',
    sun: '<circle cx="16" cy="16" r="5.5"/><path d="M16 4.5v3M16 24.5v3M4.5 16h3M24.5 16h3M7.9 7.9l2.1 2.1M22 22l2.1 2.1M24.1 7.9 22 10M10 22l-2.1 2.1"/>',
    flame: '<path d="M16.5 4.5c1 4.5 6.5 7 6.5 13.5a7 7 0 1 1-14 0c0-4 2.5-6.8 4.2-8.5.5 2.2 2 3 2 3s-.5-4.2 1.3-8Z"/><path d="M16 25a3 3 0 0 0 3-3c0-2-3-4-3-4s-3 2-3 4a3 3 0 0 0 3 3Z"/>',
    bolt: '<circle cx="16" cy="16" r="11"/><path d="M17.5 8.5 11.5 17h4.5l-1.5 6.5 6-8.5h-4.5l1.5-6.5Z"/>',
    refresh: '<path d="M25.5 15A9.5 9.5 0 0 0 8.5 9.5L6.5 11.5M6.5 7v4.5H11M6.5 17a9.5 9.5 0 0 0 17 5.5l2-2M25.5 25v-4.5H21"/>',
    link: '<path d="M13 19a5 5 0 0 1 0-7l3-3a5 5 0 0 1 7 7l-1.5 1.5"/><path d="M19 13a5 5 0 0 1 0 7l-3 3a5 5 0 0 1-7-7l1.5-1.5"/>',
    pinLoc: '<path d="M16 27s8-6.2 8-13a8 8 0 1 0-16 0c0 6.8 8 13 8 13Z"/><circle cx="16" cy="14" r="3"/>',
    ruler: '<path d="M6 12h20v8a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-8Z"/><path d="M10 12v4M14 12v3M18 12v4M22 12v3"/>',
    palette: '<path d="M16 5a11 11 0 0 0 0 22 2.5 2.5 0 0 0 2.5-2.5c0-.6-.2-1.2-.6-1.6-.4-.4-.6-1-.6-1.6A2.5 2.5 0 0 1 19.8 19H22a5 5 0 0 0 5-5c0-5-4.9-9-11-9Z"/><circle cx="10.5" cy="13.5" r="1.3" fill="currentColor"/><circle cx="14.5" cy="10.5" r="1.3" fill="currentColor"/><circle cx="19.5" cy="11.5" r="1.3" fill="currentColor"/>',
    megaphone: '<path d="m19 8-9 4H6a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h4l9 4V8Z"/><path d="M23 12a4.5 4.5 0 0 1 0 7M9.5 19l1.5 5.5h3L12.5 19"/>',
    eye: '<path d="M4 16s4.5-7 12-7 12 7 12 7-4.5 7-12 7-12-7-12-7Z"/><circle cx="16" cy="16" r="3.2"/>',
    eyeOff: '<path d="M4 16s4.5-7 12-7 12 7 12 7-4.5 7-12 7-12-7-12-7Z"/><path d="m6 6 20 20"/>',
    arrowUp: '<circle cx="16" cy="16" r="11"/><path d="M16 21V11m0 0-4 4m4-4 4 4"/>',
    arrowDown: '<circle cx="16" cy="16" r="11"/><path d="M16 11v10m0 0-4-4m4 4 4-4"/>',
    bulb: '<path d="M12.5 22h7M13.5 25.5h5M16 5a7.5 7.5 0 0 0-4.5 13.5c.8.6 1.3 1.5 1.5 2.5h6c.2-1 .7-1.9 1.5-2.5A7.5 7.5 0 0 0 16 5Z"/>',
    wheel: '<circle cx="16" cy="16" r="11"/><circle cx="16" cy="16" r="3"/><path d="M16 5v8M16 19v8M5 16h8M19 16h8M8.2 8.2l5.7 5.7M18.1 18.1l5.7 5.7M23.8 8.2l-5.7 5.7M13.9 18.1l-5.7 5.7"/>',
    music: '<path d="M12 23V8l13-3v15"/><circle cx="9" cy="23" r="3"/><circle cx="22" cy="20" r="3"/>',
    plane: '<path d="m27 5-11 12M27 5l-7 22-4-10-10-4L27 5Z"/>',
    folder: '<path d="M4 9.5A2.5 2.5 0 0 1 6.5 7h5.8l2.5 3h10.7A2.5 2.5 0 0 1 28 12.5v11A2.5 2.5 0 0 1 25.5 26h-19A2.5 2.5 0 0 1 4 23.5v-14Z"/>',
    sad: '<circle cx="16" cy="16" r="11"/><path d="M12 13h.1M20 13h.1"/><path d="M11.5 21.5a5.5 5.5 0 0 1 9 0"/>'
  };

  /* ربط جميع الرموز والإيموجيات في المشروع بأيقونات List — Corporate Iconography */
  var EMOJI_TO_KEY = {
    '📊': 'home',
    '🏠': 'home',
    '🏢': 'store',
    '🏪': 'store',
    '🏗️': 'factory',
    '🏗': 'factory',
    '💳': 'wallet',
    '⚙️': 'settings',
    '⚙': 'settings',
    '💰': 'coinHand',
    '💵': 'coinHand',
    '📈': 'trendUp',
    '📦': 'box',
    '👗': 'fashion',
    '💄': 'cosmetics',
    '👠': 'shoes',
    '👟': 'shoes',
    '⌚': 'watches',
    '📱': 'electronics',
    '🛋️': 'homeGarden',
    '🛋': 'homeGarden',
    '🍼': 'baby',
    '⚽': 'sports',
    '🍰': 'food',
    '🌱': 'plant',
    '🌸': 'plant',
    '💎': 'diamond',
    '🚀': 'rocket',
    '👑': 'crown',
    '♾️': 'infinity',
    '♾': 'infinity',
    '🌟': 'starBadge',
    '✨': 'sparkle',
    '🌙': 'sparkle',
    '☀️': 'sun',
    '☀': 'sun',
    '✏️': 'edit',
    '✏': 'edit',
    '📝': 'edit',
    '🗑️': 'trash',
    '🗑': 'trash',
    '🔍': 'search',
    '➕': 'plusCircle',
    '✅': 'checkCircle',
    '🟢': 'checkCircle',
    '🔴': 'closeCircle',
    '⛔': 'closeCircle',
    '✕': 'closeCircle',
    '🛡️': 'shieldCheck',
    '🛡': 'shieldCheck',
    '🔐': 'shieldLock',
    '🔒': 'shieldLock',
    '🔓': 'unlock',
    '🔑': 'key',
    '🎁': 'gift',
    '🎉': 'gift',
    '🎟️': 'discount',
    '🎟': 'discount',
    '📅': 'calendar',
    '⏳': 'clock',
    '🕒': 'clock',
    '👤': 'user',
    '📞': 'phoneChat',
    '💬': 'chatBubble',
    '📷': 'camera',
    '📸': 'camera',
    '📘': 'doc',
    '✈️': 'plane',
    '✈': 'plane',
    '🎵': 'music',
    '📢': 'megaphone',
    '🎡': 'wheel',
    '🎬': 'video',
    '🛍️': 'bagCheck',
    '🛍': 'bagCheck',
    '🛒': 'cart',
    '🚚': 'truck',
    '🏷️': 'tag',
    '🏷': 'tag',
    '🆔': 'tag',
    '📐': 'ruler',
    '📏': 'ruler',
    '🎨': 'palette',
    '🖤': 'palette',
    '⚡': 'bolt',
    '🔥': 'flame',
    '🔄': 'refresh',
    '🔗': 'link',
    '📌': 'pinLoc',
    '📍': 'pinLoc',
    '📋': 'copy',
    '📑': 'copy',
    '📜': 'doc',
    '📥': 'download',
    '📤': 'upload',
    '💾': 'save',
    '👁️': 'eye',
    '👁': 'eye',
    '🙈': 'eyeOff',
    '⬆️': 'arrowUp',
    '⬆': 'arrowUp',
    '⬇️': 'arrowDown',
    '⬇': 'arrowDown',
    '💡': 'bulb',
    '🎯': 'starBadge',
    '🧪': 'cosmetics',
    '🗂️': 'folder',
    '🗂': 'folder',
    '📂': 'folder',
    '🙁': 'sad'
  };

  function getSvgByKey(key) {
    var path = SP_PATHS[key] || SP_PATHS[EMOJI_TO_KEY[key]] || SP_PATHS.starBadge;
    return '<svg class="sp-svg" width="20" height="20" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + '</svg>';
  }

  function spIcon(keyOrEmoji, customStyle) {
    var k = String(keyOrEmoji || '').trim();
    var cleanKey = k.replace(/\uFE0F/g, '');
    var resolved = SP_PATHS[k] ? k : (EMOJI_TO_KEY[k] || EMOJI_TO_KEY[cleanKey] || 'starBadge');
    return '<span class="sp-ico"' + (customStyle ? ' style="' + customStyle + '"' : '') + '>' + getSvgByKey(resolved) + '</span>';
  }

  // تعبير نمطي لمطابقة كافة الإيموجيات وتحويلها تلقائياً إلى أيقونات List Corporate SVG
  var emojiKeysSorted = Object.keys(EMOJI_TO_KEY).sort(function (a, b) { return b.length - a.length; });
  var escapedKeys = emojiKeysSorted.map(function (k) {
    return k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  });
  var EMOJI_REGEX = new RegExp('(' + escapedKeys.join('|') + ')\\uFE0F?', 'g');

  var SKIP_TAGS = {
    SCRIPT: 1,
    STYLE: 1,
    TEXTAREA: 1,
    INPUT: 1,
    OPTION: 1,
    SELECT: 1,
    CODE: 1,
    PRE: 1,
    SVG: 1,
    PATH: 1
  };

  function upgradeIconsInNode(root) {
    if (!root) return;
    // تنظيف نصوص <option> من الإيموجيات القديمة لتظهر القوائم المنسدلة رسمية ونظيفة
    if (root.querySelectorAll) {
      var opts = root.querySelectorAll('option');
      for (var i = 0; i < opts.length; i++) {
        var opt = opts[i];
        if (opt.textContent && EMOJI_REGEX.test(opt.textContent)) {
          EMOJI_REGEX.lastIndex = 0;
          opt.textContent = opt.textContent.replace(EMOJI_REGEX, '').replace(/^\s+/, '');
        }
      }
    }

    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        var p = node.parentNode;
        if (!p || SKIP_TAGS[p.nodeName]) return NodeFilter.FILTER_REJECT;
        if (p.closest && p.closest('svg, option, script, style, textarea')) return NodeFilter.FILTER_REJECT;
        if (!node.nodeValue || !EMOJI_REGEX.test(node.nodeValue)) return NodeFilter.FILTER_SKIP;
        return NodeFilter.FILTER_ACCEPT;
      }
    }, false);

    var textNodes = [];
    var curr;
    while ((curr = walker.nextNode())) {
      textNodes.push(curr);
    }

    for (var j = 0; j < textNodes.length; j++) {
      var tNode = textNodes[j];
      var val = tNode.nodeValue;
      EMOJI_REGEX.lastIndex = 0;
      if (!EMOJI_REGEX.test(val)) continue;
      EMOJI_REGEX.lastIndex = 0;

      var frag = document.createDocumentFragment();
      var lastIdx = 0;
      var match;
      while ((match = EMOJI_REGEX.exec(val)) !== null) {
        if (match.index > lastIdx) {
          frag.appendChild(document.createTextNode(val.slice(lastIdx, match.index)));
        }
        var rawEmoji = match[1];
        var cleanEmoji = rawEmoji.replace(/\uFE0F/g, '');
        var iconKey = EMOJI_TO_KEY[rawEmoji] || EMOJI_TO_KEY[cleanEmoji];
        if (iconKey) {
          var span = document.createElement('span');
          span.className = 'sp-ico';
          span.innerHTML = getSvgByKey(iconKey);
          frag.appendChild(span);
        } else {
          frag.appendChild(document.createTextNode(match[0]));
        }
        lastIdx = EMOJI_REGEX.lastIndex;
      }
      if (lastIdx < val.length) {
        frag.appendChild(document.createTextNode(val.slice(lastIdx)));
      }
      if (tNode.parentNode) {
        tNode.parentNode.replaceChild(frag, tNode);
      }
    }
  }

  // مراقب ذكي يحوّل أي أيقونة أو زر يضاف للصفحة تلقائياً إلى تصميم List — Corporate Iconography
  var observerActive = false;
  function startIconObserver() {
    if (observerActive || !document.body) return;
    observerActive = true;
    upgradeIconsInNode(document.body);
    if ('MutationObserver' in window) {
      var mo = new MutationObserver(function (mutations) {
        for (var i = 0; i < mutations.length; i++) {
          var m = mutations[i];
          if (m.type === 'childList' && m.addedNodes && m.addedNodes.length) {
            for (var k = 0; k < m.addedNodes.length; k++) {
              var n = m.addedNodes[k];
              if (n.nodeType === 1) {
                if (!n.classList || !n.classList.contains('sp-ico')) {
                  upgradeIconsInNode(n);
                }
              } else if (n.nodeType === 3 && n.parentNode && !SKIP_TAGS[n.parentNode.nodeName]) {
                upgradeIconsInNode(n.parentNode);
              }
            }
          }
        }
      });
      mo.observe(document.body, { childList: true, subtree: true });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startIconObserver);
  } else {
    startIconObserver();
  }

  var ICONS = {
    info: getSvgByKey('bulb'),
    danger: getSvgByKey('trash'),
    warn: getSvgByKey('bolt'),
    warning: getSvgByKey('bolt'),
    ok: getSvgByKey('checkCircle'),
    success: getSvgByKey('checkCircle'),
    edit: getSvgByKey('edit'),
    lock: getSvgByKey('shieldLock'),
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>'
  };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function normalizeDialogArgs(arg1, arg2, arg3, kind) {
    if (typeof arg1 === 'object' && arg1 !== null) return arg1;
    var o = {};
    if (kind === 'prompt') {
      if (typeof arg2 === 'string' || typeof arg2 === 'number') {
        o = Object.assign({}, arg3 || {});
        o.message = String(arg1 || '');
        o.value = String(arg2);
      } else {
        o = Object.assign({}, arg2 || {});
        o.message = String(arg1 || '');
      }
    } else {
      o = Object.assign({}, arg2 || {});
      o.message = String(arg1 || '');
    }
    return o;
  }

  function mount(dlgClass, inner, customWidth) {
    var ov = document.createElement('div');
    ov.className = 'ui-ov';
    var styleAttr = customWidth ? (' style="max-width:' + esc(customWidth) + '"') : '';
    ov.innerHTML = '<div class="ui-dlg ' + (dlgClass || '') + '"' + styleAttr + ' role="dialog" aria-modal="true">' + inner + '</div>';
    document.body.appendChild(ov);
    upgradeIconsInNode(ov);
    requestAnimationFrame(function () { ov.classList.add('on'); });
    return ov;
  }

  function unmount(ov) {
    if (!ov) return;
    ov.classList.remove('on');
    setTimeout(function () { if (ov.parentNode) ov.parentNode.removeChild(ov); }, 240);
  }

  function dialog(arg1, arg2, arg3, kind) {
    var o = normalizeDialogArgs(arg1, arg2, arg3, kind);
    return new Promise(function (resolve) {
      var type = o.type || (o.danger ? 'danger' : (kind === 'prompt' ? 'edit' : 'info'));
      var isDanger = Boolean(o.danger || type === 'danger');
      var icoCls = isDanger ? 'danger' : (type === 'ok' || type === 'success') ? 'ok' : (type === 'warn' || type === 'warning') ? 'warn' : '';
      var html =
        '<div class="ui-dlg-body">' +
          '<div class="ui-ico ' + icoCls + '">' + (o.icon ? spIcon(o.icon) : (ICONS[type] || ICONS.info)) + '</div>' +
          (o.title ? '<h3 class="ui-ttl">' + esc(o.title) + '</h3>' : '') +
          (o.message ? '<p class="ui-msg">' + esc(o.message) + '</p>' : '') +
          (kind === 'prompt' ? '<input class="ui-inp" type="' + (o.inputType || 'text') + '" ' + (o.dir ? 'dir="' + o.dir + '"' : '') +
            ' value="' + esc(o.value || '') + '" placeholder="' + esc(o.placeholder || '') + '"><div class="ui-err"></div>' : '') +
        '</div>' +
        '<div class="ui-act">' +
          (kind !== 'alert' ? '<button type="button" class="ui-no">' + esc(o.cancelText || 'إلغاء') + '</button>' : '') +
          '<button type="button" class="ui-ok ' + (isDanger ? 'danger' : '') + '">' + esc(o.okText || (kind === 'confirm' ? 'تأكيد' : 'حسناً')) + '</button>' +
        '</div>';
      var ov = mount('', html, o.width);
      var inp = ov.querySelector('.ui-inp');
      var done = function (val) { document.removeEventListener('keydown', onKey); unmount(ov); resolve(val); };
      var ok = function () {
        if (kind === 'prompt') {
          var v = inp.value.trim();
          if (o.required !== false && !v) { ov.querySelector('.ui-err').textContent = o.requiredText || 'يرجى ملء هذا الحقل'; inp.focus(); return; }
          if (o.validate) { var err = o.validate(v); if (err) { ov.querySelector('.ui-err').textContent = err; inp.focus(); return; } }
          done(v);
        } else done(true);
      };
      var cancel = function () { done(kind === 'prompt' ? null : (kind === 'alert' ? true : false)); };
      var onKey = function (e) { if (e.key === 'Escape') cancel(); if (e.key === 'Enter' && (kind !== 'prompt' || document.activeElement === inp)) { e.preventDefault(); ok(); } };
      document.addEventListener('keydown', onKey);
      ov.querySelector('.ui-ok').addEventListener('click', ok);
      var no = ov.querySelector('.ui-no'); if (no) no.addEventListener('click', cancel);
      ov.addEventListener('click', function (e) { if (e.target === ov) cancel(); });
      setTimeout(function () { (inp || ov.querySelector('.ui-ok')).focus(); if (inp) inp.select(); }, 60);
    });
  }

  /* نافذة مخصصة كاملة بمحتوى HTML */
  function modal(o) {
    o = o || {};
    var contentHtml = o.html != null ? o.html : (o.bodyHtml || '');
    var html =
      '<div class="ui-head"><h3>' + (o.icon ? spIcon(o.icon) : '') + esc(o.title || '') + '</h3>' +
      '<button type="button" class="ui-x" aria-label="إغلاق">' + ICONS.x + '</button></div>' +
      '<div class="ui-mbody">' + contentHtml + '</div>' +
      (o.actions && o.actions.length ? '<div class="ui-mfoot">' + o.actions.map(function (a, i) {
        var btnText = a.text != null ? a.text : (a.label || 'تأكيد');
        var btnCls = a.className || (a.primary ? 'ui-ok' : (a.danger ? 'ui-ok danger' : 'ui-no'));
        return '<button type="button" data-ai="' + i + '" class="' + esc(btnCls) + '">' + esc(btnText) + '</button>';
      }).join('') + '</div>' : '');
    var ov = mount((o.size || 'wide') + ' left', html, o.width);
    var dlgEl = ov.querySelector('.ui-dlg');
    var api = {
      ov: ov,
      el: dlgEl,
      body: ov.querySelector('.ui-mbody'),
      querySelector: function (sel) { return dlgEl.querySelector(sel); },
      querySelectorAll: function (sel) { return dlgEl.querySelectorAll(sel); },
      close: function () { document.removeEventListener('keydown', onKey); unmount(ov); if (o.onClose) o.onClose(); }
    };
    var onKey = function (e) { if (e.key === 'Escape') api.close(); };
    document.addEventListener('keydown', onKey);
    ov.querySelector('.ui-x').addEventListener('click', api.close);
    ov.addEventListener('mousedown', function (e) { if (e.target === ov && o.dismissible !== false) api.close(); });
    Array.prototype.forEach.call(ov.querySelectorAll('[data-ai]'), function (b) {
      b.addEventListener('click', function () {
        var a = o.actions[Number(b.getAttribute('data-ai'))];
        var r = a.onClick ? a.onClick(dlgEl, api.close, api) : undefined;
        if (r !== false && a.keepOpen !== true) api.close();
      });
    });
    if (o.onMount) o.onMount(dlgEl, api);
    upgradeIconsInNode(dlgEl);
    return api;
  }

  var toastBox = null;
  function toast(msg, type) {
    if (!document.body) return;
    if (!toastBox) { toastBox = document.createElement('div'); toastBox.className = 'ui-toasts'; document.body.appendChild(toastBox); }
    var t = document.createElement('div');
    t.className = 'ui-toast ' + (type || 'ok');
    t.innerHTML = '<i>' + ((type === 'err' || type === 'danger') ? '!' : (type === 'warn' || type === 'warning') ? '!' : type === 'info' ? 'i' : '✓') + '</i><span>' + esc(msg) + '</span>';
    upgradeIconsInNode(t);
    toastBox.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('on'); });
    setTimeout(function () { t.classList.remove('on'); setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 260); }, (type === 'err' || type === 'danger') ? 3400 : 2500);
  }

  function copy(text, okMsg) {
    var done = function () { toast(okMsg || 'تم النسخ ✓', 'success'); };
    if (navigator.clipboard && window.isSecureContext !== false) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else fallback();
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e) { toast('تعذر النسخ تلقائياً', 'err'); }
      document.body.removeChild(ta);
    }
  }

  window.spIcon = spIcon;
  window.SP_PATHS = SP_PATHS;
  window.UI = {
    alert: function (a1, a2) { return dialog(a1, a2, null, 'alert'); },
    confirm: function (a1, a2) { return dialog(a1, a2, null, 'confirm'); },
    prompt: function (a1, a2, a3) { return dialog(a1, a2, a3, 'prompt'); },
    modal: modal,
    toast: toast,
    copy: copy,
    esc: esc,
    icons: ICONS,
    spIcon: spIcon,
    upgradeIcons: upgradeIconsInNode
  };
})();
